<?php
/**
 * Plugin Name: Áreas Asignadas
 * Plugin URI:  https://example.com
 * Description: Panel para administradores de empresa: gestión de áreas asignadas, listado de usuarios con progreso de test y generación de informes en PDF.
 * Version:     2.5.0
 * Author:      Tu Empresa
 * Text Domain: areas-asignadas
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

// ─── Constantes del plugin ──────────────────────────────────────────────────
define( 'AP_VERSION', '2.5.0' );
define( 'AP_PLUGIN_FILE', __FILE__ );
define( 'AP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AP_TEXT_DOMAIN', 'areas-asignadas' );

// ─── Carga de clases ────────────────────────────────────────────────────────
// Orden deliberado: primero las utilidades sin dependencias (helpers, security,
// database), luego los módulos que dependen de ellas (frontend, ajax, admin)
// y por último el loader que las conecta entre sí.
require_once AP_PLUGIN_DIR . 'includes/class-helpers.php';
require_once AP_PLUGIN_DIR . 'includes/class-security.php';
require_once AP_PLUGIN_DIR . 'includes/class-database.php';
require_once AP_PLUGIN_DIR . 'includes/class-xlsx-writer.php';
require_once AP_PLUGIN_DIR . 'includes/class-reminders.php';
require_once AP_PLUGIN_DIR . 'includes/class-reminders-admin.php';
require_once AP_PLUGIN_DIR . 'includes/class-frontend.php';
require_once AP_PLUGIN_DIR . 'includes/class-ajax.php';
require_once AP_PLUGIN_DIR . 'includes/class-admin.php';
require_once AP_PLUGIN_DIR . 'includes/class-loader.php';

/**
 * Arranca el plugin una vez que todos los plugins están cargados,
 * garantizando que dependencias externas (roles, otros plugins) ya existen.
 */
function ap_areas_asignadas_bootstrap(): void {
	load_plugin_textdomain(
		AP_TEXT_DOMAIN,
		false,
		dirname( plugin_basename( AP_PLUGIN_FILE ) ) . '/languages'
	);

	$loader = new AP_Loader();
	$loader->run();
}
add_action( 'plugins_loaded', 'ap_areas_asignadas_bootstrap' );
