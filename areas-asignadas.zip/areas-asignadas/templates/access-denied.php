<?php
/**
 * Vista: acceso restringido (usuario sin rol empresa_admin).
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="ap-wrap">
	<div class="ap-denied">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
			<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
		</svg>
		<h3><?php esc_html_e( 'Acceso restringido', AP_TEXT_DOMAIN ); ?></h3>
		<p><?php esc_html_e( 'No tienes los permisos necesarios para acceder a este módulo.', AP_TEXT_DOMAIN ); ?></p>
	</div>
</div>
