<?php
/**
 * Parcial: modal «Recordar registro», de dos pasos (selección y confirmación).
 *
 * Es un único modal reutilizado por los dos puntos de entrada: el menú
 * "Acciones" del listado de áreas (todas las áreas del grupo, con filtro por
 * área) y el del modal de usuarios de un área (solo esa área, sin ese
 * filtro). El JS decide qué controles mostrar según desde dónde se abra; la
 * tabla, la selección y el envío son los mismos en ambos casos.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-recordar" class="ap-modal-overlay ap-modal-recordar-overlay" hidden aria-modal="true" role="dialog" aria-labelledby="ap-recordar-titulo">
	<div class="ap-modal ap-modal-recordar">

		<div class="ap-modal-head">
			<h3 class="ap-modal-title" id="ap-recordar-titulo"><?php esc_html_e( 'Recordar registro', AP_TEXT_DOMAIN ); ?></h3>
			<button class="ap-modal-close" id="ap-recordar-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>
		</div>

		<!-- ───────────── Paso 1: selección ───────────── -->
		<div class="ap-recordar-paso" id="ap-recordar-paso-1">

			<p class="ap-recordar-intro">
				<?php esc_html_e( 'Usuarios que todavía no han completado su perfil. Selecciona a quiénes quieres recordarles que terminen su registro.', AP_TEXT_DOMAIN ); ?>
			</p>

			<div class="ap-recordar-filtros">
				<div class="ap-search-wrap ap-recordar-buscador">
					<input type="text" id="ap-recordar-search" class="ap-search" placeholder="<?php esc_attr_e( 'Buscar por correo electrónico…', AP_TEXT_DOMAIN ); ?>" autocomplete="off">
					<span class="ap-search-icon" aria-hidden="true">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
						</svg>
					</span>
				</div>

				<select id="ap-recordar-filtro-area" class="ap-modal-select" hidden>
					<option value="0"><?php esc_html_e( 'Todas las áreas', AP_TEXT_DOMAIN ); ?></option>
				</select>

				<select id="ap-recordar-filtro-recordatorio" class="ap-modal-select">
					<option value="todos"><?php esc_html_e( 'Todos los recordatorios', AP_TEXT_DOMAIN ); ?></option>
					<option value="sin_recordatorios"><?php esc_html_e( 'Sin recordatorios', AP_TEXT_DOMAIN ); ?></option>
					<option value="rango"><?php esc_html_e( 'Rango de fechas', AP_TEXT_DOMAIN ); ?></option>
				</select>
			</div>

			<div class="ap-recordar-rango" id="ap-recordar-rango" hidden>
				<label for="ap-recordar-desde"><?php esc_html_e( 'Desde', AP_TEXT_DOMAIN ); ?></label>
				<input type="date" id="ap-recordar-desde" class="ap-modal-select">
				<label for="ap-recordar-hasta"><?php esc_html_e( 'Hasta', AP_TEXT_DOMAIN ); ?></label>
				<input type="date" id="ap-recordar-hasta" class="ap-modal-select">
			</div>

			<div class="ap-recordar-meta">
				<span id="ap-recordar-conteo" class="ap-modal-count-info"></span>
				<span id="ap-recordar-seleccionados" class="ap-recordar-badge" hidden></span>
			</div>

			<div class="ap-modal-scroll ap-recordar-scroll">
				<div id="ap-recordar-tabla"></div>
			</div>

			<div class="ap-modal-crear-footer">
				<button type="button" class="ap-btn-secundario" id="ap-recordar-cancelar"><?php esc_html_e( 'Cancelar', AP_TEXT_DOMAIN ); ?></button>
				<button type="button" class="ap-btn-primario" id="ap-recordar-siguiente" disabled>
					<?php esc_html_e( 'Siguiente', AP_TEXT_DOMAIN ); ?>
				</button>
			</div>
		</div>

		<!-- ───────────── Paso 2: confirmación ───────────── -->
		<div class="ap-recordar-paso" id="ap-recordar-paso-2" hidden>

			<p class="ap-recordar-intro" id="ap-recordar-resumen"></p>

			<div class="ap-modal-scroll ap-recordar-scroll">
				<div id="ap-recordar-confirmacion"></div>
			</div>

			<p class="ap-crear-error" id="ap-recordar-error" hidden></p>

			<div class="ap-modal-crear-footer">
				<button type="button" class="ap-btn-secundario" id="ap-recordar-volver"><?php esc_html_e( 'Volver', AP_TEXT_DOMAIN ); ?></button>
				<button type="button" class="ap-btn-primario" id="ap-recordar-enviar">
					<svg class="ap-crear-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
						<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
					</svg>
					<span id="ap-recordar-enviar-texto"><?php esc_html_e( 'Enviar recordatorios', AP_TEXT_DOMAIN ); ?></span>
				</button>
			</div>
		</div>

	</div>
</div>
