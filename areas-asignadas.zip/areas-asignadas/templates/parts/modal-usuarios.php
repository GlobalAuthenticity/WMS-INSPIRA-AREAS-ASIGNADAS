<?php
/**
 * Parcial: shell del modal "Ver usuarios". El contenido interno (búsqueda,
 * filtros, tabla y paginación) lo rellena assets/js/areas-asignadas.js tras
 * consultar el endpoint AJAX ap_get_usuarios_area.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-overlay" class="ap-modal-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal">
		<div class="ap-modal-head">
			<h3 class="ap-modal-title" id="ap-modal-area-nombre"></h3>
			<div class="ap-modal-head-right">
				<div class="ap-dropdown" id="ap-modal-acciones-dropdown">
					<button type="button" id="ap-modal-btn-acciones" class="ap-btn-agregar-usuario ap-btn-dropdown-toggle" aria-haspopup="true" aria-expanded="false">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/>
							<line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/>
							<line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/>
							<line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>
						</svg>
						<?php esc_html_e( 'Acciones', AP_TEXT_DOMAIN ); ?>
						<svg class="ap-dropdown-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<polyline points="6 9 12 15 18 9"/>
						</svg>
					</button>

					<div class="ap-dropdown-menu ap-dropdown-menu-right" id="ap-modal-acciones-menu" hidden>
						<button type="button" id="ap-btn-agregar-usuario" class="ap-dropdown-item">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
								<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
								<circle cx="8.5" cy="7" r="4"/>
								<line x1="20" y1="8" x2="20" y2="14"/>
								<line x1="23" y1="11" x2="17" y2="11"/>
							</svg>
							<?php esc_html_e( 'Agregar usuario', AP_TEXT_DOMAIN ); ?>
						</button>
						<button type="button" id="ap-btn-descargar-estado-area" class="ap-dropdown-item">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
								<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
								<polyline points="7 10 12 15 17 10"/>
								<line x1="12" y1="15" x2="12" y2="3"/>
							</svg>
							<span id="ap-descargar-estado-area-texto"><?php esc_html_e( 'Descargar estado de usuario', AP_TEXT_DOMAIN ); ?></span>
						</button>
						<button type="button" id="ap-btn-recordar-registro-area" class="ap-dropdown-item">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
								<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
								<path d="M13.73 21a2 2 0 0 1-3.46 0"/>
							</svg>
							<?php esc_html_e( 'Recordar registro', AP_TEXT_DOMAIN ); ?>
						</button>
					</div>
				</div>
				<span class="ap-modal-disponibles" id="ap-modal-disponibles"></span>
				<button class="ap-modal-close" id="ap-modal-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>
			</div>
		</div>
		<div class="ap-modal-body" id="ap-modal-body">
			<div class="ap-modal-loading">
				<svg class="ap-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
					<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
				</svg>
				<span><?php esc_html_e( 'Cargando usuarios…', AP_TEXT_DOMAIN ); ?></span>
			</div>
		</div>
	</div>
</div>
