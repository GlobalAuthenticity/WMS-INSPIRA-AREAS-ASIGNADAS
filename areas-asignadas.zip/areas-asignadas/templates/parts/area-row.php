<?php
/**
 * Parcial: una fila de la tabla de áreas.
 *
 * @package AreasAsignadas
 *
 * @var array<string,mixed> $area Fila cruda proveniente de AP_Database::get_areas_by_grupo().
 */

defined( 'ABSPATH' ) || exit;

$nombre            = esc_html( $area['nombre'] );
$usados            = (int) $area['cupos_usados'];
$cupo              = (int) $area['cupo'];
$estado            = esc_html( $area['estado'] );
$estado_lower      = strtolower( $area['estado'] );
$pct               = $cupo > 0 ? min( 100, (int) round( $usados / $cupo * 100 ) ) : 0;
$fecha             = AP_Helpers::format_fecha_expiracion( (string) $area['fecha_expiracion'] );
$usuarios_con_test = (int) $area['usuarios_con_test'];

// El botón de informe se deshabilita si no hay usuarios inscritos o si
// ninguno ha completado el test todavía (no hay datos que informar).
$btn_disabled = 0 === $usados || 0 === $usuarios_con_test;
$sin_usuarios = 0 === $usados ? '1' : '0';
$sin_test     = ( $usados > 0 && 0 === $usuarios_con_test ) ? '1' : '0';
?>
<tr data-area-id="<?php echo (int) $area['id']; ?>" data-nombre="<?php echo esc_attr( strtolower( $nombre ) ); ?>" data-estado="<?php echo esc_attr( $estado_lower ); ?>">
	<td>
		<span class="ap-name"><?php echo $nombre; ?></span>
		<span class="ap-date<?php echo $fecha ? '' : ' ap-no-date'; ?>">
			<?php echo $fecha ? esc_html( $fecha ) : esc_html__( 'Sin fecha de expiración', AP_TEXT_DOMAIN ); ?>
		</span>
	</td>
	<td>
		<div class="ap-cupos">
			<span class="ap-cupos-num"><b><?php echo $usados; ?></b> / <small><?php echo $cupo; ?></small></span>
			<div class="ap-bar"><div class="ap-fill <?php echo esc_attr( AP_Helpers::bar_class_for_cupo( $pct ) ); ?>" style="width:<?php echo $pct; ?>%"></div></div>
			<span class="ap-pct"><?php echo $pct; ?>% <?php esc_html_e( 'ocupado', AP_TEXT_DOMAIN ); ?></span>
		</div>
	</td>
	<td><span class="ap-badge ap-badge-<?php echo esc_attr( $estado_lower ); ?>"><?php echo $estado; ?></span></td>
	<td class="ap-hide-sm">
		<button
			class="ap-btn-usuarios"
			data-area-id="<?php echo (int) $area['id']; ?>"
			data-area-nombre="<?php echo esc_attr( $nombre ); ?>"
			data-area-usados="<?php echo $usados; ?>"
			data-area-cupo="<?php echo $cupo; ?>"
		>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
				<circle cx="9" cy="7" r="4"/>
				<path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
				<path d="M16 3.13a4 4 0 0 1 0 7.75"/>
			</svg>
			<?php esc_html_e( 'Ver usuarios', AP_TEXT_DOMAIN ); ?>
		</button>
	</td>
	<td class="ap-hide-sm">
		<button
			class="ap-btn-resultados ap-btn-resultados-area<?php echo $btn_disabled ? ' ap-btn-resultados-disabled' : ''; ?>"
			data-area-id="<?php echo (int) $area['id']; ?>"
			data-area-nombre="<?php echo esc_attr( $nombre ); ?>"
			data-sin-usuarios="<?php echo esc_attr( $sin_usuarios ); ?>"
			data-sin-test="<?php echo esc_attr( $sin_test ); ?>"
		>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
				<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
				<polyline points="14 2 14 8 20 8"/>
				<line x1="9" y1="13" x2="15" y2="13"/>
				<line x1="9" y1="17" x2="15" y2="17"/>
			</svg>
			<?php esc_html_e( 'Informe general', AP_TEXT_DOMAIN ); ?>
		</button>
	</td>
</tr>
