<?php
/**
 * Parcial: modal de espera mientras se genera y descarga un informe en PDF.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-pdf" class="ap-modal-overlay ap-modal-pdf-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal ap-modal-pdf">
		<div class="ap-pdf-waiting">
			<svg class="ap-spinner ap-spinner-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
			</svg>
			<p class="ap-pdf-waiting-text" id="ap-pdf-waiting-text"><?php esc_html_e( 'Estamos descargando tu informe.', AP_TEXT_DOMAIN ); ?></p>
		</div>
	</div>
</div>
