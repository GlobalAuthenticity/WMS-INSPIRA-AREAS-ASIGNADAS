<?php
/**
 * Parcial: modal para crear un usuario nuevo dentro del área que está
 * abierta en el modal "Ver usuarios". Solo pide el correo; el resto de
 * datos (login, nicename, contraseña) se generan en el servidor
 * (ver AP_Ajax::crear_usuario()).
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-crear-overlay" class="ap-modal-overlay ap-modal-crear-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal ap-modal-crear">
		<div class="ap-modal-head">
			<h3 class="ap-modal-title"><?php esc_html_e( 'Agregar usuario', AP_TEXT_DOMAIN ); ?></h3>
			<button class="ap-modal-close" id="ap-modal-crear-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>
		</div>
		<div class="ap-modal-crear-body">
			<label class="ap-crear-label" for="ap-crear-correo"><?php esc_html_e( 'Correo electrónico', AP_TEXT_DOMAIN ); ?></label>
			<input type="email" id="ap-crear-correo" class="ap-crear-input" placeholder="usuario@correo.com" autocomplete="off">
			<p class="ap-crear-error" id="ap-crear-error" hidden></p>
		</div>
		<div class="ap-modal-crear-footer">
			<button type="button" class="ap-btn-secundario" id="ap-crear-cancelar"><?php esc_html_e( 'Cancelar', AP_TEXT_DOMAIN ); ?></button>
			<button type="button" class="ap-btn-primario" id="ap-crear-aceptar">
				<svg class="ap-crear-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
					<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
				</svg>
				<span id="ap-crear-aceptar-texto"><?php esc_html_e( 'Aceptar', AP_TEXT_DOMAIN ); ?></span>
			</button>
		</div>
	</div>
</div>
