<?php
/**
 * Parcial: estado vacío cuando el grupo no tiene áreas asignadas.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="ap-empty">
	<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
		<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
		<polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/>
	</svg>
	<p><?php esc_html_e( 'No tienes áreas asignadas actualmente.', AP_TEXT_DOMAIN ); ?></p>
</div>
