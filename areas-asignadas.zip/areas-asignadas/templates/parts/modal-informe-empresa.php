<?php
/**
 * Parcial: modal "Informe general" (consolidado de toda la empresa).
 *
 * Al abrirse, el JS consulta `ap_get_resumen_empresa` y pinta aquí el
 * resumen de participación por área (integrantes / completaron test / %).
 * "Generar informe general" dispara `ap_get_resultados_empresa_pdf` y
 * reutiliza el mismo flujo de descarga que los informes por área/usuario
 * (ver enviarAlWebhookYDescargar() en areas-asignadas.js).
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-informe-empresa" class="ap-modal-overlay ap-modal-informe-empresa-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal ap-modal-informe-empresa">
		<div class="ap-modal-head">
			<div class="ap-informe-empresa-head-text">
				<h3 class="ap-modal-title"><?php esc_html_e( 'Informe general de la empresa', AP_TEXT_DOMAIN ); ?></h3>
				<p class="ap-informe-empresa-subtitulo" id="ap-informe-empresa-subtitulo"></p>
			</div>
			<button class="ap-modal-close" id="ap-modal-informe-empresa-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>
		</div>

		<div class="ap-informe-empresa-body" id="ap-informe-empresa-body">
			<div class="ap-modal-loading">
				<svg class="ap-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
					<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
				</svg>
				<span><?php esc_html_e( 'Cargando resumen de áreas…', AP_TEXT_DOMAIN ); ?></span>
			</div>
		</div>

		<div class="ap-informe-empresa-footer">
			<span class="ap-informe-empresa-footer-caption" id="ap-informe-empresa-footer-caption"></span>
			<div class="ap-informe-empresa-footer-buttons">
				<button type="button" class="ap-btn-secundario" id="ap-informe-empresa-cancelar"><?php esc_html_e( 'Cancelar', AP_TEXT_DOMAIN ); ?></button>
				<button type="button" class="ap-btn-primario" id="ap-informe-empresa-generar" disabled>
					<svg class="ap-crear-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
						<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
					</svg>
					<span id="ap-informe-empresa-generar-texto"><?php esc_html_e( 'Generar informe general', AP_TEXT_DOMAIN ); ?></span>
				</button>
			</div>
		</div>
	</div>
</div>
