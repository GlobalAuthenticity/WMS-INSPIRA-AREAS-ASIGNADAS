<?php
/**
 * Parcial: modal "Exportar usuarios a Excel", abierto desde el menú
 * "Acciones" → "Descargar estado de usuario". Lista las áreas del grupo
 * actual (mismo array $areas que ya recibe areas-list.php, sin volver a
 * consultarlas) para que el admin elija cuáles incluir en el .xlsx.
 *
 * @package AreasAsignadas
 *
 * @var array<int,array<string,mixed>> $areas Áreas del grupo actual (ver AP_Database::get_areas_by_grupo()).
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-exportar" class="ap-modal-overlay ap-modal-exportar-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal ap-modal-exportar">
		<div class="ap-modal-head">
			<h3 class="ap-modal-title"><?php esc_html_e( 'Exportar usuarios a Excel', AP_TEXT_DOMAIN ); ?></h3>
			<button class="ap-modal-close" id="ap-modal-exportar-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>
		</div>
		<div class="ap-modal-exportar-body">
			<label class="ap-exportar-all">
				<input type="checkbox" id="ap-exportar-select-all">
				<span><?php esc_html_e( 'Seleccionar todas las áreas', AP_TEXT_DOMAIN ); ?></span>
			</label>

			<div class="ap-exportar-list" id="ap-exportar-list">
				<?php foreach ( $areas as $area ) : ?>
					<label class="ap-exportar-item">
						<input type="checkbox" class="ap-exportar-area-checkbox" value="<?php echo (int) $area['id']; ?>">
						<span><?php echo esc_html( $area['nombre'] ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>

			<p class="ap-crear-error" id="ap-exportar-error" hidden></p>
		</div>
		<div class="ap-modal-crear-footer">
			<button type="button" class="ap-btn-secundario" id="ap-exportar-cancelar"><?php esc_html_e( 'Cancelar', AP_TEXT_DOMAIN ); ?></button>
			<button type="button" class="ap-btn-primario" id="ap-exportar-aceptar">
				<svg class="ap-crear-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
					<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
				</svg>
				<span id="ap-exportar-aceptar-texto"><?php esc_html_e( 'Exportar Excel', AP_TEXT_DOMAIN ); ?></span>
			</button>
		</div>
	</div>
</div>
