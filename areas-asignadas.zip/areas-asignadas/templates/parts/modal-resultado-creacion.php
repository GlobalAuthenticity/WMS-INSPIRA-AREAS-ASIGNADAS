<?php
/**
 * Parcial: shell del modal "Resultado de la creación". Se muestra siempre
 * que se intenta crear uno o varios usuarios (aunque sea uno solo): ícono
 * de estado, badges de resumen por categoría y, por cada correo, su
 * ícono de estado + motivo puntual (incluyendo el nombre del área cuando
 * el duplicado pertenece a la propia empresa del admin). El contenido
 * dinámico lo rellena assets/js/areas-asignadas.js tras terminar la
 * cadena de peticiones a ap_crear_usuario.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;
?>
<div id="ap-modal-resultado-overlay" class="ap-modal-overlay ap-modal-resultado-overlay" hidden aria-modal="true" role="dialog">
	<div class="ap-modal ap-modal-resultado">
		<button class="ap-modal-close ap-resultado-close" id="ap-modal-resultado-close" aria-label="<?php esc_attr_e( 'Cerrar', AP_TEXT_DOMAIN ); ?>">&#10005;</button>

		<div class="ap-resultado-header">
			<div class="ap-resultado-icono" aria-hidden="true">
				<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 12 9 17 20 6"></polyline></svg>
			</div>
			<h3 class="ap-resultado-titulo" id="ap-resultado-titulo"><?php esc_html_e( '¡Proceso completado!', AP_TEXT_DOMAIN ); ?></h3>
		</div>

		<div class="ap-resultado-badges" id="ap-resultado-badges"></div>
		<div class="ap-resultado-body" id="ap-resultado-body"></div>

		<div class="ap-resultado-footer">
			<button type="button" class="ap-btn-primario" id="ap-resultado-aceptar"><?php esc_html_e( 'Aceptar', AP_TEXT_DOMAIN ); ?></button>
		</div>
	</div>
</div>
