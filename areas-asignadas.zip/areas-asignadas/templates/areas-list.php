<?php
/**
 * Vista principal del shortcode: listado de áreas + modales.
 *
 * @package AreasAsignadas
 *
 * @var array<int,array<string,mixed>> $areas Áreas del grupo actual (ver AP_Database::get_areas_by_grupo()).
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="ap-wrap" id="ap-root">

	<div class="ap-header">
		<h2 class="ap-title">
			<?php esc_html_e( 'Áreas asignadas', AP_TEXT_DOMAIN ); ?>
			<span class="ap-count" id="ap-count"><?php echo count( $areas ); ?></span>
		</h2>
		<div class="ap-toolbar">
			<div class="ap-dropdown" id="ap-acciones-dropdown">
				<button type="button" id="ap-btn-acciones" class="ap-btn-resultados ap-btn-dropdown-toggle"<?php echo empty( $areas ) ? ' disabled' : ''; ?> aria-haspopup="true" aria-expanded="false">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
						<polyline points="14 2 14 8 20 8"/>
						<line x1="9" y1="13" x2="15" y2="13"/>
						<line x1="9" y1="17" x2="15" y2="17"/>
					</svg>
					<?php esc_html_e( 'Acciones', AP_TEXT_DOMAIN ); ?>
					<svg class="ap-dropdown-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
						<polyline points="6 9 12 15 18 9"/>
					</svg>
				</button>

				<div class="ap-dropdown-menu" id="ap-acciones-menu" hidden>
					<button type="button" id="ap-btn-informe-grupo" class="ap-dropdown-item">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
							<polyline points="14 2 14 8 20 8"/>
							<line x1="9" y1="13" x2="15" y2="13"/>
							<line x1="9" y1="17" x2="15" y2="17"/>
						</svg>
						<?php esc_html_e( 'Informe general', AP_TEXT_DOMAIN ); ?>
					</button>
					<button type="button" id="ap-btn-descargar-estado" class="ap-dropdown-item">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
							<polyline points="7 10 12 15 17 10"/>
							<line x1="12" y1="15" x2="12" y2="3"/>
						</svg>
						<?php esc_html_e( 'Descargar estado de usuario', AP_TEXT_DOMAIN ); ?>
					</button>
					<button type="button" id="ap-btn-recordar-registro" class="ap-dropdown-item">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
							<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
							<path d="M13.73 21a2 2 0 0 1-3.46 0"/>
						</svg>
						<?php esc_html_e( 'Recordar registro', AP_TEXT_DOMAIN ); ?>
					</button>
				</div>
			</div>

			<div class="ap-search-wrap">
				<input type="text" id="ap-search" class="ap-search" placeholder="<?php esc_attr_e( 'Buscar…', AP_TEXT_DOMAIN ); ?>" autocomplete="off">
				<span class="ap-search-icon" aria-hidden="true">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
					</svg>
				</span>
			</div>
		</div>
	</div>

	<div class="ap-table-wrap">
		<?php if ( empty( $areas ) ) : ?>
			<?php include AP_PLUGIN_DIR . 'templates/parts/empty-state.php'; ?>
		<?php else : ?>
			<table class="ap-table" id="ap-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Área', AP_TEXT_DOMAIN ); ?></th>
						<th><?php esc_html_e( 'Cupos', AP_TEXT_DOMAIN ); ?></th>
						<th><?php esc_html_e( 'Estado', AP_TEXT_DOMAIN ); ?></th>
						<th class="ap-hide-sm"><?php esc_html_e( 'Usuarios', AP_TEXT_DOMAIN ); ?></th>
						<th class="ap-hide-sm"><?php esc_html_e( 'Informe', AP_TEXT_DOMAIN ); ?></th>
					</tr>
				</thead>
				<tbody id="ap-tbody">
					<?php foreach ( $areas as $area ) : ?>
						<?php include AP_PLUGIN_DIR . 'templates/parts/area-row.php'; ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<div id="ap-no-results" class="ap-no-results" hidden>
		<p><?php esc_html_e( 'No se encontraron áreas con ese criterio.', AP_TEXT_DOMAIN ); ?></p>
	</div>

	<div class="ap-pagination" id="ap-pager"></div>

</div>

<?php include AP_PLUGIN_DIR . 'templates/parts/modal-usuarios.php'; ?>
<?php include AP_PLUGIN_DIR . 'templates/parts/modal-crear-usuario.php'; ?>
<?php include AP_PLUGIN_DIR . 'templates/parts/modal-pdf.php'; ?>
<?php include AP_PLUGIN_DIR . 'templates/parts/modal-exportar-excel.php'; ?>
<?php include AP_PLUGIN_DIR . 'templates/parts/modal-recordar-registro.php'; ?>
