=== Áreas Asignadas ===
Contributors: tuusuario
Tags: reportes, learndash, ajax, empresa
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 2.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Panel para administradores de empresa: áreas asignadas, usuarios, progreso de test e informes en PDF.

== Description ==

Este plugin expone el shortcode `[areas_asignadas]`, visible únicamente para
usuarios con el rol `empresa_admin`. Permite:

* Ver las áreas asignadas a la empresa, con cupos, estado y fecha de expiración.
* Buscar y paginar el listado de áreas.
* Ver los usuarios de cada área, con búsqueda, filtro por estado del test y
  paginación resueltos en el servidor (no en memoria del navegador).
* Generar informes en PDF por usuario o por área completa, a través de un
  webhook externo.
* Crear usuarios nuevos directamente dentro de un área, a partir únicamente
  de su correo electrónico, con réplica automática en wmslatam.com.

== Requisitos externos ==

Este plugin asume que el sitio ya cuenta con:

* Las tablas personalizadas `{prefix}areas` y `{prefix}user_members`.
* Las funciones `get_results_area( $area_id )` y `get_results_user( $user_id )`,
  definidas por el sistema de evaluaciones del sitio (fuera del alcance de
  este plugin).
* SweetAlert2 (`Swal`) cargado globalmente para los diálogos de confirmación.
  Si no está disponible, el plugin recurre a `alert()` nativo como respaldo.
* Un endpoint webhook accesible en
  `https://api.efrenmartinezortiz-ia.com/webhook/pdf_aprobandome` que recibe
  los resultados del test y devuelve `{ pdfUrl: "..." }`.
* Un endpoint accesible en `https://wmslatam.com/wp-json/wms/v1/create-user`
  que replica cada usuario creado desde el botón "Agregar usuario". Si su
  respuesta trae `area_octagono_id`, se encadena automáticamente el alta en
  `https://octagono.wmslatam.com/wp-json/octagono/v1/create-user-area`.

== Arquitectura ==

El plugin sigue el principio de responsabilidad única: cada clase en
`includes/` tiene una única razón para cambiar.

* `AP_Loader`      — instancia y conecta el resto de módulos.
* `AP_Security`    — verificación de rol y de nonces de AJAX.
* `AP_Database`    — toda interacción con `$wpdb` (única fuente de SQL).
* `AP_Frontend`    — registro del shortcode, renderizado de plantillas y
                      carga condicional de CSS/JS.
* `AP_Ajax`        — endpoints `wp_ajax_*`, validación de entrada y
                      delegación a `AP_Database`.
* `AP_Admin`       — integraciones con wp-admin (punto de extensión para
                      una futura pantalla de configuración).
* `AP_Helpers`     — utilidades de formato sin efectos secundarios.

La presentación vive en `templates/` (PHP con HTML mínimo, sin lógica de
negocio); el comportamiento de cliente vive en `assets/js/`; los estilos en
`assets/css/`. Ningún archivo mezcla las tres capas.

== Changelog ==

= 2.4.0 =
* Nuevo: «Recordar registro», disponible en el menú «Acciones» del listado de
  áreas y en el del modal de usuarios de un área. Abre un modal de dos pasos
  (selección y confirmación) con los usuarios que aún no han completado su
  perfil, con buscador por correo, filtro por área (solo en el listado) y
  filtro por último recordatorio (todos / sin recordatorios / rango de
  fechas). La selección se conserva al cambiar de filtro.
* Nuevo: el envío sale del servidor de WordPress en una sola petición POST
  con el array de correos sin duplicados. La fecha del último recordatorio de
  cada usuario se guarda solo cuando el webhook acepta la solicitud, y se
  muestra en hora de Colombia (dd/mm/yyyy hh:mm:ss AM/PM).
* Nuevo: pantalla «Áreas asignadas → Recordatorios de registro» en wp-admin
  (solo para administradores) para configurar la URL del webhook y probarla
  con un correo concreto, viendo el código HTTP y la respuesta. La prueba no
  altera la fecha de ningún usuario.
* Seguridad: el recordatorio de test pendiente (botón de campana) ya no llama
  al webhook desde el navegador. Ahora pasa por `ap_enviar_recordatorio_test`,
  así que su URL deja de estar a la vista en el JS público y el correo lo
  resuelve el servidor tras comprobar que el usuario pertenece a la empresa.


= 2.3.1 =
* Corregido: el avance de los usuarios aparecía en 0% cuando el curso estaba
  en progreso pero sin terminar. Ahora se lee el avance real de LearnDash
  (`_sfwd-course_progress` / learndash_course_progress()), el mismo que ve el
  alumno en su panel. Afecta al modal "Ver usuarios" y a la columna "Avance
  general" del Excel.
* Corregido: los cursos a los que el usuario accede por un grupo de
  LearnDash ahora también se cuentan (antes solo los de inscripción directa).

= 2.3.0 =
* Nuevo: el webhook `webhook/creacion-inspira-wms` se dispara siempre que la
  API de WMS confirme el alta (`success: true`), tenga o no el usuario un
  área en Octágono. Solo si además trae un `area_octagono_id` con valor real
  se encadena, adicionalmente: alta en
  `octagono.wmslatam.com/.../create-user-area` → aviso final
  `webhook/creacion-inspira-octagono`. Un fallo en cualquier eslabón detiene
  los siguientes pasos sin afectar al usuario ya creado localmente.
* Nuevo: botón "Agregar usuario" en la cabecera del modal "Ver usuarios".
  Abre un modal que solo pide el correo electrónico; si ya existe un usuario
  con ese correo, el proceso se detiene sin crear nada.
* Si el correo no existe, se crea el usuario en WordPress con contraseña
  aleatoria, `first_name`/`nickname` tomados del nombre del correo (antes
  del @) y `user_nicename` igual al valor por defecto de WordPress más un
  sufijo aleatorio.
* Se inscribe automáticamente al nuevo usuario en `{prefix}user_members`
  para el área desde la que se creó, con `status = 'ACTIVO'`, `days = 0` y
  `fecha_final_membresia` heredada de la fecha de expiración del área.
* El alta se replica en `https://wmslatam.com/wp-json/wms/v1/create-user`
  (correo, contraseña, id de área y `tipo_programa = 'inspira'`). Si esa
  llamada falla, el usuario y su membresía ya quedaron creados localmente;
  solo se avisa de una sincronización pendiente.
* Los cupos del área se actualizan en pantalla (fila de la tabla principal
  y badge del modal) sin recargar la página.
* El botón "Agregar usuario" se deshabilita cuando el área ya alcanzó su
  cupo máximo; la validación definitiva ocurre siempre en el servidor
  (`AP_Ajax::crear_usuario`), no solo en la UI.

= 2.2.0 =
* Nuevo: botón discreto de "enviar recordatorio" junto al badge de estado
  del test cuando este es INCOMPLETO. Envía nombre y correo del usuario de
  la fila a un webhook externo, con estado de carga (spinner) y notificación
  de éxito/error mediante SweetAlert2 (con respaldo a alert() nativo).
* Corrección: se sube el z-index de `.swal2-container` por encima del
  overlay del modal de usuarios y del modal de PDF, para que los diálogos y
  toasts de SweetAlert2 no queden ocultos detrás del fondo oscurecido
  cuando se disparan con un modal del plugin abierto.

= 2.1.0 =
* Rediseño completo del modal "Ver usuarios": cabecera compacta, barra de
  herramientas unificada (buscador + filtros alineados en una sola fila),
  cabecera de tabla fija (sticky) y paginación anclada al pie mientras solo
  la lista central hace scroll.
* En pantallas angostas (≤640px) la tabla se convierte en tarjetas apiladas
  en vez de forzar scroll horizontal, mejorando la legibilidad en móvil.
* Sin cambios funcionales: misma búsqueda, mismos filtros, misma paginación
  y misma generación de informes en PDF.

= 2.0.1 =
* Corrección: el CSS/JS ahora se encolan desde el propio callback del
  shortcode en lugar de depender de has_shortcode() sobre post_content.
  Esto arregla la pérdida de estilos cuando el shortcode se inserta vía
  widget, Elementor, un bloque reutilizable o una plantilla, en vez de
  como texto plano en el contenido de la entrada/página.

= 2.0.0 =
* Refactorización completa a arquitectura de plugin modular (antes era un
  único archivo de shortcode con PHP, JS y CSS mezclados).
* Corrección de seguridad: `ap_get_resultados_pdf` ahora valida que el
  usuario solicitado pertenezca a un área del grupo del admin autenticado
  antes de exponer sus resultados (previene IDOR entre empresas distintas).
* Búsqueda, filtro por estado del test y paginación de usuarios resueltos en
  el servidor en lugar de cargarse todos en memoria del navegador.
* CSS y JS extraídos a archivos propios, cargados únicamente en páginas que
  contienen el shortcode.
* Textos preparados para traducción bajo el text domain `areas-asignadas`.
* Sin cambios de comportamiento visible para el usuario final: misma UI,
  mismos flujos de generación de PDF.

= 1.x =
* Versión inicial como shortcode suelto embebido en el tema.
