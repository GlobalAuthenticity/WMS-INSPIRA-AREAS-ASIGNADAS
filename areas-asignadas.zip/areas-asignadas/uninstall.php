<?php
/**
 * Se ejecuta cuando el plugin se desinstala desde el panel de WordPress
 * (Plugins → Eliminar), no en cada desactivación.
 *
 * El plugin no crea opciones propias, tablas ni tareas programadas: reutiliza
 * las tablas {prefix}areas y {prefix}user_members administradas por otro
 * sistema, por lo que no hay nada que limpiar aquí. Se deja el archivo como
 * punto de extensión explícito para el futuro (p. ej. si se añaden opciones
 * en wp_options bajo un prefijo `ap_`).
 *
 * @package AreasAsignadas
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Ejemplo de extensión futura:
// delete_option( 'ap_areas_asignadas_settings' );
