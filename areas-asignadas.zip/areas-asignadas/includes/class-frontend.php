<?php
/**
 * Registro del shortcode público, renderizado de plantillas y carga de
 * CSS/JS del frontend.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Frontend {

	const SHORTCODE_TAG = 'areas_asignadas';
	const ASSET_HANDLE   = 'ap-areas-asignadas';

	/** @var AP_Database */
	private $database;

	public function __construct( AP_Database $database ) {
		$this->database = $database;
	}

	public function register_hooks(): void {
		add_shortcode( self::SHORTCODE_TAG, [ $this, 'render_shortcode' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );

		// Respaldo: si el shortcode se ejecuta después de que wp_head() ya
		// imprimió los estilos (habitual cuando el shortcode viene de un
		// widget, Elementor, un bloque reutilizable o una plantilla en vez
		// de texto plano en post_content), este hook imprime el CSS igual
		// justo antes de cerrar el body.
		add_action( 'wp_footer', [ $this, 'print_late_styles' ], 1 );
	}

	/**
	 * Registra (sin encolar) los assets. Encolar aquí basándose en
	 * has_shortcode() no es fiable: el shortcode puede vivir fuera de
	 * post_content. El encolado real ocurre en render_shortcode(), que se
	 * ejecuta únicamente cuando el shortcode realmente se procesa.
	 */
	public function register_assets(): void {
		wp_register_style(
			self::ASSET_HANDLE,
			AP_PLUGIN_URL . 'assets/css/areas-asignadas.css',
			[],
			AP_VERSION
		);

		wp_register_script(
			self::ASSET_HANDLE,
			AP_PLUGIN_URL . 'assets/js/areas-asignadas.js',
			[],
			AP_VERSION,
			true
		);
	}

	/**
	 * Callback del shortcode [areas_asignadas].
	 */
	public function render_shortcode(): string {
		$this->enqueue_assets();

		if ( ! AP_Security::current_user_is_empresa_admin() ) {
			return $this->render_template( 'access-denied' );
		}

		$grupo_id = get_current_user_id();
		$areas    = $this->database->get_areas_by_grupo( $grupo_id );

		return $this->render_template( 'areas-list', [ 'areas' => $areas ] );
	}

	/**
	 * Encola CSS/JS y localiza el objeto apAjax. Se llama desde dentro del
	 * shortcode para garantizar que se cargan sin importar dónde esté
	 * insertado (post_content, widget, Elementor, plantilla, etc.).
	 */
	private function enqueue_assets(): void {
		if ( ! wp_style_is( self::ASSET_HANDLE, 'registered' ) ) {
			// Red de seguridad por si algún tema dispara el shortcode antes
			// de wp_enqueue_scripts (poco común, pero evita un fatal).
			$this->register_assets();
		}

		wp_enqueue_style( self::ASSET_HANDLE );
		wp_enqueue_script( self::ASSET_HANDLE );

		wp_localize_script( self::ASSET_HANDLE, 'apAjax', [
			'url'   => admin_url( 'admin-ajax.php' ),
			'nonce' => AP_Security::create_nonce(),
			// Webhook de PDF resuelto en servidor por el plugin «Webhooks de
			// generación de PDF (Inspira)». Si ese plugin no está activo se
			// manda cadena vacía y el JS cae al literal que lleva dentro,
			// que es el comportamiento que tenía antes.
			//
			// No se usa AP_Settings::get() aquí: esa clase existe en el
			// repositorio pero no la carga ni areas-asignadas.php ni
			// AP_Loader, así que en tiempo de ejecución no está definida y
			// llamarla provoca un fatal en el shortcode.
			'webhook_pdf' => function_exists( 'ipw_get_webhook' ) ? ipw_get_webhook( 'area' ) : '',
			'i18n'  => $this->get_localized_strings(),
		] );
	}

	/**
	 * Imprime el CSS del plugin en el footer si quedó encolado pero nunca
	 * se imprimió en el head (ver comentario en register_hooks()).
	 */
	public function print_late_styles(): void {
		if ( wp_style_is( self::ASSET_HANDLE, 'enqueued' ) && ! wp_style_is( self::ASSET_HANDLE, 'done' ) ) {
			wp_print_styles( [ self::ASSET_HANDLE ] );
		}
	}

	/**
	 * Cadenas usadas por el JS del frontend. Centralizadas aquí para que
	 * viajen traducidas junto con el resto del plugin.
	 *
	 * @return array<string,string>
	 */
	private function get_localized_strings(): array {
		return [
			'cargando_usuarios'   => __( 'Cargando usuarios…', AP_TEXT_DOMAIN ),
			'sin_criterio'        => __( 'No se encontraron usuarios con ese criterio.', AP_TEXT_DOMAIN ),
			'sin_usuarios_area'   => __( 'Esta área no tiene usuarios asignados.', AP_TEXT_DOMAIN ),
			'error_carga'         => __( 'Error al cargar.', AP_TEXT_DOMAIN ),
			'error_red'           => __( 'Error de red.', AP_TEXT_DOMAIN ),
			'descargando_informe' => __( 'Estamos descargando tu informe.', AP_TEXT_DOMAIN ),
			'obteniendo_usuario'  => __( 'Obteniendo resultados del usuario…', AP_TEXT_DOMAIN ),
			'obteniendo_area'     => __( 'Obteniendo resultados del área…', AP_TEXT_DOMAIN ),
			'error_pdf'           => __( 'Ocurrió un error al generar el PDF.', AP_TEXT_DOMAIN ),
			'sin_usuarios_title'  => __( 'Sin usuarios registrados', AP_TEXT_DOMAIN ),
			'sin_usuarios_text'   => __( 'El informe no puede generarse sin usuarios registrados.', AP_TEXT_DOMAIN ),
			'sin_test_title'      => __( 'No es posible generar el informe', AP_TEXT_DOMAIN ),
			'sin_test_text'       => __( 'Ningún usuario ha completado el test, por lo que aún no hay resultados disponibles para generar el informe.', AP_TEXT_DOMAIN ),
			'entendido'           => __( 'Entendido', AP_TEXT_DOMAIN ),
			'completado'          => __( 'Completado', AP_TEXT_DOMAIN ),
			'incompleto'          => __( 'Incompleto', AP_TEXT_DOMAIN ),
			'perfil'              => __( 'Perfil', AP_TEXT_DOMAIN ),
			'perfil_completo'     => __( 'Completo', AP_TEXT_DOMAIN ),
			'perfil_incompleto'   => __( 'Incompleto', AP_TEXT_DOMAIN ),
			'ver_resultados'      => __( 'Ver resultados', AP_TEXT_DOMAIN ),
			'usuarios_en_total'   => __( 'usuario(s) en total', AP_TEXT_DOMAIN ),
			'de'                  => __( 'de', AP_TEXT_DOMAIN ),
			'enviar_recordatorio' => __( 'Enviar recordatorio', AP_TEXT_DOMAIN ),
			'recordatorio_enviado' => __( 'Recordatorio enviado correctamente.', AP_TEXT_DOMAIN ),
			'recordatorio_error'  => __( 'No se pudo enviar el recordatorio. Inténtalo de nuevo.', AP_TEXT_DOMAIN ),
			'agregar_usuario'     => __( 'Agregar usuario', AP_TEXT_DOMAIN ),
			'correo_invalido'     => __( 'Ingresa un correo electrónico válido.', AP_TEXT_DOMAIN ),
			'creando_usuario'     => __( 'Creando…', AP_TEXT_DOMAIN ),
			'usuario_creado'      => __( 'Usuario creado correctamente.', AP_TEXT_DOMAIN ),
			'usuario_creado_sync_pendiente' => __( 'Usuario creado. La sincronización con WMS falló; puede requerir revisión manual.', AP_TEXT_DOMAIN ),
			'error_crear_usuario' => __( 'No se pudo crear el usuario.', AP_TEXT_DOMAIN ),
			'area_llena_title'    => __( 'Cupo alcanzado', AP_TEXT_DOMAIN ),
			'area_llena_text'     => __( 'Esta área ya alcanzó su cupo máximo de usuarios.', AP_TEXT_DOMAIN ),
			'exportar_selecciona_area' => __( 'Selecciona al menos un área para exportar.', AP_TEXT_DOMAIN ),
			'exportando_excel'        => __( 'Exportando…', AP_TEXT_DOMAIN ),
			'error_exportar_excel'    => __( 'No se pudo generar el archivo Excel. Inténtalo de nuevo.', AP_TEXT_DOMAIN ),

			// Flujo «Recordar registro».
			'rec_cargando'        => __( 'Cargando usuarios…', AP_TEXT_DOMAIN ),
			'rec_sin_pendientes'  => __( 'Todos los usuarios completaron su perfil.', AP_TEXT_DOMAIN ),
			'rec_sin_pendientes_sub' => __( 'No hay nadie a quien recordarle que termine su registro.', AP_TEXT_DOMAIN ),
			'rec_sin_criterio'    => __( 'Ningún usuario coincide con los filtros aplicados.', AP_TEXT_DOMAIN ),
			'rec_todas_areas'     => __( 'Todas las áreas', AP_TEXT_DOMAIN ),
			'rec_col_usuario'     => __( 'Usuario', AP_TEXT_DOMAIN ),
			'rec_col_area'        => __( 'Área', AP_TEXT_DOMAIN ),
			'rec_col_ultimo'      => __( 'Último recordatorio', AP_TEXT_DOMAIN ),
			'rec_col_correo'      => __( 'Correo electrónico', AP_TEXT_DOMAIN ),
			'rec_sin_recordatorios' => __( 'Sin recordatorios', AP_TEXT_DOMAIN ),
			'rec_seleccionar_todos' => __( 'Seleccionar todos los resultados', AP_TEXT_DOMAIN ),
			'rec_seleccionados'   => __( 'seleccionado(s)', AP_TEXT_DOMAIN ),
			'rec_pendientes'      => __( 'usuario(s) sin completar su perfil', AP_TEXT_DOMAIN ),
			'rec_resumen'         => __( 'Se enviará un recordatorio a los siguientes usuarios:', AP_TEXT_DOMAIN ),
			'rec_enviando'        => __( 'Enviando…', AP_TEXT_DOMAIN ),
			'rec_exito'           => __( 'La solicitud de envío de recordatorios se procesó correctamente.', AP_TEXT_DOMAIN ),
			'rec_error'           => __( 'No se pudieron enviar los recordatorios. Revisa la configuración del webhook e inténtalo de nuevo.', AP_TEXT_DOMAIN ),
		];
	}

	/**
	 * Renderiza una plantilla de la carpeta templates/ con las variables dadas.
	 * Mantiene el HTML fuera de las clases de lógica.
	 *
	 * @param array<string,mixed> $vars
	 */
	private function render_template( string $name, array $vars = [] ): string {
		$path = AP_PLUGIN_DIR . 'templates/' . $name . '.php';

		if ( ! file_exists( $path ) ) {
			return '';
		}

		extract( $vars, EXTR_SKIP );

		ob_start();
		include $path;
		return ob_get_clean();
	}
}
