<?php
/**
 * Utilidades de formato sin dependencias de base de datos ni de hooks.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Helpers {

	/** @var array<int,string> */
	private static $meses = [
		1  => 'enero',
		2  => 'febrero',
		3  => 'marzo',
		4  => 'abril',
		5  => 'mayo',
		6  => 'junio',
		7  => 'julio',
		8  => 'agosto',
		9  => 'septiembre',
		10 => 'octubre',
		11 => 'noviembre',
		12 => 'diciembre',
	];

	/**
	 * Formatea una fecha de expiración en formato legible ("Expira el 3 de julio de 2026").
	 * Devuelve cadena vacía si la fecha no es válida o está "vacía" (0000-00-00).
	 */
	public static function format_fecha_expiracion( string $raw ): string {
		if ( ! $raw || '0000-00-00' === $raw ) {
			return '';
		}

		$timestamp = strtotime( $raw );

		if ( ! $timestamp ) {
			return '';
		}

		return sprintf(
			/* translators: 1: día, 2: nombre del mes, 3: año */
			__( 'Expira el %1$d de %2$s de %3$s', AP_TEXT_DOMAIN ),
			(int) gmdate( 'j', $timestamp ),
			self::$meses[ (int) gmdate( 'n', $timestamp ) ],
			gmdate( 'Y', $timestamp )
		);
	}

	/**
	 * Clase CSS de la barra de progreso de cupos de un área.
	 */
	public static function bar_class_for_cupo( int $pct ): string {
		return $pct >= 100 ? 'ap-bar-complete' : 'ap-bar-ok';
	}

	/**
	 * Restringe el filtro de estado del test a los valores permitidos.
	 */
	public static function sanitize_estado_filter( string $estado ): string {
		$permitidos = [ 'todos', 'completado', 'pendiente' ];

		return in_array( $estado, $permitidos, true ) ? $estado : 'todos';
	}

	/**
	 * Restringe el tamaño de página a los valores permitidos, o 'todos'.
	 *
	 * @param mixed $per_page Valor crudo recibido desde la petición.
	 * @return int|string
	 */
	public static function sanitize_per_page( $per_page ) {
		if ( 'todos' === $per_page ) {
			return 'todos';
		}

		$permitidos = [ 10, 25, 50, 100 ];
		$per_page   = (int) $per_page;

		return in_array( $per_page, $permitidos, true ) ? $per_page : 10;
	}

	/**
	 * Número total de páginas dado un total de registros y un tamaño de página.
	 *
	 * @param int        $total    Total de registros tras aplicar filtros.
	 * @param int|string $per_page Tamaño de página, o 'todos'.
	 */
	public static function calcular_paginas( int $total, $per_page ): int {
		if ( 'todos' === $per_page || (int) $per_page <= 0 ) {
			return 1;
		}

		return max( 1, (int) ceil( $total / (int) $per_page ) );
	}

	/**
	 * Formatea un porcentaje con coma decimal (convención en español),
	 * usado en la columna "Avance general" del Excel de exportación. Sin
	 * decimales cuando el valor es un número entero (ej. "0%", "100%"),
	 * con 2 decimales en el resto (ej. "58,33%"), tal como se especificó.
	 */
	public static function format_porcentaje_es( float $valor ): string {
		$redondeado = round( $valor, 2 );

		$texto = ( (float) (int) $redondeado === $redondeado )
			? (string) (int) $redondeado
			: number_format( $redondeado, 2, ',', '' );

		return $texto . '%';
	}
}
