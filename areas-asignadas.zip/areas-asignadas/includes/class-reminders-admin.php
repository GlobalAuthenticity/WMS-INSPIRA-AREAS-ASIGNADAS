<?php
/**
 * Pantalla de wp-admin «Recordatorios de registro»: configura la URL del
 * webhook al que se envían los correos y permite probarla sin tocar a ningún
 * usuario real.
 *
 * Es una pantalla autónoma: deliberadamente NO depende de class-settings.php,
 * que está escrito pero no se carga desde ningún sitio (y además invoca un
 * método de AP_Database que no existe). Conectar aquel archivo es un cambio
 * con alcance propio; esta pantalla solo necesita sus dos ajustes.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Reminders_Admin {

	const MENU_SLUG    = 'ap-recordatorios';
	const OPTION_GROUP = 'ap_recordatorios_group';
	const NONCE_TEST   = 'ap_probar_webhook';

	public function register_hooks(): void {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'wp_ajax_ap_probar_webhook_recordatorio', [ $this, 'probar_webhook' ] );
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'Recordatorios de registro', AP_TEXT_DOMAIN ),
			__( 'Áreas asignadas', AP_TEXT_DOMAIN ),
			'manage_options',
			self::MENU_SLUG,
			[ $this, 'render_page' ],
			'dashicons-groups',
			58
		);

		// Sin esto, el primer submenú hereda el título del menú padre y se
		// leería «Áreas asignadas → Áreas asignadas».
		add_submenu_page(
			self::MENU_SLUG,
			__( 'Recordatorios de registro', AP_TEXT_DOMAIN ),
			__( 'Recordatorios de registro', AP_TEXT_DOMAIN ),
			'manage_options',
			self::MENU_SLUG,
			[ $this, 'render_page' ]
		);
	}

	public function register_settings(): void {
		register_setting( self::OPTION_GROUP, AP_Reminders::OPTION_WEBHOOK, [
			'type'              => 'string',
			'sanitize_callback' => [ $this, 'sanitize_webhook' ],
			'default'           => AP_Reminders::DEFAULT_WEBHOOK,
		] );

		register_setting( self::OPTION_GROUP, AP_Reminders::OPTION_WEBHOOK_TEST, [
			'type'              => 'string',
			'sanitize_callback' => [ $this, 'sanitize_webhook_test' ],
			'default'           => AP_Reminders::DEFAULT_WEBHOOK_TEST,
		] );
	}

	public function sanitize_webhook( $valor ): string {
		return $this->sanitize_url_campo( $valor, AP_Reminders::OPTION_WEBHOOK, AP_Reminders::get_webhook() );
	}

	public function sanitize_webhook_test( $valor ): string {
		return $this->sanitize_url_campo( $valor, AP_Reminders::OPTION_WEBHOOK_TEST, AP_Reminders::get_webhook_test() );
	}

	/**
	 * Una URL inválida no se guarda: se conserva la vigente y se avisa. Dejar
	 * guardar una cadena rota dejaría los recordatorios sin destino y el
	 * fallo solo aparecería al intentar enviarlos.
	 */
	private function sanitize_url_campo( $valor, string $option, string $actual ): string {
		$url = esc_url_raw( trim( (string) $valor ) );

		if ( ! AP_Reminders::es_url_valida( $url ) ) {
			add_settings_error(
				$option,
				'ap_webhook_invalido',
				__( 'La URL indicada no es válida; debe empezar por http:// o https://. Se mantuvo la anterior.', AP_TEXT_DOMAIN ),
				'error'
			);

			return $actual;
		}

		return $url;
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap ap-rec-wrap">

			<div class="ap-rec-hero">
				<div class="ap-rec-hero-icono" aria-hidden="true"><span class="dashicons dashicons-email-alt"></span></div>
				<div>
					<h1><?php esc_html_e( 'Recordatorios de registro', AP_TEXT_DOMAIN ); ?></h1>
					<p><?php esc_html_e( 'Destino al que el servidor envía los correos de los usuarios que aún no completan su perfil.', AP_TEXT_DOMAIN ); ?></p>
				</div>
			</div>

			<?php settings_errors( AP_Reminders::OPTION_WEBHOOK ); ?>
			<?php settings_errors( AP_Reminders::OPTION_WEBHOOK_TEST ); ?>

			<form method="post" action="options.php" class="ap-rec-card">
				<?php settings_fields( self::OPTION_GROUP ); ?>

				<h2><?php esc_html_e( 'Webhook', AP_TEXT_DOMAIN ); ?></h2>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="ap-rec-webhook"><?php esc_html_e( 'URL del webhook', AP_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<input type="url" id="ap-rec-webhook" class="regular-text code"
								name="<?php echo esc_attr( AP_Reminders::OPTION_WEBHOOK ); ?>"
								value="<?php echo esc_attr( AP_Reminders::get_webhook() ); ?>" required>
							<p class="description">
								<?php esc_html_e( 'Recibe un POST con Content-Type: application/json y, como cuerpo, el array de correos seleccionados.', AP_TEXT_DOMAIN ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="ap-rec-webhook-test"><?php esc_html_e( 'Webhook de recordatorio de test', AP_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<input type="url" id="ap-rec-webhook-test" class="regular-text code"
								name="<?php echo esc_attr( AP_Reminders::OPTION_WEBHOOK_TEST ); ?>"
								value="<?php echo esc_attr( AP_Reminders::get_webhook_test() ); ?>" required>
							<p class="description">
								<?php esc_html_e( 'El del botón de campana que avisa a un usuario de que tiene el test pendiente. Recibe un objeto con nombre_completo y correo, no un array.', AP_TEXT_DOMAIN ); ?>
							</p>
						</td>
					</tr>
				</table>

				<?php submit_button( __( 'Guardar cambios', AP_TEXT_DOMAIN ) ); ?>
			</form>

			<div class="ap-rec-card">
				<h2><?php esc_html_e( 'Probar webhook', AP_TEXT_DOMAIN ); ?></h2>

				<p class="ap-rec-aviso">
					<span class="dashicons dashicons-warning" aria-hidden="true"></span>
					<?php esc_html_e( 'La prueba envía una solicitud real al webhook con el correo que escribas, así que es probable que esa dirección reciba un correo de recordatorio. No modifica la fecha del último recordatorio de ningún usuario.', AP_TEXT_DOMAIN ); ?>
				</p>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="ap-rec-correo-prueba"><?php esc_html_e( 'Correo de prueba', AP_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<input type="email" id="ap-rec-correo-prueba" class="regular-text" placeholder="prueba@ejemplo.com">
						</td>
					</tr>
				</table>

				<p>
					<button type="button" class="button button-secondary" id="ap-rec-probar">
						<?php esc_html_e( 'Probar webhook', AP_TEXT_DOMAIN ); ?>
					</button>
				</p>

				<div id="ap-rec-resultado" class="ap-rec-resultado" hidden></div>
			</div>
		</div>

		<style>
			.ap-rec-wrap { max-width: 860px; }
			.ap-rec-hero {
				display: flex; align-items: center; gap: 16px;
				background: linear-gradient(135deg, #423a59 0%, #35304a 100%);
				color: #fff; padding: 24px 28px; border-radius: 18px; margin: 20px 0 20px;
			}
			.ap-rec-hero-icono {
				display: flex; align-items: center; justify-content: center;
				width: 46px; height: 46px; border-radius: 50%; background: #944de9; flex-shrink: 0;
			}
			.ap-rec-hero-icono .dashicons { color: #fff; font-size: 24px; width: 24px; height: 24px; }
			.ap-rec-wrap .ap-rec-hero h1 { color: #fff; font-size: 23px; margin: 0; padding: 0; }
			.ap-rec-hero p { margin: 4px 0 0; color: rgba(255,255,255,.75); font-size: 13.5px; }

			.ap-rec-card {
				background: #fff; border: 1px solid #d1d5db; border-radius: 18px;
				padding: 20px 26px; margin-bottom: 18px;
			}
			.ap-rec-card h2 {
				font-size: 18px; margin: 0 0 4px; padding-bottom: 12px;
				border-bottom: 1px solid #e5e7eb; color: #423a59;
			}
			.ap-rec-card .form-table th { width: 260px; padding-left: 0; }

			.ap-rec-aviso {
				display: flex; align-items: flex-start; gap: 10px;
				background: #fef6e7; border: 1px solid #f3d9a4; color: #7a5b12;
				border-radius: 12px; padding: 12px 14px; margin: 16px 0 0; font-size: 13.5px; line-height: 1.6;
			}
			.ap-rec-aviso .dashicons { flex-shrink: 0; color: #b7791f; }

			.ap-rec-resultado {
				border-radius: 12px; padding: 14px 16px; font-size: 13.5px; line-height: 1.6;
				border: 1px solid #d1d5db; background: #f8f8f9;
			}
			.ap-rec-resultado.is-ok   { border-color: #b7e1c8; background: #eaf6ef; color: #1f7a4d; }
			.ap-rec-resultado.is-err  { border-color: #f3c2bc; background: #fdecea; color: #b42318; }
			.ap-rec-resultado strong  { display: block; margin-bottom: 6px; }
			.ap-rec-resultado pre {
				margin: 8px 0 0; padding: 10px 12px; background: rgba(0,0,0,.05);
				border-radius: 8px; max-height: 220px; overflow: auto;
				white-space: pre-wrap; word-break: break-word; font-size: 12.5px;
			}
		</style>

		<script>
		( function () {
			var boton    = document.getElementById( 'ap-rec-probar' );
			var correoEl = document.getElementById( 'ap-rec-correo-prueba' );
			var salida   = document.getElementById( 'ap-rec-resultado' );

			if ( ! boton || ! correoEl || ! salida ) { return; }

			var textoOriginal = boton.textContent;

			function pintar( ok, titulo, detalle ) {
				salida.className = 'ap-rec-resultado ' + ( ok ? 'is-ok' : 'is-err' );
				salida.innerHTML = '';

				var strong = document.createElement( 'strong' );
				strong.textContent = titulo;
				salida.appendChild( strong );

				if ( detalle ) {
					var pre = document.createElement( 'pre' );
					pre.textContent = detalle;
					salida.appendChild( pre );
				}

				salida.hidden = false;
			}

			boton.addEventListener( 'click', function () {
				var correo = correoEl.value.trim();

				if ( ! correo ) {
					pintar( false, <?php echo wp_json_encode( __( 'Escribe un correo de prueba.', AP_TEXT_DOMAIN ) ); ?>, '' );
					return;
				}

				boton.disabled = true;
				boton.textContent = <?php echo wp_json_encode( __( 'Enviando…', AP_TEXT_DOMAIN ) ); ?>;

				var body = new URLSearchParams( {
					action: 'ap_probar_webhook_recordatorio',
					nonce:  <?php echo wp_json_encode( wp_create_nonce( self::NONCE_TEST ) ); ?>,
					correo: correo
				} );

				fetch( <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, { method: 'POST', body: body } )
					.then( function ( r ) { return r.json(); } )
					.then( function ( res ) {
						var d = ( res && res.data ) || {};
						var detalle = '';

						if ( d.code ) {
							detalle += 'HTTP ' + d.code + '\n';
						}
						if ( d.body ) {
							detalle += d.body;
						}

						pintar( !! ( res && res.success ), d.msg || '', detalle.trim() );
					} )
					.catch( function () {
						pintar( false, <?php echo wp_json_encode( __( 'No se pudo contactar con el servidor.', AP_TEXT_DOMAIN ) ); ?>, '' );
					} )
					.then( function () {
						boton.disabled = false;
						boton.textContent = textoOriginal;
					} );
			} );
		} )();
		</script>
		<?php
	}

	/**
	 * Envía al webhook un array con un único correo, por el mismo camino y
	 * con el mismo formato que el envío real, y devuelve el código HTTP y el
	 * cuerpo de la respuesta. No toca el usermeta de ningún usuario, aunque
	 * el correo de prueba coincida con el de uno existente.
	 */
	public function probar_webhook(): void {
		check_ajax_referer( self::NONCE_TEST, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'msg' => __( 'Sin permisos.', AP_TEXT_DOMAIN ) ], 403 );
		}

		$correo = sanitize_email( wp_unslash( $_POST['correo'] ?? '' ) );

		if ( ! $correo || ! is_email( $correo ) ) {
			wp_send_json_error( [ 'msg' => __( 'Escribe un correo electrónico válido.', AP_TEXT_DOMAIN ) ], 400 );
		}

		$resultado = AP_Reminders::enviar( [ $correo ], AP_Reminders::get_webhook() );

		if ( ! $resultado['ok'] ) {
			wp_send_json_error( [
				'msg'  => $resultado['error'] ?: __( 'El webhook respondió con un error.', AP_TEXT_DOMAIN ),
				'code' => $resultado['code'],
				'body' => $resultado['body'],
			], 200 ); // 200: el fallo es del webhook, no de esta petición AJAX.
		}

		wp_send_json_success( [
			'msg'  => __( 'El webhook aceptó la solicitud de prueba.', AP_TEXT_DOMAIN ),
			'code' => $resultado['code'],
			'body' => $resultado['body'],
		] );
	}
}
