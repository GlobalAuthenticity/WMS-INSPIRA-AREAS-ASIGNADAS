<?php
/**
 * Integraciones con el área de administración de WordPress.
 *
 * Hoy solo valida requisitos del entorno (existencia del rol requerido);
 * es el punto de extensión natural para una futura pantalla de configuración
 * del plugin sin tener que reestructurar el resto de la arquitectura.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Admin {

	public function register_hooks(): void {
		add_action( 'admin_notices', [ $this, 'maybe_warn_missing_role' ] );
	}

	/**
	 * Advierte a los administradores del sitio si el rol requerido por el
	 * shortcode todavía no existe, para detectar configuraciones incompletas
	 * antes de que un cliente reporte que "el panel no aparece".
	 */
	public function maybe_warn_missing_role(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( get_role( AP_Security::ROLE_EMPRESA_ADMIN ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__(
				'Áreas Asignadas: el rol "empresa_admin" no existe en este sitio. El shortcode [areas_asignadas] no será visible para nadie hasta que se cree ese rol.',
				AP_TEXT_DOMAIN
			)
		);
	}
}
