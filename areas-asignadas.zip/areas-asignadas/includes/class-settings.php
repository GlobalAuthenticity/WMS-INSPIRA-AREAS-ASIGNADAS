<?php
/**
 * Menú principal "Áreas asignadas (Inspira)" en wp-admin: única fuente de
 * verdad para los valores que antes vivían hardcodeados en el código
 * (token/endpoints de WMS, webhooks de recordatorio/PDF/creación, rol
 * requerido por el shortcode) y una vista de solo lectura de todas las
 * áreas de todas las empresas, para el super-admin del sitio.
 *
 * El resto del plugin nunca lee `get_option()` directamente: siempre pasa
 * por AP_Settings::get( $clave ), que aplica el valor por defecto si la
 * opción todavía no se ha guardado (por ejemplo, justo tras instalar esta
 * versión, antes de que alguien visite la pantalla de ajustes).
 *
 * ⚠️ ESTE ARCHIVO NO ESTÁ CONECTADO.
 * Ni areas-asignadas.php ni AP_Loader hacen require_once de él, así que
 * AP_Settings no existe en tiempo de ejecución: el menú de ajustes nunca
 * llega a aparecer y el resto del plugin sigue usando las constantes
 * escritas a mano en class-ajax.php. Llamar a AP_Settings::get() desde
 * cualquier otro archivo provoca un fatal («Class AP_Settings not found»).
 *
 * Para activarlo hace falta añadir el require en areas-asignadas.php y
 * `( new AP_Settings( $database ) )->register_hooks();` en AP_Loader::run(),
 * y después revisar class-ajax.php para que lea de aquí en vez de sus
 * constantes. Es un cambio con alcance propio, no una línea suelta.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Settings {

	const OPTION_KEY = 'ap_ajustes';
	const MENU_SLUG  = 'ap-ajustes';

	/**
	 * Valores con los que operaba el plugin antes de existir esta pantalla.
	 * Se usan como respaldo mientras la opción no se guarde explícitamente,
	 * para que actualizar el plugin no cambie el comportamiento en
	 * producción hasta que alguien decida tocar un ajuste.
	 *
	 * @var array<string,string>
	 */
	const DEFAULTS = [
		'rol_empresa_admin'              => 'empresa_admin',
		'mostrar_boton_informe_empresa'  => '1',
		'wms_endpoint'                   => 'https://wmslatam.com/wp-json/wms/v1/create-user',
		'wms_token'                      => '83cbe58392d6c44ff25ab8aa675808440ed4e9ad6f60f42c',
		'webhook_creacion_wms'           => 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira-wms',
		'webhook_creacion'               => 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira',
		'webhook_recordatorio'           => 'https://api.efrenmartinezortiz-ia.com/webhook/recocrdatorio-inspira',
		'webhook_pdf'                    => 'https://api.efrenmartinezortiz-ia.com/webhook/pdf_aprobandome',
	];

	/** @var AP_Database */
	private $database;

	public function __construct( AP_Database $database ) {
		$this->database = $database;
	}

	public function register_hooks(): void {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Carga la tipografía Inter (la misma que usa aprobandome.com) solo en
	 * esta pantalla de ajustes, para que el panel se sienta parte del
	 * mismo ecosistema visual de la marca sin afectar el resto de
	 * wp-admin. `$hook` es el identificador que WordPress asigna a esta
	 * pantalla porque el menú es de nivel superior sin padre.
	 */
	public function enqueue_assets( string $hook ): void {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'ap-ajustes-inter',
			'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
			[],
			AP_VERSION
		);
	}

	/**
	 * Lee un valor guardado, o su valor por defecto si todavía no se ha
	 * guardado nada. Punto único de acceso para el resto del plugin.
	 */
	public static function get( string $clave ): string {
		// El webhook de PDF pasó a administrarse en «Webhooks de generación
		// de PDF (Inspira)», que es la pantalla única para todos los
		// informes del sitio (también los del tema). Mientras ese plugin
		// esté activo manda él, para que no existan dos valores distintos
		// para el mismo webhook; si se desactiva, se vuelve al ajuste local
		// de abajo y nada deja de funcionar.
		if ( 'webhook_pdf' === $clave && function_exists( 'ipw_get_webhook' ) ) {
			$central = ipw_get_webhook( 'area' );

			if ( '' !== $central ) {
				return $central;
			}
		}

		$valores = get_option( self::OPTION_KEY, [] );

		if ( isset( $valores[ $clave ] ) && '' !== $valores[ $clave ] ) {
			return (string) $valores[ $clave ];
		}

		return self::DEFAULTS[ $clave ] ?? '';
	}

	/**
	 * Azúcar sintáctica sobre get() para ajustes tipo checkbox (guardados
	 * como '1'/'0'), para no repetir comparaciones de string por fuera de
	 * esta clase.
	 */
	public static function is_true( string $clave ): bool {
		return '1' === self::get( $clave );
	}

	public function add_menu(): void {
		add_menu_page(
			__( 'Áreas asignadas (Inspira)', AP_TEXT_DOMAIN ),
			__( 'Áreas asignadas (Inspira)', AP_TEXT_DOMAIN ),
			'manage_options',
			self::MENU_SLUG,
			[ $this, 'render_page' ],
			'dashicons-groups',
			58
		);
	}

	public function register_settings(): void {
		register_setting( self::MENU_SLUG, self::OPTION_KEY, [
			'type'              => 'array',
			'sanitize_callback' => [ $this, 'sanitize' ],
			'default'           => self::DEFAULTS,
		] );
	}

	/**
	 * Sanea y valida cada campo por separado; si alguno llega vacío o
	 * inválido, se conserva el valor por defecto correspondiente en vez
	 * de guardar una cadena vacía que rompería silenciosamente la
	 * integración (por ejemplo, un endpoint vacío haría fallar todas las
	 * sincronizaciones con WMS sin que quede claro por qué).
	 *
	 * @param array<string,mixed> $input
	 * @return array<string,string>
	 */
	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : [];

		// El campo del webhook de PDF se pinta deshabilitado cuando lo
		// administra el plugin central, y un input deshabilitado no viaja
		// en el POST. Sin esto, guardar cualquier otro ajuste borraría el
		// valor local y lo reemplazaría por el DEFAULTS del código.
		if ( ! isset( $input['webhook_pdf'] ) ) {
			$guardado               = get_option( self::OPTION_KEY, [] );
			$input['webhook_pdf']   = is_array( $guardado ) ? ( $guardado['webhook_pdf'] ?? '' ) : '';
		}

		$limpio = [
			'rol_empresa_admin'             => sanitize_key( $input['rol_empresa_admin'] ?? '' ),
			// Checkbox: si está desmarcado, el navegador ni siquiera lo
			// envía en $input — por eso se resuelve con isset() en vez de
			// leer su valor, a diferencia de los campos de texto de abajo.
			'mostrar_boton_informe_empresa' => isset( $input['mostrar_boton_informe_empresa'] ) ? '1' : '0',
			'wms_endpoint'                  => esc_url_raw( trim( $input['wms_endpoint'] ?? '' ) ),
			'wms_token'                     => sanitize_text_field( trim( $input['wms_token'] ?? '' ) ),
			'webhook_creacion_wms'          => esc_url_raw( trim( $input['webhook_creacion_wms'] ?? '' ) ),
			'webhook_creacion'              => esc_url_raw( trim( $input['webhook_creacion'] ?? '' ) ),
			'webhook_recordatorio'          => esc_url_raw( trim( $input['webhook_recordatorio'] ?? '' ) ),
			'webhook_pdf'                   => esc_url_raw( trim( $input['webhook_pdf'] ?? '' ) ),
		];

		foreach ( $limpio as $clave => $valor ) {
			if ( '' === $valor ) {
				$limpio[ $clave ] = self::DEFAULTS[ $clave ];
			}
		}

		if ( ! get_role( $limpio['rol_empresa_admin'] ) ) {
			add_settings_error(
				self::OPTION_KEY,
				'ap_rol_inexistente',
				sprintf(
					/* translators: %s: nombre del rol que no existe */
					__( 'Guardado: el rol "%s" no existe todavía en este sitio, así que el shortcode no será visible para nadie hasta que se cree.', AP_TEXT_DOMAIN ),
					esc_html( $limpio['rol_empresa_admin'] )
				),
				'warning'
			);
		}

		return $limpio;
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap ap-ajustes-wrap">

			<div class="ap-hero">
				<div class="ap-hero-icono" aria-hidden="true">
					<span class="dashicons dashicons-groups"></span>
				</div>
				<div>
					<h1><?php esc_html_e( 'Áreas asignadas', AP_TEXT_DOMAIN ); ?> <span class="ap-hero-marca">Inspira</span></h1>
					<p class="ap-hero-subtitulo"><?php esc_html_e( 'Panel de control de integraciones, permisos y visibilidad de empresas.', AP_TEXT_DOMAIN ); ?></p>
				</div>
			</div>

			<?php settings_errors( self::OPTION_KEY ); ?>

			<form method="post" action="options.php">
				<?php settings_fields( self::MENU_SLUG ); ?>

				<div class="ap-card">
					<h2><?php esc_html_e( 'Permisos', AP_TEXT_DOMAIN ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="ap-rol-empresa-admin"><?php esc_html_e( 'Rol requerido para el shortcode', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="text" id="ap-rol-empresa-admin" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[rol_empresa_admin]" value="<?php echo esc_attr( self::get( 'rol_empresa_admin' ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'Solo usuarios con este rol ven el panel de [areas_asignadas].', AP_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<?php esc_html_e( 'Botón "Informe general" (empresa)', AP_TEXT_DOMAIN ); ?>
							</th>
							<td>
								<label for="ap-mostrar-boton-informe-empresa" class="ap-checkbox-label">
									<input type="checkbox" id="ap-mostrar-boton-informe-empresa" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[mostrar_boton_informe_empresa]" value="1" <?php checked( self::is_true( 'mostrar_boton_informe_empresa' ) ); ?>>
									<?php esc_html_e( 'Mostrar el botón "Informe general" (junto al buscador) para generar el informe consolidado de toda la empresa.', AP_TEXT_DOMAIN ); ?>
								</label>
								<p class="description"><?php esc_html_e( 'Desmárcalo para ocultarlo en el panel de todas las empresas, sin tocar los informes por área ni por usuario.', AP_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div class="ap-card">
					<h2><?php esc_html_e( 'Sincronización con WMS', AP_TEXT_DOMAIN ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="ap-wms-endpoint"><?php esc_html_e( 'Endpoint de creación de usuario', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="url" id="ap-wms-endpoint" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[wms_endpoint]" value="<?php echo esc_attr( self::get( 'wms_endpoint' ) ); ?>" class="regular-text code">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ap-wms-token"><?php esc_html_e( 'Token de autorización (Bearer)', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="password" id="ap-wms-token" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[wms_token]" value="<?php echo esc_attr( self::get( 'wms_token' ) ); ?>" class="regular-text code" autocomplete="off">
								<button type="button" class="button ap-toggle-password" data-target="ap-wms-token"><?php esc_html_e( 'Mostrar', AP_TEXT_DOMAIN ); ?></button>
							</td>
						</tr>
					</table>
				</div>

				<div class="ap-card">
					<h2><?php esc_html_e( 'Webhooks (n8n)', AP_TEXT_DOMAIN ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">
								<label for="ap-webhook-creacion-wms"><?php esc_html_e( 'Creación replicada en WMS', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="url" id="ap-webhook-creacion-wms" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[webhook_creacion_wms]" value="<?php echo esc_attr( self::get( 'webhook_creacion_wms' ) ); ?>" class="regular-text code">
								<p class="description"><?php esc_html_e( 'Se llama cuando WMS confirma que el usuario se creó/replicó allá.', AP_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ap-webhook-creacion"><?php esc_html_e( 'Creación (usuario ya existía en WMS)', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="url" id="ap-webhook-creacion" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[webhook_creacion]" value="<?php echo esc_attr( self::get( 'webhook_creacion' ) ); ?>" class="regular-text code">
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ap-webhook-recordatorio"><?php esc_html_e( 'Recordatorio de test pendiente', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="url" id="ap-webhook-recordatorio" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[webhook_recordatorio]" value="<?php echo esc_attr( self::get( 'webhook_recordatorio' ) ); ?>" class="regular-text code">
								<p class="description"><?php esc_html_e( 'Llamado directamente desde el navegador del admin (botones "Enviar recordatorio").', AP_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ap-webhook-pdf"><?php esc_html_e( 'Generación de informe PDF', AP_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<?php $pdf_centralizado = function_exists( 'ipw_get_webhook' ); ?>
								<input type="url" id="ap-webhook-pdf" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[webhook_pdf]" value="<?php echo esc_attr( self::get( 'webhook_pdf' ) ); ?>" class="regular-text code" <?php disabled( $pdf_centralizado ); ?>>
								<?php if ( $pdf_centralizado ) : ?>
									<p class="description">
										<?php esc_html_e( 'Este webhook se administra ahora en «Webhooks de PDF», junto con los del resto de informes del sitio. Este campo solo muestra el valor vigente.', AP_TEXT_DOMAIN ); ?>
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=ipw-pdf-webhooks' ) ); ?>"><?php esc_html_e( 'Ir a esa pantalla', AP_TEXT_DOMAIN ); ?></a>
									</p>
								<?php else : ?>
									<p class="description"><?php esc_html_e( 'También llamado directamente desde el navegador del admin.', AP_TEXT_DOMAIN ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					</table>
				</div>

				<?php submit_button( __( 'Guardar cambios', AP_TEXT_DOMAIN ) ); ?>
			</form>

			<div class="ap-card">
				<h2><?php esc_html_e( 'Resumen de todas las áreas', AP_TEXT_DOMAIN ); ?></h2>
				<p class="description"><?php esc_html_e( 'Vista de solo lectura para el super-admin del sitio: todas las áreas de todas las empresas, sin importar quién sea su empresa_admin.', AP_TEXT_DOMAIN ); ?></p>
				<?php $this->render_resumen_areas(); ?>
			</div>
		</div>
		<style>
			/* ─────────────────────────────────────────────────────────────
			 * Identidad visual tomada de aprobandome.com (tipografía Inter,
			 * paleta ciruela/púrpura, radios generosos, sombras suaves).
			 * Todo queda dentro de .ap-ajustes-wrap: no afecta ninguna otra
			 * pantalla de wp-admin ni cambia el HTML generado por las APIs
			 * nativas de WordPress (settings_fields, submit_button, etc.),
			 * solo su apariencia.
			 * ───────────────────────────────────────────────────────────── */
			.ap-ajustes-wrap {
				--ap-plum:      #2d2631;
				--ap-heading:   #423a59;
				--ap-primary:   #944de9;
				--ap-primary-h: #7d3ad1;
				--ap-cream:     #f0eade;
				--ap-border:    #d1d5db;
				--ap-muted:     #69727d;
				--ap-radius-lg: 20px;
				--ap-radius-pill: 40px;
				--ap-shadow: 0 0 10px -4px rgba(0,0,0,.5);
				font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
				color: var(--ap-plum);
				max-width: 920px;
			}

			.ap-ajustes-wrap h1,
			.ap-ajustes-wrap h2,
			.ap-ajustes-wrap h3 {
				font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
				color: var(--ap-heading);
			}

			/* Encabezado tipo "hero", igual en espíritu a las cabeceras de
			   sección de aprobandome.com: color de marca + tipografía fuerte. */
			.ap-hero {
				display: flex; align-items: center; gap: 18px;
				background: linear-gradient(135deg, var(--ap-heading) 0%, #35304a 100%);
				color: #fff; padding: 28px 32px; border-radius: var(--ap-radius-lg);
				margin: 20px 0 24px; box-shadow: var(--ap-shadow);
			}
			.ap-hero-icono {
				display: flex; align-items: center; justify-content: center;
				width: 52px; height: 52px; border-radius: 50%;
				background: var(--ap-primary); flex-shrink: 0;
			}
			.ap-hero-icono .dashicons { color: #fff; font-size: 26px; width: 26px; height: 26px; }
			.ap-ajustes-wrap .ap-hero h1 {
				color: #fff; font-size: 26px; font-weight: 700; margin: 0; line-height: 1.3;
			}
			.ap-hero-marca { color: var(--ap-primary); font-weight: 300; }
			.ap-hero-subtitulo { color: rgba(255,255,255,.75); margin: 4px 0 0; font-size: 14px; }

			/* Tarjetas: cada sección del formulario y el resumen viven en su
			   propia tarjeta redondeada con sombra suave, como las secciones
			   de la landing en vez de una lista plana de tablas de WordPress. */
			.ap-card {
				background: #fff; border: 1px solid var(--ap-border);
				border-radius: var(--ap-radius-lg); box-shadow: var(--ap-shadow);
				padding: 24px 28px; margin-bottom: 20px;
			}
			.ap-ajustes-wrap .ap-card h2 {
				font-size: 20px; font-weight: 600; margin: 0 0 4px;
				padding-bottom: 12px; border-bottom: 1px solid var(--ap-border);
			}
			.ap-ajustes-wrap .ap-card .form-table { margin-top: 8px; }
			.ap-ajustes-wrap .form-table th {
				width: 320px; font-weight: 500; color: var(--ap-heading); padding-left: 0;
			}
			.ap-ajustes-wrap .form-table td { padding-top: 18px; padding-bottom: 18px; }
			.ap-ajustes-wrap .description { color: var(--ap-muted); }

			/* Inputs: fondo cálido y bordes redondeados, igual que los
			   formularios de aprobandome.com. */
			.ap-ajustes-wrap input[type="text"],
			.ap-ajustes-wrap input[type="url"],
			.ap-ajustes-wrap input[type="password"],
			.ap-ajustes-wrap input[type="email"],
			.ap-ajustes-wrap textarea,
			.ap-ajustes-wrap select {
				background: var(--ap-cream); border: 1px solid var(--ap-border);
				border-radius: 14px; padding: 10px 14px; font-family: inherit;
				box-shadow: none; transition: border-color .15s, box-shadow .15s;
			}
			.ap-ajustes-wrap input[type="text"]:focus,
			.ap-ajustes-wrap input[type="url"]:focus,
			.ap-ajustes-wrap input[type="password"]:focus,
			.ap-ajustes-wrap input[type="email"]:focus,
			.ap-ajustes-wrap textarea:focus,
			.ap-ajustes-wrap select:focus {
				border-color: var(--ap-primary); box-shadow: 0 0 0 3px rgba(148,77,233,.15); outline: none;
			}

			/* Botones: forma píldora y color de marca, igual que los CTA de
			   la landing (fondo sólido, sin borde, peso 500). */
			.ap-ajustes-wrap .button,
			.ap-ajustes-wrap .button-secondary {
				border-radius: var(--ap-radius-pill); font-family: inherit; font-weight: 500;
				border: 1px solid var(--ap-border); background: #fff; color: var(--ap-heading);
				padding: 4px 18px; height: auto; line-height: 2; box-shadow: none; transition: all .15s;
			}
			.ap-ajustes-wrap .button:hover,
			.ap-ajustes-wrap .button-secondary:hover {
				border-color: var(--ap-primary); color: var(--ap-primary); background: #fff;
			}
			.ap-ajustes-wrap .button-primary {
				border-radius: var(--ap-radius-pill); font-family: inherit; font-weight: 500;
				background: var(--ap-primary); border: none; color: #fff;
				padding: 6px 26px; height: auto; line-height: 2; box-shadow: none; text-shadow: none;
			}
			.ap-ajustes-wrap .button-primary:hover,
			.ap-ajustes-wrap .button-primary:focus {
				background: var(--ap-primary-h); color: #fff;
			}
			.ap-ajustes-wrap .button:disabled,
			.ap-ajustes-wrap .button-primary:disabled {
				opacity: .6; cursor: not-allowed;
			}
			.ap-ajustes-wrap .ap-toggle-password { margin-left: 8px; font-size: 12px; padding: 4px 14px; }

			/* Checkbox: alineado con el texto de su propia etiqueta, en
			   vez del punto por defecto de WordPress pegado arriba a la
			   izquierda del párrafo. */
			.ap-ajustes-wrap .ap-checkbox-label {
				display: flex; align-items: flex-start; gap: 10px;
				font-weight: 500; color: var(--ap-heading); cursor: pointer;
			}
			.ap-ajustes-wrap .ap-checkbox-label input[type="checkbox"] {
				margin-top: 3px; width: 18px; height: 18px; flex-shrink: 0;
				accent-color: var(--ap-primary);
			}

			/* Avisos (settings_errors): se conservan los colores semánticos
			   de WordPress (ámbar = advertencia, etc.) pero con la misma
			   tipografía y radios redondeados del resto de la pantalla. */
			.ap-ajustes-wrap .notice {
				border-radius: 14px; border-left-width: 4px; font-family: inherit;
				padding: 10px 16px; box-shadow: var(--ap-shadow);
			}

			/* Tabla de resumen: encabezado con tinte cálido de marca y radios
			   consistentes con el resto de tarjetas. */
			.ap-ajustes-wrap table.widefat {
				border: 1px solid var(--ap-border); border-radius: 14px; overflow: hidden; border-spacing: 0;
			}
			.ap-ajustes-wrap table.widefat thead th {
				background: var(--ap-cream); color: var(--ap-heading); font-weight: 600;
				border-bottom: 1px solid var(--ap-border); text-transform: none;
			}
			.ap-ajustes-wrap table.widefat td, .ap-ajustes-wrap table.widefat th { padding: 12px 14px; }
			.ap-ajustes-wrap table.widefat.striped tbody tr:nth-child(odd) { background: #fafafa; }
			.ap-ajustes-wrap table.widefat tbody tr:hover { background: rgba(148,77,233,.06); }

			/* Badge de cupo lleno: mismo lenguaje visual de "pastilla" que
			   ya usa el shortcode público (ver areas-asignadas.css). */
			.ap-ajustes-wrap .ap-badge-cupo {
				display: inline-flex; align-items: center; padding: 3px 12px;
				border-radius: 999px; font-size: 12px; font-weight: 600;
				background: #F3F4F6; color: var(--ap-muted);
			}
			.ap-ajustes-wrap .ap-resumen-cupo-llena .ap-badge-cupo {
				background: #FEE2E2; color: #B91C1C;
			}
		</style>
		<script>
			document.querySelectorAll( '.ap-toggle-password' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					var input = document.getElementById( btn.dataset.target );
					if ( ! input ) return;
					var mostrando = 'text' === input.type;
					input.type = mostrando ? 'password' : 'text';
					btn.textContent = mostrando ? '<?php echo esc_js( __( 'Mostrar', AP_TEXT_DOMAIN ) ); ?>' : '<?php echo esc_js( __( 'Ocultar', AP_TEXT_DOMAIN ) ); ?>';
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Tabla de solo lectura con todas las áreas de todas las empresas.
	 * A diferencia del shortcode (que filtra por `grupo_id` del admin
	 * autenticado), aquí no hay ese filtro: es exclusivamente para
	 * `manage_options`, ya verificado al entrar a render_page().
	 */
	private function render_resumen_areas(): void {
		$areas = $this->database->get_all_areas_admin();

		if ( empty( $areas ) ) {
			echo '<p>' . esc_html__( 'Todavía no hay áreas creadas.', AP_TEXT_DOMAIN ) . '</p>';
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Empresa (empresa_admin)', AP_TEXT_DOMAIN ); ?></th>
					<th><?php esc_html_e( 'Área', AP_TEXT_DOMAIN ); ?></th>
					<th><?php esc_html_e( 'Cupo', AP_TEXT_DOMAIN ); ?></th>
					<th><?php esc_html_e( 'Estado', AP_TEXT_DOMAIN ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $areas as $area ) : ?>
					<?php
					$cupo_usado = (int) $area['cupos_usados'];
					$cupo_total = (int) $area['cupo'];
					$llena      = $cupo_total > 0 && $cupo_usado >= $cupo_total;
					?>
					<tr>
						<td>
							<?php echo esc_html( $area['empresa_admin_nombre'] ?: __( '(sin admin asignado)', AP_TEXT_DOMAIN ) ); ?>
							<?php if ( $area['empresa_admin_correo'] ) : ?>
								<br><span class="description"><?php echo esc_html( $area['empresa_admin_correo'] ); ?></span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $area['nombre'] ); ?></td>
						<td class="<?php echo $llena ? 'ap-resumen-cupo-llena' : ''; ?>">
							<span class="ap-badge-cupo"><?php echo esc_html( $cupo_usado . ' / ' . ( $cupo_total ?: '∞' ) ); ?></span>
						</td>
						<td><?php echo esc_html( $area['estado'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}
