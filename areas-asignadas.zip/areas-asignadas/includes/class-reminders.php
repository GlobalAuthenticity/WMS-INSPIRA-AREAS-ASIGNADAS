<?php
/**
 * Recordatorios de registro: configuración del webhook, envío desde el
 * servidor y persistencia de la fecha del último recordatorio por usuario.
 *
 * Toda llamada saliente del flujo de recordatorios pasa por aquí, para que
 * exista un único lugar donde se decide a qué URL se envía, con qué formato
 * y qué se considera una respuesta aceptada.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Reminders {

	/** Opción con la URL del webhook de «Recordar registro». */
	const OPTION_WEBHOOK = 'ap_webhook_recordar_registro';

	/**
	 * Opción con la URL del webhook del recordatorio de test pendiente (el
	 * botón de campana del listado de usuarios). Antes vivía escrita en el
	 * JS público; ahora se resuelve en el servidor igual que la de arriba.
	 */
	const OPTION_WEBHOOK_TEST = 'ap_webhook_recordatorio_test';

	/** Usermeta con el timestamp Unix del último recordatorio de registro. */
	const META_ULTIMO = 'ap_ultimo_recordatorio_registro';

	const DEFAULT_WEBHOOK      = 'https://api.efrenmartinezortiz-ia.com/webhook/credenciales_para_wms-inspira-array';
	const DEFAULT_WEBHOOK_TEST = 'https://api.efrenmartinezortiz-ia.com/webhook/recocrdatorio-inspira';

	/** Zona horaria en la que se muestran y se filtran las fechas. */
	const TIMEZONE = 'America/Bogota';

	const TIMEOUT = 25;

	/**
	 * URL del webhook de recordatorios de registro. Cae al valor por defecto
	 * mientras no se haya guardado nada en la pantalla de ajustes, para que
	 * la función sirva desde el primer momento sin configurar nada.
	 */
	public static function get_webhook(): string {
		$url = (string) get_option( self::OPTION_WEBHOOK, '' );

		return '' !== trim( $url ) ? trim( $url ) : self::DEFAULT_WEBHOOK;
	}

	/**
	 * URL del webhook del recordatorio de test pendiente (botón de campana).
	 */
	public static function get_webhook_test(): string {
		$url = (string) get_option( self::OPTION_WEBHOOK_TEST, '' );

		return '' !== trim( $url ) ? trim( $url ) : self::DEFAULT_WEBHOOK_TEST;
	}

	/**
	 * Valida que una URL sea utilizable como webhook: bien formada, con
	 * esquema http/https y aceptada por la propia validación de WordPress
	 * (que además bloquea destinos internos cuando el sitio lo restringe).
	 */
	public static function es_url_valida( string $url ): bool {
		$url = trim( $url );

		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return false;
		}

		$esquema = wp_parse_url( $url, PHP_URL_SCHEME );

		return in_array( $esquema, [ 'http', 'https' ], true );
	}

	/**
	 * Envía un array de correos al webhook indicado, en una sola petición
	 * POST con `Content-Type: application/json`. El cuerpo es exactamente el
	 * array de correos (sin envoltorio), tal como espera el flujo de n8n.
	 *
	 * @param array<int,string> $correos Correos ya validados.
	 * @param string            $url     Webhook destino.
	 * @return array{ok:bool,code:int,body:string,error:string}
	 */
	public static function enviar( array $correos, string $url ): array {
		$correos = self::normalizar_correos( $correos );

		if ( empty( $correos ) ) {
			return [ 'ok' => false, 'code' => 0, 'body' => '', 'error' => __( 'No hay correos válidos para enviar.', AP_TEXT_DOMAIN ) ];
		}

		if ( ! self::es_url_valida( $url ) ) {
			return [ 'ok' => false, 'code' => 0, 'body' => '', 'error' => __( 'La URL del webhook no es válida.', AP_TEXT_DOMAIN ) ];
		}

		$response = wp_remote_post( $url, [
			'method'  => 'POST',
			'timeout' => self::TIMEOUT,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( $correos ),
		] );

		if ( is_wp_error( $response ) ) {
			return [ 'ok' => false, 'code' => 0, 'body' => '', 'error' => $response->get_error_message() ];
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = (string) wp_remote_retrieve_body( $response );

		return [
			'ok'    => $code >= 200 && $code < 300,
			'code'  => $code,
			'body'  => $body,
			'error' => '',
		];
	}

	/**
	 * Correos en minúsculas, válidos y sin duplicados, conservando el orden
	 * de aparición. Es lo que se manda al webhook y lo que se compara contra
	 * los usuarios del grupo.
	 *
	 * @param array<int,string> $correos
	 * @return array<int,string>
	 */
	public static function normalizar_correos( array $correos ): array {
		$limpios = [];

		foreach ( $correos as $correo ) {
			$correo = sanitize_email( strtolower( trim( (string) $correo ) ) );

			if ( '' === $correo || ! is_email( $correo ) ) {
				continue;
			}

			$limpios[ $correo ] = true;
		}

		return array_keys( $limpios );
	}

	/**
	 * Marca la fecha y hora actual como último recordatorio de los usuarios
	 * indicados. Se guarda el timestamp Unix (UTC): el formato con zona
	 * horaria se aplica solo al mostrarlo, para que un cambio de zona en el
	 * sitio no reinterprete fechas ya guardadas.
	 *
	 * @param array<int,int> $user_ids
	 * @return int Timestamp guardado.
	 */
	public static function marcar_enviados( array $user_ids ): int {
		$ahora = time();

		foreach ( array_unique( array_map( 'intval', $user_ids ) ) as $user_id ) {
			if ( $user_id > 0 ) {
				update_user_meta( $user_id, self::META_ULTIMO, $ahora );
			}
		}

		return $ahora;
	}

	/**
	 * Formatea un timestamp como `dd/mm/yyyy hh:mm:ss AM/PM` en hora de
	 * Colombia. Devuelve cadena vacía si nunca se envió un recordatorio, y
	 * es el frontend quien decide cómo representar ese caso.
	 *
	 * @param mixed $timestamp Valor crudo del usermeta.
	 */
	public static function format_ultimo( $timestamp ): string {
		$timestamp = (int) $timestamp;

		if ( $timestamp <= 0 ) {
			return '';
		}

		try {
			$fecha = new DateTimeImmutable( '@' . $timestamp );

			return $fecha->setTimezone( new DateTimeZone( self::TIMEZONE ) )->format( 'd/m/Y h:i:s A' );
		} catch ( \Exception $e ) {
			return '';
		}
	}

	/**
	 * Convierte una fecha `Y-m-d` escrita por el admin (que la piensa en hora
	 * de Colombia) al timestamp del inicio o del final de ese día. Se usa
	 * para el filtro por rango de fechas del último recordatorio.
	 *
	 * @param string $fecha  Fecha en formato Y-m-d.
	 * @param bool   $fin    true para el último segundo del día.
	 * @return int|null Timestamp, o null si la fecha no es válida.
	 */
	public static function fecha_a_timestamp( string $fecha, bool $fin = false ): ?int {
		$fecha = trim( $fecha );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fecha ) ) {
			return null;
		}

		try {
			$hora = $fin ? ' 23:59:59' : ' 00:00:00';
			$dt   = new DateTimeImmutable( $fecha . $hora, new DateTimeZone( self::TIMEZONE ) );

			return $dt->getTimestamp();
		} catch ( \Exception $e ) {
			return null;
		}
	}
}
