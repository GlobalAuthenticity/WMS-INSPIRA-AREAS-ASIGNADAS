<?php
/**
 * Punto único de arranque: instancia las dependencias compartidas y registra
 * los hooks de cada módulo. Añadir un módulo nuevo (p. ej. un widget o una
 * REST route) solo requiere instanciarlo aquí, sin tocar el resto del código.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Loader {

	public function run(): void {
		$database = new AP_Database();

		$frontend = new AP_Frontend( $database );
		$frontend->register_hooks();

		$ajax = new AP_Ajax( $database );
		$ajax->register_hooks();

		$admin = new AP_Admin();
		$admin->register_hooks();

		$recordatorios = new AP_Reminders_Admin();
		$recordatorios->register_hooks();
	}
}
