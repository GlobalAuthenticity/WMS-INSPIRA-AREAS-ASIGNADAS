<?php
/**
 * Generador mínimo de archivos .xlsx reales (OOXML), sin depender de
 * ninguna librería externa (no hay Composer/vendor propio en el proyecto;
 * la única copia de PhpSpreadsheet del sitio vive prefijada dentro de
 * woo-order-export-lite y no es segura de reutilizar desde otro plugin).
 *
 * Además de las celdas, escribe encabezado con estilo, anchos de columna,
 * fila congelada y autofiltro, para que el archivo abra ya legible en vez
 * de una tabla plana sin formato. La paleta reutiliza los mismos colores
 * de assets/css/areas-asignadas.css (--ap-p, --ap-pl, --ap-ph y los
 * colores de .ap-badge-activo/.ap-badge-pendiente), para que el Excel se
 * sienta parte del mismo sistema visual que el panel.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Xlsx_Writer {

	// Índices de estilo (cellXfs), en el mismo orden en que los declara
	// self::styles_xml(). Definidos como constantes para que
	// AP_Ajax::exportar_usuarios_excel() no tenga que conocer números
	// mágicos al armar la configuración de columnas.
	const STYLE_HEADER       = 1;
	const STYLE_BODY_LEFT    = 2;
	const STYLE_BODY_RIGHT   = 3;
	const STYLE_STATUS_GOOD  = 4;
	const STYLE_STATUS_BAD   = 5;

	/**
	 * Genera el binario de un .xlsx de una sola hoja.
	 *
	 * @param array<int,string> $headers Encabezados de columna, en orden.
	 * @param array<int,array<int,string|int|float>> $rows Filas; cada una con el mismo número de columnas que $headers.
	 * @param array<int,array{type?:string,align?:string,good?:string,width?:float}> $columns {
	 *     Configuración por columna, en el mismo orden que $headers/$rows. Todas las claves son opcionales.
	 *
	 *     @type string $type  'number' escribe la celda como número real (sin comillas, alineado a la
	 *                         derecha, sin el triángulo de "número guardado como texto"); cualquier otro
	 *                         valor (o ausente) la escribe como texto. Por defecto 'text'.
	 *     @type string $align 'left' (por defecto), 'right', o 'status' — 'status' colorea la celda en
	 *                         verde si el valor coincide (sin distinguir mayúsculas) con `good`, o en gris
	 *                         en caso contrario (p. ej. "Completado" vs. "Incompleto").
	 *     @type string $good  Solo relevante con align='status': el valor considerado positivo.
	 *     @type float  $width Ancho de columna en unidades de Excel. Por defecto 18.
	 * }
	 * @param string $sheet_name Nombre de la hoja (máx. 31 caracteres, límite de Excel).
	 * @return string|null Contenido binario del .xlsx, o null si no se pudo generar (p. ej. sin extensión ZipArchive).
	 */
	public static function generate( array $headers, array $rows, array $columns = [], string $sheet_name = 'Usuarios' ): ?string {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return null;
		}

		$tmp_path = wp_tempnam( 'ap-export.xlsx' );

		if ( ! $tmp_path ) {
			return null;
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $tmp_path, ZipArchive::OVERWRITE ) ) {
			wp_delete_file( $tmp_path );
			return null;
		}

		$zip->addEmptyDir( '_rels' );
		$zip->addEmptyDir( 'xl' );
		$zip->addEmptyDir( 'xl/_rels' );
		$zip->addEmptyDir( 'xl/worksheets' );

		$zip->addFromString( '[Content_Types].xml', self::content_types_xml() );
		$zip->addFromString( '_rels/.rels', self::root_rels_xml() );
		$zip->addFromString( 'xl/workbook.xml', self::workbook_xml( substr( $sheet_name, 0, 31 ) ) );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', self::workbook_rels_xml() );
		$zip->addFromString( 'xl/styles.xml', self::styles_xml() );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', self::sheet_xml( $headers, $rows, $columns ) );

		$zip->close();

		$contenido = file_get_contents( $tmp_path );
		wp_delete_file( $tmp_path );

		return false !== $contenido ? $contenido : null;
	}

	private static function content_types_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '</Types>';
	}

	private static function root_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
	}

	private static function workbook_xml( string $sheet_name ): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="' . self::esc( $sheet_name ) . '" sheetId="1" r:id="rId1"/></sheets>'
			. '</workbook>';
	}

	private static function workbook_rels_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
			. '</Relationships>';
	}

	/**
	 * Fuentes, rellenos, bordes y combinaciones (cellXfs) usadas por
	 * sheet_xml(). El índice de cada <xf> en <cellXfs> es lo que
	 * self::STYLE_* referencia vía el atributo s="" de cada celda; el
	 * orden de las entradas de abajo debe coincidir exactamente con esas
	 * constantes (0 = por defecto, sin usar explícitamente).
	 */
	private static function styles_xml(): string {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<fonts count="4">'
				. '<font><sz val="11"/><color rgb="FF1E1B4B"/><name val="Calibri"/></font>'
				. '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
				. '<font><b/><sz val="10"/><color rgb="FF065F46"/><name val="Calibri"/></font>'
				. '<font><b/><sz val="10"/><color rgb="FF6B7280"/><name val="Calibri"/></font>'
			. '</fonts>'
			. '<fills count="6">'
				. '<fill><patternFill patternType="none"/></fill>'
				. '<fill><patternFill patternType="gray125"/></fill>'
				. '<fill><patternFill patternType="solid"><fgColor rgb="FF423373"/><bgColor indexed="64"/></patternFill></fill>'
				. '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F3FF"/><bgColor indexed="64"/></patternFill></fill>'
				. '<fill><patternFill patternType="solid"><fgColor rgb="FFD1FAE5"/><bgColor indexed="64"/></patternFill></fill>'
				. '<fill><patternFill patternType="solid"><fgColor rgb="FFF3F4F6"/><bgColor indexed="64"/></patternFill></fill>'
			. '</fills>'
			. '<borders count="2">'
				. '<border><left/><right/><top/><bottom/><diagonal/></border>'
				. '<border><left/><right/><top/><bottom style="thin"><color rgb="FFEDE9FE"/></bottom><diagonal/></border>'
			. '</borders>'
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. '<cellXfs count="6">'
				// 0 · por defecto (obligatorio, sin uso explícito).
				. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
				// 1 · STYLE_HEADER: blanco y negrita sobre fondo morado (--ap-p), igual que <thead> en pantalla.
				. '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>'
				// 2 · STYLE_BODY_LEFT: fondo lavanda (--ap-pl) con borde inferior (--ap-ph), igual que <tbody>.
				. '<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>'
				// 3 · STYLE_BODY_RIGHT: igual, alineado a la derecha (columnas numéricas/porcentaje).
				. '<xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>'
				// 4 · STYLE_STATUS_GOOD: mismo verde que .ap-badge-activo.
				. '<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
				// 5 · STYLE_STATUS_BAD: mismo gris que .ap-badge-pendiente.
				. '<xf numFmtId="0" fontId="3" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
			. '</cellXfs>'
			. '</styleSheet>';
	}

	/**
	 * @param array<int,array{type?:string,align?:string,good?:string,width?:float}> $columns
	 */
	private static function sheet_xml( array $headers, array $rows, array $columns ): string {
		$total_filas = count( $rows ) + 1; // +1 por la fila de encabezado.
		$ultima_col  = self::column_letter( max( 0, count( $headers ) - 1 ) );

		$xml  = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
		$xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';

		// Fila de encabezado siempre visible al desplazar la lista hacia abajo.
		$xml .= '<sheetViews><sheetView workbookViewId="0">'
			. '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
			. '<selection pane="bottomLeft" activeCell="A2" sqref="A2"/>'
			. '</sheetView></sheetViews>';

		$xml .= self::cols_xml( $headers, $columns );

		$xml .= '<sheetData>';
		$xml .= self::header_row_xml( $headers );

		foreach ( $rows as $index => $row ) {
			$xml .= self::body_row_xml( $index + 2, $row, $columns );
		}

		$xml .= '</sheetData>';

		// Flechas de filtro en el encabezado, sobre todo el rango de datos.
		$xml .= '<autoFilter ref="A1:' . $ultima_col . $total_filas . '"/>';

		// La columna numérica y la de porcentaje (ambas alineadas a la
		// derecha) pueden verse iguales a un número normal para Excel;
		// esto silencia el triángulo verde de "número guardado como
		// texto" en las que sí se escriben como texto (ver STYLE_BODY_RIGHT
		// en sheet_xml() / body_row_xml()).
		$xml .= '<ignoredErrors><ignoredError sqref="A2:' . $ultima_col . $total_filas . '" numberStoredAsText="1"/></ignoredErrors>';

		$xml .= '</worksheet>';

		return $xml;
	}

	private static function cols_xml( array $headers, array $columns ): string {
		$xml = '<cols>';

		foreach ( array_keys( $headers ) as $index ) {
			$width = $columns[ $index ]['width'] ?? 18;
			$xml  .= '<col min="' . ( $index + 1 ) . '" max="' . ( $index + 1 ) . '" width="' . $width . '" customWidth="1"/>';
		}

		return $xml . '</cols>';
	}

	private static function header_row_xml( array $headers ): string {
		$xml = '<row r="1" ht="22" customHeight="1">';

		foreach ( array_values( $headers ) as $col_index => $value ) {
			$ref  = self::column_letter( $col_index ) . '1';
			$xml .= '<c r="' . $ref . '" t="inlineStr" s="' . self::STYLE_HEADER . '"><is><t xml:space="preserve">' . self::esc( (string) $value ) . '</t></is></c>';
		}

		return $xml . '</row>';
	}

	/**
	 * @param array<int,array{type?:string,align?:string,good?:string,width?:float}> $columns
	 */
	private static function body_row_xml( int $row_number, array $row, array $columns ): string {
		$xml = '<row r="' . $row_number . '" ht="18">';

		foreach ( array_values( $row ) as $col_index => $value ) {
			$ref    = self::column_letter( $col_index ) . $row_number;
			$config = $columns[ $col_index ] ?? [];
			$align  = $config['align'] ?? 'left';

			if ( 'status' === $align ) {
				$es_positivo = 0 === strcasecmp( (string) $value, (string) ( $config['good'] ?? '' ) );
				$style       = $es_positivo ? self::STYLE_STATUS_GOOD : self::STYLE_STATUS_BAD;
			} else {
				$style = 'right' === $align ? self::STYLE_BODY_RIGHT : self::STYLE_BODY_LEFT;
			}

			if ( 'number' === ( $config['type'] ?? 'text' ) && is_numeric( $value ) ) {
				$xml .= '<c r="' . $ref . '" s="' . $style . '"><v>' . self::esc( (string) ( 0 + $value ) ) . '</v></c>';
				continue;
			}

			$xml .= '<c r="' . $ref . '" t="inlineStr" s="' . $style . '"><is><t xml:space="preserve">' . self::esc( (string) $value ) . '</t></is></c>';
		}

		return $xml . '</row>';
	}

	private static function column_letter( int $index ): string {
		$letter = '';

		do {
			$letter = chr( 65 + ( $index % 26 ) ) . $letter;
			$index  = intdiv( $index, 26 ) - 1;
		} while ( $index >= 0 );

		return $letter;
	}

	private static function esc( string $value ): string {
		return htmlspecialchars( $value, ENT_QUOTES | ENT_XML1, 'UTF-8' );
	}
}
