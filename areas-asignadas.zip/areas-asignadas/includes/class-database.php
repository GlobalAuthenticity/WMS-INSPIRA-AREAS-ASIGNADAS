<?php
/**
 * Capa de acceso a datos. Toda sentencia SQL del plugin vive aquí; ningún
 * otro archivo debe tocar $wpdb directamente.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Database {

	/** @var wpdb */
	private $wpdb;

	public function __construct() {
		global $wpdb;
		$this->wpdb = $wpdb;
	}

	/**
	 * Áreas asignadas a un grupo (empresa), con cupos usados y usuarios que
	 * ya completaron el test.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_areas_by_grupo( int $grupo_id ): array {
		$sql = "SELECT a.id, a.nombre, a.cupo, a.estado, a.fecha_expiracion,
		               COUNT(DISTINCT um.id) AS cupos_usados,
		               COUNT(DISTINCT CASE WHEN umeta.meta_key = 'question_test_ids' THEN um.user_id END) AS usuarios_con_test
		        FROM {$this->wpdb->prefix}areas a
		        LEFT JOIN {$this->wpdb->prefix}user_members um ON um.area_id = a.id
		        LEFT JOIN {$this->wpdb->usermeta} umeta ON umeta.user_id = um.user_id AND umeta.meta_key = 'question_test_ids'
		        WHERE a.grupo_id = %d
		        GROUP BY a.id
		        ORDER BY a.nombre ASC";

		return (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, $grupo_id ), ARRAY_A );
	}

	/**
	 * Confirma que un área pertenece al grupo indicado. Base de toda
	 * autorización sobre operaciones a nivel de área.
	 */
	public function area_pertenece_a_grupo( int $area_id, int $grupo_id ): bool {
		$id = $this->wpdb->get_var( $this->wpdb->prepare(
			"SELECT id FROM {$this->wpdb->prefix}areas WHERE id = %d AND grupo_id = %d",
			$area_id,
			$grupo_id
		) );

		return (bool) $id;
	}

	/**
	 * Confirma que un usuario está inscrito en al menos un área del grupo
	 * indicado. Se usa para evitar exponer resultados de un usuario de otra
	 * empresa al solicitar su informe individual (protección IDOR).
	 */
	public function usuario_pertenece_a_grupo( int $user_id, int $grupo_id ): bool {
		$id = $this->wpdb->get_var( $this->wpdb->prepare(
			"SELECT um.id
			 FROM {$this->wpdb->prefix}user_members um
			 INNER JOIN {$this->wpdb->prefix}areas a ON a.id = um.area_id
			 WHERE um.user_id = %d AND a.grupo_id = %d
			 LIMIT 1",
			$user_id,
			$grupo_id
		) );

		return (bool) $id;
	}

	/**
	 * Total de usuarios inscritos en un área, sin filtros. Se usa para el
	 * badge "Usuarios: X / cupo" del modal.
	 */
	public function total_usuarios_area( int $area_id ): int {
		return (int) $this->wpdb->get_var( $this->wpdb->prepare(
			"SELECT COUNT(*) FROM {$this->wpdb->prefix}user_members WHERE area_id = %d",
			$area_id
		) );
	}

	/**
	 * Datos crudos de un área concreta (incluye grupo_id y fecha_expiracion).
	 * Base de la autorización y de los datos que se copian al crear una
	 * membresía nueva en esa área.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_area( int $area_id ): ?array {
		$area = $this->wpdb->get_row( $this->wpdb->prepare(
			"SELECT id, nombre, cupo, estado, tipo, grupo_id, fecha_expiracion
			 FROM {$this->wpdb->prefix}areas
			 WHERE id = %d",
			$area_id
		), ARRAY_A );

		return $area ?: null;
	}

	/**
	 * Crea el registro de membresía que vincula un usuario recién creado con
	 * un área. `fecha_final_membresia` hereda la fecha de expiración del área
	 * en el momento de la creación (no se recalcula después).
	 */
	public function crear_membresia_usuario( int $area_id, int $user_id, string $fecha_final_membresia ): bool {
		$insertado = $this->wpdb->insert(
			"{$this->wpdb->prefix}user_members",
			[
				'area_id'                => $area_id,
				'user_id'                => $user_id,
				'status'                 => 'ACTIVO',
				'days'                   => 0,
				'fecha_final_membresia'  => $fecha_final_membresia,
			],
			[ '%d', '%d', '%s', '%d', '%s' ]
		);

		return false !== $insertado;
	}

	/**
	 * Usuarios de un área, con búsqueda, filtro por estado del test y
	 * paginación resueltos a nivel de base de datos (no en PHP ni en JS).
	 *
	 * @param array{search?:string,estado?:string,per_page?:int|string,page?:int} $args
	 * @return array{usuarios:array<int,array<string,mixed>>,total_filtrado:int}
	 */
	public function get_usuarios_area( int $area_id, array $args ): array {
		$search   = $args['search'] ?? '';
		$estado   = $args['estado'] ?? 'todos';
		$per_page = $args['per_page'] ?? 10;
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );

		$where  = 'WHERE um.area_id = %d';
		$params = [ $area_id ];

		if ( '' !== $search ) {
			$like     = '%' . $this->wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (u.display_name LIKE %s OR u.user_email LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$having = '';
		if ( 'completado' === $estado ) {
			$having = 'HAVING tiene_test = 1';
		} elseif ( 'pendiente' === $estado ) {
			$having = 'HAVING tiene_test = 0';
		}

		$base_sql = "
			SELECT u.ID, u.display_name, u.user_email,
			       EXISTS (
			           SELECT 1 FROM {$this->wpdb->usermeta} um2
			           WHERE um2.user_id = u.ID AND um2.meta_key = 'question_test_ids'
			       ) AS tiene_test
			FROM {$this->wpdb->prefix}user_members um
			INNER JOIN {$this->wpdb->users} u ON u.ID = um.user_id
			{$where}
			{$having}
		";

		$total_filtrado = (int) $this->wpdb->get_var(
			$this->wpdb->prepare( "SELECT COUNT(*) FROM ({$base_sql}) AS filtered", $params )
		);

		$order_sql = ' ORDER BY u.display_name ASC';
		$limit_sql = '';

		if ( 'todos' !== $per_page ) {
			$per_page  = (int) $per_page;
			$offset    = ( $page - 1 ) * $per_page;
			$limit_sql = $this->wpdb->prepare( ' LIMIT %d OFFSET %d', $per_page, $offset );
		}

		$final_sql = $this->wpdb->prepare( $base_sql, $params ) . $order_sql . $limit_sql;
		$usuarios  = (array) $this->wpdb->get_results( $final_sql, ARRAY_A );

		// El progreso y el estado del perfil solo se calculan para los usuarios
		// de la página actual, no para todos los del área: evita recorrer
		// usermeta/LearnDash de cientos de usuarios cuando solo se muestran 10
		// o 25 a la vez.
		if ( ! empty( $usuarios ) ) {
			// Una sola consulta para toda la usermeta de la página: el criterio
			// de "perfil completo" lee varios campos de cada usuario.
			update_meta_cache( 'user', array_map( 'intval', wp_list_pluck( $usuarios, 'ID' ) ) );
		}

		foreach ( $usuarios as &$usuario ) {
			$usuario['tiene_test']      = (bool) $usuario['tiene_test'];
			$usuario['perfil_completo'] = $this->usuario_tiene_perfil_completo( (int) $usuario['ID'] );
			$usuario['progreso_pct']    = $this->get_progreso_usuario( (int) $usuario['ID'] );
		}
		unset( $usuario );

		return [
			'usuarios'       => $usuarios,
			'total_filtrado' => $total_filtrado,
		];
	}

	/**
	 * IDs de los cursos LearnDash de un usuario. Une dos fuentes: la API de
	 * LearnDash (incluye cursos a los que accede por grupo, que no generan
	 * el usermeta `course_{id}_access_from`) y la detección por usermeta que
	 * ya existía, que se conserva como respaldo si LearnDash no está activo.
	 *
	 * @return array<int,int>
	 */
	private function get_course_ids_usuario( int $user_id ): array {
		$ids = $this->get_course_ids_por_meta( $user_id );

		if ( function_exists( 'learndash_user_get_enrolled_courses' ) ) {
			$ids = array_merge( $ids, array_map( 'intval', (array) learndash_user_get_enrolled_courses( $user_id ) ) );
		}

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * IDs de los cursos LearnDash a los que un usuario tiene acceso,
	 * detectados a partir del usermeta que LearnDash crea al inscribir
	 * (`course_{id}_access_from`). Único lugar donde vive esta consulta;
	 * tanto get_progreso_usuario() como get_cursos_y_avance_usuario()
	 * parten de aquí para no duplicar el patrón de la regex.
	 *
	 * @return array<int,int>
	 */
	private function get_course_ids_por_meta( int $user_id ): array {
		return array_map( 'intval', (array) $this->wpdb->get_col( $this->wpdb->prepare(
			"SELECT CAST(
			    SUBSTRING(meta_key, 8, CHAR_LENGTH(meta_key) - 19)
			 AS UNSIGNED)
			 FROM {$this->wpdb->usermeta}
			 WHERE user_id = %d
			   AND meta_key REGEXP '^course_[0-9]+_access_from$'
			   AND CAST(SUBSTRING(meta_key, 8, CHAR_LENGTH(meta_key) - 19) AS UNSIGNED) > 0",
			$user_id
		) ) );
	}

	/**
	 * Porcentaje de progreso promedio de un usuario a través de todos los
	 * cursos a los que tiene acceso.
	 */
	public function get_progreso_usuario( int $user_id ): int {
		$course_ids = $this->get_course_ids_usuario( $user_id );

		if ( empty( $course_ids ) ) {
			return 0;
		}

		$suma_pct = 0;

		foreach ( $course_ids as $course_id ) {
			$suma_pct += $this->get_progreso_curso( $user_id, $course_id );
		}

		return (int) round( $suma_pct / count( $course_ids ) );
	}

	/**
	 * Igual que get_progreso_usuario(), pero además del promedio devuelve
	 * el total de cursos asignados y conserva 2 decimales de precisión
	 * (necesario para el Excel de exportación, ver AP_Xlsx_Writer). No
	 * reemplaza a get_progreso_usuario(): esa se usa tal cual en el modal
	 * "Ver usuarios" (progreso redondeado a entero para la barra visual).
	 *
	 * @return array{total_cursos:int,avance_pct:float}
	 */
	public function get_cursos_y_avance_usuario( int $user_id ): array {
		$course_ids = $this->get_course_ids_usuario( $user_id );
		$total      = count( $course_ids );

		if ( 0 === $total ) {
			return [ 'total_cursos' => 0, 'avance_pct' => 0.0 ];
		}

		$suma_pct = 0;

		foreach ( $course_ids as $course_id ) {
			$suma_pct += $this->get_progreso_curso( $user_id, $course_id );
		}

		return [
			'total_cursos' => $total,
			'avance_pct'   => round( $suma_pct / $total, 2 ),
		];
	}

	/**
	 * Progreso de un usuario en un curso concreto (0–100, con decimales).
	 * Prioriza el avance real de LearnDash (`_sfwd-course_progress`); si no
	 * hay, recurre al metadato propio del sistema y, por último, a la tabla
	 * de actividad de LearnDash (curso completado = 100%).
	 */
	private function get_progreso_curso( int $user_id, int $course_id ): float {
		// 1) Fuente de verdad: el mismo cálculo de LearnDash que ve el alumno en
		// su panel. Lee `_sfwd-course_progress`, que es donde LearnDash guarda
		// el avance (lecciones/temas completados sobre el total del curso).
		if ( function_exists( 'learndash_course_progress' ) ) {
			$ld = learndash_course_progress( [
				'user_id'   => $user_id,
				'course_id' => $course_id,
				'array'     => true,
			] );

			if ( is_array( $ld ) && isset( $ld['percentage'] ) && (float) $ld['percentage'] > 0 ) {
				return (float) min( 100, max( 0, (float) $ld['percentage'] ) );
			}
		}

		// 2) Mismo dato leído directamente, por si la función anterior no está
		// disponible en el contexto actual.
		$ld_meta = get_user_meta( $user_id, '_sfwd-course_progress', true );

		if ( is_array( $ld_meta ) && ! empty( $ld_meta[ $course_id ]['total'] ) && (int) $ld_meta[ $course_id ]['total'] > 0 ) {
			$pct = (int) ( $ld_meta[ $course_id ]['completed'] ?? 0 ) / (int) $ld_meta[ $course_id ]['total'] * 100;

			if ( $pct > 0 ) {
				return round( min( 100, max( 0, $pct ) ), 2 );
			}
		}

		// 3) Respaldos anteriores (metadato propio y tabla de actividad).
		$raw = get_user_meta( $user_id, 'course_' . $course_id . '_progress', true );

		if ( is_array( $raw ) && ! empty( $raw ) ) {
			if ( isset( $raw['percentage'] ) && (int) $raw['percentage'] > 0 ) {
				return min( 100, max( 0, (int) $raw['percentage'] ) );
			}

			if ( isset( $raw['total'], $raw['completed'] ) && (int) $raw['total'] > 0 ) {
				$pct = (int) round( (int) $raw['completed'] / (int) $raw['total'] * 100 );
				return min( 100, max( 0, $pct ) );
			}

			return 0;
		}

		$completado = $this->wpdb->get_var( $this->wpdb->prepare(
			"SELECT activity_status
			 FROM {$this->wpdb->prefix}learndash_user_activity
			 WHERE user_id       = %d
			   AND course_id     = %d
			   AND activity_type = 'course'
			 LIMIT 1",
			$user_id,
			$course_id
		) );

		return $completado ? 100 : 0;
	}

	/**
	 * Usuarios de un conjunto de áreas, para la exportación a Excel
	 * ("Descargar estado de usuario"). A diferencia de get_usuarios_area()
	 * (una sola área, paginada, para el modal "Ver usuarios"), esta trae
	 * TODAS las áreas pedidas sin paginar, y solo las que realmente
	 * pertenecen al grupo indicado (`a.grupo_id = %d` en el propio JOIN,
	 * mismo criterio de autorización que area_pertenece_a_grupo()): un
	 * area_id ajeno enviado desde el cliente simplemente no trae filas, en
	 * vez de exponer datos de otra empresa.
	 *
	 * Si un mismo usuario está inscrito en más de una de las áreas
	 * pedidas, solo se incluye una vez (con la primera área encontrada
	 * según el ORDER BY), tal como pide el ticket ("evitar usuarios
	 * duplicados en el Excel").
	 *
	 * @param array<int,int> $area_ids
	 * @return array<int,array<string,mixed>>
	 */
	public function get_usuarios_export( array $area_ids, int $grupo_id ): array {
		$area_ids = array_values( array_unique( array_filter( array_map( 'intval', $area_ids ) ) ) );

		if ( empty( $area_ids ) ) {
			return [];
		}

		$placeholders = implode( ',', array_fill( 0, count( $area_ids ), '%d' ) );

		$sql = "SELECT u.ID, u.display_name, u.user_email, a.nombre AS area_nombre,
		               EXISTS (
		                   SELECT 1 FROM {$this->wpdb->usermeta} um2
		                   WHERE um2.user_id = u.ID AND um2.meta_key = 'question_test_ids'
		               ) AS tiene_test
		        FROM {$this->wpdb->prefix}user_members um
		        INNER JOIN {$this->wpdb->prefix}areas a ON a.id = um.area_id
		        INNER JOIN {$this->wpdb->users} u ON u.ID = um.user_id
		        WHERE um.area_id IN ({$placeholders}) AND a.grupo_id = %d
		        ORDER BY a.nombre ASC, u.display_name ASC";

		$params = array_merge( $area_ids, [ $grupo_id ] );
		$filas  = (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, $params ), ARRAY_A );

		$usuarios     = [];
		$ids_incluidos = [];

		foreach ( $filas as $fila ) {
			$user_id = (int) $fila['ID'];

			if ( isset( $ids_incluidos[ $user_id ] ) ) {
				continue;
			}
			$ids_incluidos[ $user_id ] = true;

			$detalle = $this->get_cursos_y_avance_usuario( $user_id );

			$usuarios[] = [
				'ID'              => $user_id,
				'display_name'    => $fila['display_name'],
				'user_email'      => $fila['user_email'],
				'area_nombre'     => $fila['area_nombre'],
				'tiene_test'      => (bool) $fila['tiene_test'],
				'perfil_completo' => $this->usuario_tiene_perfil_completo( $user_id ),
				'total_cursos'    => $detalle['total_cursos'],
				'avance_pct'      => $detalle['avance_pct'],
			];
		}

		return $usuarios;
	}

	/**
	 * Usuarios de un grupo (o de un área concreta) que todavía NO han
	 * completado su perfil, para el flujo «Recordar registro».
	 *
	 * El criterio de "perfil completo" vive en PHP (ESP_User_Fields), no en
	 * SQL, así que no se puede filtrar ni paginar en la consulta: se traen de
	 * una vez los miembros del grupo y se descartan en PHP los que ya tienen
	 * el perfil completo. Para que eso no degenere en una consulta por
	 * usuario, se precalienta la caché de usermeta con update_meta_cache():
	 * a partir de ahí, los get_user_meta() de ESP_User_Fields y el del último
	 * recordatorio se resuelven en memoria.
	 *
	 * Un usuario inscrito en varias áreas del grupo aparece una sola vez, con
	 * la primera área según el ORDER BY (mismo criterio que get_usuarios_export()).
	 *
	 * @param int      $grupo_id Empresa (empresa_admin) autenticada.
	 * @param int|null $area_id  Área concreta, o null para todas las del grupo.
	 * @return array<int,array<string,mixed>>
	 */
	public function get_usuarios_perfil_incompleto( int $grupo_id, ?int $area_id = null ): array {
		$where  = 'a.grupo_id = %d';
		$params = [ $grupo_id ];

		if ( $area_id ) {
			$where   .= ' AND um.area_id = %d';
			$params[] = $area_id;
		}

		$sql = "SELECT u.ID, u.display_name, u.user_email, a.id AS area_id, a.nombre AS area_nombre
		        FROM {$this->wpdb->prefix}user_members um
		        INNER JOIN {$this->wpdb->prefix}areas a ON a.id = um.area_id
		        INNER JOIN {$this->wpdb->users} u ON u.ID = um.user_id
		        WHERE {$where}
		        ORDER BY a.nombre ASC, u.user_email ASC";

		$filas = (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, $params ), ARRAY_A );

		if ( empty( $filas ) ) {
			return [];
		}

		// Una sola consulta para toda la usermeta de estos usuarios; sin
		// esto, cada ESP_User_Fields::get_user_values() dispararía la suya.
		update_meta_cache( 'user', array_values( array_unique( array_map( 'intval', wp_list_pluck( $filas, 'ID' ) ) ) ) );

		$usuarios = [];
		$vistos   = [];

		foreach ( $filas as $fila ) {
			$user_id = (int) $fila['ID'];

			if ( isset( $vistos[ $user_id ] ) ) {
				continue;
			}
			$vistos[ $user_id ] = true;

			if ( $this->usuario_tiene_perfil_completo( $user_id ) ) {
				continue;
			}

			$ultimo = (int) get_user_meta( $user_id, AP_Reminders::META_ULTIMO, true );

			$usuarios[] = [
				'ID'               => $user_id,
				'display_name'     => $fila['display_name'],
				'user_email'       => $fila['user_email'],
				'area_id'          => (int) $fila['area_id'],
				'area_nombre'      => $fila['area_nombre'],
				'ultimo_ts'        => $ultimo,
				'ultimo_formateado' => AP_Reminders::format_ultimo( $ultimo ),
			];
		}

		return $usuarios;
	}

	/**
	 * Correos de los usuarios indicados que (a) pertenecen a un área del
	 * grupo y (b) siguen teniendo el perfil incompleto. Es la verificación
	 * que se hace justo antes de enviar: entre que el admin abrió el modal y
	 * pulsó «Enviar recordatorios», un usuario pudo completar su perfil, y
	 * un id ajeno enviado a mano simplemente no aparece en el resultado.
	 *
	 * @param array<int,int> $user_ids
	 * @return array<int,array{ID:int,user_email:string}>
	 */
	public function filtrar_usuarios_pendientes_del_grupo( array $user_ids, int $grupo_id ): array {
		$user_ids = array_values( array_unique( array_filter( array_map( 'intval', $user_ids ) ) ) );

		if ( empty( $user_ids ) ) {
			return [];
		}

		$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );

		$sql = "SELECT DISTINCT u.ID, u.user_email
		        FROM {$this->wpdb->prefix}user_members um
		        INNER JOIN {$this->wpdb->prefix}areas a ON a.id = um.area_id
		        INNER JOIN {$this->wpdb->users} u ON u.ID = um.user_id
		        WHERE um.user_id IN ({$placeholders}) AND a.grupo_id = %d";

		$params = array_merge( $user_ids, [ $grupo_id ] );
		$filas  = (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, $params ), ARRAY_A );

		if ( empty( $filas ) ) {
			return [];
		}

		update_meta_cache( 'user', array_map( 'intval', wp_list_pluck( $filas, 'ID' ) ) );

		$pendientes = [];

		foreach ( $filas as $fila ) {
			$id = (int) $fila['ID'];

			if ( $this->usuario_tiene_perfil_completo( $id ) ) {
				continue;
			}

			$pendientes[] = [
				'ID'         => $id,
				'user_email' => (string) $fila['user_email'],
			];
		}

		return $pendientes;
	}

	/**
	 * Indica si un usuario completó su perfil, usando la MISMA definición
	 * que ya gobierna el acceso al sitio para estos usuarios: el esquema
	 * de campos obligatorios de edit-subscriber-profile
	 * (ESP_User_Fields), diseñado para el rol 'subscriber' —el mismo rol
	 * con el que AP_Ajax::crear_usuario() da de alta a estos usuarios—.
	 *
	 * No se reutiliza octagono_user_has_complete_name() del theme: esa
	 * función solo aplica su validación a usuarios con rol 'customer' y
	 * devuelve true (sin comprobar nada) para cualquier otro rol,
	 * incluido 'subscriber', por lo que marcaría a todos estos usuarios
	 * como "completo" sin importar sus datos reales.
	 *
	 * Si edit-subscriber-profile no está activo, se recurre a un respaldo
	 * mínimo (nombre y apellidos) para no dejar la columna vacía.
	 *
	 * Es pública porque el flujo «Recordar registro» necesita el mismo
	 * criterio tanto para listar pendientes como para revalidarlos antes de
	 * enviar; duplicar la definición en otra clase sería la forma más
	 * sencilla de que ambas acabaran divergiendo.
	 */
	public function usuario_tiene_perfil_completo( int $user_id ): bool {
		if ( class_exists( 'ESP_User_Fields' ) ) {
			$valores = ESP_User_Fields::get_user_values( $user_id );

			return ! ESP_User_Fields::has_missing_required_fields( $valores );
		}

		$first_name = trim( (string) get_user_meta( $user_id, 'first_name', true ) );
		$last_name  = trim( (string) get_user_meta( $user_id, 'last_name', true ) );

		return '' !== $first_name && '' !== $last_name;
	}
}
