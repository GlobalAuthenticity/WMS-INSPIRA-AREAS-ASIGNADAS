<?php
/**
 * Comprobaciones de rol y de nonces. Única fuente de verdad sobre "quién
 * puede hacer qué" dentro del plugin.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Security {

	const ROLE_EMPRESA_ADMIN = 'empresa_admin';
	const NONCE_ACTION       = 'ap_nonce';

	/**
	 * Indica si el usuario actual tiene el rol requerido para usar el shortcode.
	 */
	public static function current_user_is_empresa_admin(): bool {
		$user = wp_get_current_user();

		return in_array( self::ROLE_EMPRESA_ADMIN, (array) $user->roles, true );
	}

	/**
	 * Crea el nonce que se localiza en el JS del frontend.
	 */
	public static function create_nonce(): string {
		return wp_create_nonce( self::NONCE_ACTION );
	}

	/**
	 * Verifica nonce y rol para una petición AJAX. Si algo falla, responde
	 * con error JSON y termina la ejecución (comportamiento estándar de
	 * check_ajax_referer() / wp_send_json_error()).
	 */
	public static function verify_ajax_request(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! self::current_user_is_empresa_admin() ) {
			wp_send_json_error( [ 'msg' => __( 'Sin permisos', AP_TEXT_DOMAIN ) ], 403 );
		}
	}
}
