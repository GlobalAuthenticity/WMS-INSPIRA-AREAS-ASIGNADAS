<?php
/**
 * Endpoints AJAX del panel de áreas asignadas. Cada método valida nonce, rol
 * y pertenencia (área/usuario → grupo del admin autenticado) antes de tocar
 * la base de datos.
 *
 * @package AreasAsignadas
 */

defined( 'ABSPATH' ) || exit;

class AP_Ajax {

	/** @var AP_Database */
	private $database;

	public function __construct( AP_Database $database ) {
		$this->database = $database;
	}

	public function register_hooks(): void {
		add_action( 'wp_ajax_ap_get_usuarios_area', [ $this, 'get_usuarios_area' ] );
		add_action( 'wp_ajax_ap_get_resultados_area_pdf', [ $this, 'get_resultados_area_pdf' ] );
		add_action( 'wp_ajax_ap_get_resultados_grupo_pdf', [ $this, 'get_resultados_grupo_pdf' ] );
		add_action( 'wp_ajax_ap_get_resultados_pdf', [ $this, 'get_resultados_pdf' ] );
		add_action( 'wp_ajax_ap_crear_usuario', [ $this, 'crear_usuario' ] );
		add_action( 'wp_ajax_ap_exportar_usuarios_excel', [ $this, 'exportar_usuarios_excel' ] );
		add_action( 'wp_ajax_ap_get_usuarios_pendientes_registro', [ $this, 'get_usuarios_pendientes_registro' ] );
		add_action( 'wp_ajax_ap_enviar_recordatorios_registro', [ $this, 'enviar_recordatorios_registro' ] );
		add_action( 'wp_ajax_ap_enviar_recordatorio_test', [ $this, 'enviar_recordatorio_test' ] );
	}

	/**
	 * Usuarios con el perfil incompleto, para el paso 1 de «Recordar
	 * registro». Sin `area_id` devuelve los de todas las áreas del grupo
	 * (menú "Acciones" del listado); con `area_id` solo los de esa área
	 * (menú "Acciones" del modal de usuarios).
	 *
	 * Búsqueda y filtros se aplican en el servidor sobre el conjunto ya
	 * resuelto, para que el checkbox "seleccionar todo" del encabezado
	 * marque exactamente lo que el admin está viendo.
	 */
	public function get_usuarios_pendientes_registro(): void {
		AP_Security::verify_ajax_request();

		$grupo_id = get_current_user_id();
		$area_id  = (int) ( $_POST['area_id'] ?? 0 );

		if ( $area_id && ! $this->database->area_pertenece_a_grupo( $area_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Área no autorizada', AP_TEXT_DOMAIN ) ], 403 );
		}

		$usuarios = $this->database->get_usuarios_perfil_incompleto( $grupo_id, $area_id ?: null );
		$total    = count( $usuarios );

		$usuarios = $this->filtrar_pendientes( $usuarios, [
			'search'       => sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ),
			'area'         => (int) ( $_POST['filtro_area'] ?? 0 ),
			'recordatorio' => sanitize_key( wp_unslash( $_POST['filtro_recordatorio'] ?? 'todos' ) ),
			'desde'        => sanitize_text_field( wp_unslash( $_POST['desde'] ?? '' ) ),
			'hasta'        => sanitize_text_field( wp_unslash( $_POST['hasta'] ?? '' ) ),
		] );

		// Las áreas del desplegable solo se piden en la primera carga: no
		// cambian al teclear en el buscador, y resolverlas implica la consulta
		// agregada de cupos de get_areas_by_grupo().
		$con_areas = ! $area_id && ! empty( $_POST['con_areas'] );

		wp_send_json_success( [
			'usuarios'       => array_values( $usuarios ),
			'total_filtrado' => count( $usuarios ),
			'total'          => $total,
			'areas'          => $con_areas ? $this->areas_para_filtro( $grupo_id ) : [],
		] );
	}

	/**
	 * Aplica búsqueda por correo, filtro por área y filtro por último
	 * recordatorio sobre la lista ya resuelta de pendientes.
	 *
	 * @param array<int,array<string,mixed>>                                   $usuarios
	 * @param array{search:string,area:int,recordatorio:string,desde:string,hasta:string} $filtros
	 * @return array<int,array<string,mixed>>
	 */
	private function filtrar_pendientes( array $usuarios, array $filtros ): array {
		$search = strtolower( trim( $filtros['search'] ) );
		$desde  = AP_Reminders::fecha_a_timestamp( $filtros['desde'] );
		$hasta  = AP_Reminders::fecha_a_timestamp( $filtros['hasta'], true );

		return array_values( array_filter( $usuarios, static function ( $usuario ) use ( $search, $filtros, $desde, $hasta ) {
			if ( '' !== $search && false === strpos( strtolower( (string) $usuario['user_email'] ), $search ) ) {
				return false;
			}

			if ( $filtros['area'] > 0 && (int) $usuario['area_id'] !== $filtros['area'] ) {
				return false;
			}

			$ultimo = (int) $usuario['ultimo_ts'];

			if ( 'sin_recordatorios' === $filtros['recordatorio'] ) {
				return 0 === $ultimo;
			}

			if ( 'rango' === $filtros['recordatorio'] ) {
				if ( 0 === $ultimo ) {
					return false;
				}
				if ( null !== $desde && $ultimo < $desde ) {
					return false;
				}
				if ( null !== $hasta && $ultimo > $hasta ) {
					return false;
				}
			}

			return true;
		} ) );
	}

	/**
	 * Áreas del grupo en el formato mínimo que necesita el `select` de
	 * filtro por área del modal.
	 *
	 * @return array<int,array{id:int,nombre:string}>
	 */
	private function areas_para_filtro( int $grupo_id ): array {
		return array_map(
			static function ( $area ) {
				return [ 'id' => (int) $area['id'], 'nombre' => (string) $area['nombre'] ];
			},
			$this->database->get_areas_by_grupo( $grupo_id )
		);
	}

	/**
	 * Envía el recordatorio de registro a los usuarios seleccionados, en una
	 * sola petición al webhook configurado.
	 *
	 * Los correos no se toman del cliente: se reciben ids de usuario y el
	 * servidor resuelve los correos de los que realmente pertenecen al grupo
	 * y siguen con el perfil incompleto. Así, manipular el formulario no
	 * permite enviar a direcciones arbitrarias ni a usuarios de otra empresa.
	 */
	public function enviar_recordatorios_registro(): void {
		AP_Security::verify_ajax_request();

		$grupo_id = get_current_user_id();
		$user_ids = array_map( 'intval', (array) ( $_POST['user_ids'] ?? [] ) );
		$user_ids = array_values( array_filter( $user_ids ) );

		if ( empty( $user_ids ) ) {
			wp_send_json_error( [ 'msg' => __( 'Selecciona al menos un usuario.', AP_TEXT_DOMAIN ) ], 400 );
		}

		$pendientes = $this->database->filtrar_usuarios_pendientes_del_grupo( $user_ids, $grupo_id );

		if ( empty( $pendientes ) ) {
			wp_send_json_error( [
				'msg' => __( 'Ninguno de los usuarios seleccionados sigue pendiente de completar su perfil.', AP_TEXT_DOMAIN ),
			], 409 );
		}

		$correos = AP_Reminders::normalizar_correos( wp_list_pluck( $pendientes, 'user_email' ) );

		if ( empty( $correos ) ) {
			wp_send_json_error( [ 'msg' => __( 'Los usuarios seleccionados no tienen un correo válido.', AP_TEXT_DOMAIN ) ], 400 );
		}

		$resultado = AP_Reminders::enviar( $correos, AP_Reminders::get_webhook() );

		if ( ! $resultado['ok'] ) {
			wp_send_json_error( [
				'msg'  => $resultado['error'] ?: sprintf(
					/* translators: %d: código HTTP devuelto por el webhook */
					__( 'El webhook respondió con el código %d.', AP_TEXT_DOMAIN ),
					$resultado['code']
				),
				'code' => $resultado['code'],
			], 502 );
		}

		// Solo cuando el webhook acepta la solicitud se marca la fecha: si
		// falló, la selección debe poder reintentarse sin que el listado
		// diga que ya se les escribió.
		$timestamp = AP_Reminders::marcar_enviados( wp_list_pluck( $pendientes, 'ID' ) );

		wp_send_json_success( [
			'enviados'  => count( $correos ),
			'user_ids'  => array_map( 'intval', wp_list_pluck( $pendientes, 'ID' ) ),
			'ultimo_ts' => $timestamp,
			'ultimo'    => AP_Reminders::format_ultimo( $timestamp ),
		] );
	}

	/**
	 * Recordatorio individual de test pendiente (botón de campana del modal
	 * de usuarios). Antes el navegador llamaba al webhook directamente, lo
	 * que dejaba su URL a la vista en el JS público y permitía invocarlo con
	 * cualquier correo; ahora la petición sale del servidor y el correo lo
	 * resuelve el propio WordPress a partir del id, tras comprobar que ese
	 * usuario pertenece al grupo del admin autenticado.
	 */
	public function enviar_recordatorio_test(): void {
		AP_Security::verify_ajax_request();

		$user_id  = (int) ( $_POST['user_id'] ?? 0 );
		$grupo_id = get_current_user_id();

		if ( ! $user_id ) {
			wp_send_json_error( [ 'msg' => __( 'Usuario inválido', AP_TEXT_DOMAIN ) ], 400 );
		}

		if ( ! $this->database->usuario_pertenece_a_grupo( $user_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Usuario no autorizado', AP_TEXT_DOMAIN ) ], 403 );
		}

		$usuario = get_userdata( $user_id );

		if ( ! $usuario || ! is_email( $usuario->user_email ) ) {
			wp_send_json_error( [ 'msg' => __( 'El usuario no tiene un correo válido.', AP_TEXT_DOMAIN ) ], 400 );
		}

		$url = AP_Reminders::get_webhook_test();

		if ( ! AP_Reminders::es_url_valida( $url ) ) {
			wp_send_json_error( [ 'msg' => __( 'La URL del webhook no es válida.', AP_TEXT_DOMAIN ) ], 500 );
		}

		// Este webhook conserva su contrato original (objeto con nombre y
		// correo), distinto al de «Recordar registro» (array de correos).
		$response = wp_remote_post( $url, [
			'method'  => 'POST',
			'timeout' => AP_Reminders::TIMEOUT,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [
				'nombre_completo' => $usuario->display_name,
				'correo'          => $usuario->user_email,
			] ),
		] );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( [ 'msg' => $response->get_error_message() ], 502 );
		}

		$codigo = (int) wp_remote_retrieve_response_code( $response );

		if ( $codigo < 200 || $codigo >= 300 ) {
			wp_send_json_error( [
				'msg'  => sprintf(
					/* translators: %d: código HTTP devuelto por el webhook */
					__( 'El webhook respondió con el código %d.', AP_TEXT_DOMAIN ),
					$codigo
				),
				'code' => $codigo,
			], 502 );
		}

		wp_send_json_success( [ 'code' => $codigo ] );
	}

	/**
	 * Devuelve los usuarios de un área con búsqueda, filtro y paginación
	 * aplicados en la base de datos.
	 */
	public function get_usuarios_area(): void {
		AP_Security::verify_ajax_request();

		$area_id  = (int) ( $_POST['area_id'] ?? 0 );
		$grupo_id = get_current_user_id();

		if ( ! $area_id ) {
			wp_send_json_error( [ 'msg' => __( 'Área inválida', AP_TEXT_DOMAIN ) ], 400 );
		}

		if ( ! $this->database->area_pertenece_a_grupo( $area_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Área no autorizada', AP_TEXT_DOMAIN ) ], 403 );
		}

		$args = [
			'search'   => sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ),
			'estado'   => AP_Helpers::sanitize_estado_filter( sanitize_text_field( wp_unslash( $_POST['estado'] ?? 'todos' ) ) ),
			'per_page' => AP_Helpers::sanitize_per_page( $_POST['per_page'] ?? 10 ),
			'page'     => max( 1, (int) ( $_POST['page'] ?? 1 ) ),
		];

		$resultado  = $this->database->get_usuarios_area( $area_id, $args );
		$total_area = $this->database->total_usuarios_area( $area_id );
		$pages      = AP_Helpers::calcular_paginas( $resultado['total_filtrado'], $args['per_page'] );

		wp_send_json_success( [
			'usuarios'       => $resultado['usuarios'],
			'total_filtrado' => $resultado['total_filtrado'],
			'total_area'     => $total_area,
			'page'           => min( $args['page'], $pages ),
			'per_page'       => $args['per_page'],
			'pages'          => $pages,
		] );
	}

	/**
	 * Resultados del test de un área completa, para generación de PDF.
	 */
	public function get_resultados_area_pdf(): void {
		AP_Security::verify_ajax_request();

		$area_id  = (int) ( $_POST['area_id'] ?? 0 );
		$grupo_id = get_current_user_id();

		if ( ! $area_id ) {
			wp_send_json_error( [ 'msg' => __( 'Área inválida', AP_TEXT_DOMAIN ) ], 400 );
		}

		if ( ! $this->database->area_pertenece_a_grupo( $area_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Área no autorizada', AP_TEXT_DOMAIN ) ], 403 );
		}

		/**
		 * get_results_area() es una función externa del sistema de
		 * evaluaciones del sitio (fuera del alcance de este plugin) que
		 * devuelve el array asociativo de resultados de un área.
		 */
		$resultado = function_exists( 'get_results_area' ) ? get_results_area( $area_id ) : null;

		if ( empty( $resultado ) ) {
			wp_send_json_error( [ 'msg' => __( 'No se encontraron resultados para esta área.', AP_TEXT_DOMAIN ) ], 404 );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Resultados del test de TODAS las áreas del grupo del admin autenticado,
	 * para generación de un único PDF consolidado ("informe general").
	 *
	 * Reutiliza get_results_area() por cada área (misma función externa que
	 * get_resultados_area_pdf()) y agrupa las respuestas en un array por área.
	 *
	 * NOTA: el webhook `pdf_aprobandome` hoy solo recibe el resultado de UNA
	 * área a la vez (ver get_resultados_area_pdf()). Este endpoint le manda
	 * un array de resultados por área en su lugar — es posible que el flujo
	 * n8n del webhook necesite un ajuste para aceptar y combinar esta forma
	 * en un solo PDF antes de que este botón funcione de punta a punta.
	 */
	public function get_resultados_grupo_pdf(): void {
		AP_Security::verify_ajax_request();

		$grupo_id = get_current_user_id();
		$areas    = $this->database->get_areas_by_grupo( $grupo_id );

		if ( empty( $areas ) ) {
			wp_send_json_error( [ 'msg' => __( 'No tienes áreas asignadas.', AP_TEXT_DOMAIN ) ], 404 );
		}

		$resultados = [];

		foreach ( $areas as $area ) {
			$area_id        = (int) $area['id'];
			$resultado_area = function_exists( 'get_results_area' ) ? get_results_area( $area_id ) : null;

			if ( empty( $resultado_area ) ) {
				continue;
			}

			$resultados[] = [
				'area_id'     => $area_id,
				'area_nombre' => $area['nombre'],
				'resultado'   => $resultado_area,
			];
		}

		if ( empty( $resultados ) ) {
			wp_send_json_error( [ 'msg' => __( 'No se encontraron resultados para ninguna área.', AP_TEXT_DOMAIN ) ], 404 );
		}

		wp_send_json_success( [ 'areas' => $resultados ] );
	}

	/**
	 * Resultados del test de un usuario individual, para generación de PDF.
	 *
	 * A diferencia de la versión original, valida que el usuario solicitado
	 * pertenezca a una área del grupo del admin autenticado antes de exponer
	 * sus resultados, evitando que un admin de una empresa pueda solicitar
	 * el informe de un usuario de otra empresa cambiando el user_id.
	 */
	public function get_resultados_pdf(): void {
		AP_Security::verify_ajax_request();

		$user_id  = (int) ( $_POST['user_id'] ?? 0 );
		$grupo_id = get_current_user_id();

		if ( ! $user_id ) {
			wp_send_json_error( [ 'msg' => __( 'Usuario inválido', AP_TEXT_DOMAIN ) ], 400 );
		}

		if ( ! $this->database->usuario_pertenece_a_grupo( $user_id, $grupo_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Usuario no autorizado', AP_TEXT_DOMAIN ) ], 403 );
		}

		/**
		 * get_results_user() es una función externa del sistema de
		 * evaluaciones del sitio (fuera del alcance de este plugin).
		 */
		$resultado = function_exists( 'get_results_user' ) ? get_results_user( $user_id ) : null;

		if ( empty( $resultado ) ) {
			wp_send_json_error( [ 'msg' => __( 'No se encontraron resultados para este usuario.', AP_TEXT_DOMAIN ) ], 404 );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Exporta a un .xlsx real los usuarios de las áreas seleccionadas
	 * (menú "Acciones" → "Descargar estado de usuario"). A diferencia del
	 * resto de endpoints del panel, esta respuesta NO es JSON: en éxito
	 * envía directamente el binario del archivo con las cabeceras de
	 * descarga, y solo cae a wp_send_json_error() en los casos de error
	 * (mismo patrón que usa cualquier exportador de WordPress).
	 */
	public function exportar_usuarios_excel(): void {
		AP_Security::verify_ajax_request();

		$area_ids = array_map( 'intval', (array) ( $_POST['area_ids'] ?? [] ) );
		$area_ids = array_values( array_filter( $area_ids ) );

		if ( empty( $area_ids ) ) {
			wp_send_json_error( [ 'msg' => __( 'Selecciona al menos un área para exportar.', AP_TEXT_DOMAIN ) ], 400 );
		}

		$grupo_id = get_current_user_id();

		// get_usuarios_export() ya filtra por a.grupo_id = $grupo_id en el
		// propio JOIN: cualquier area_id que no pertenezca a esta empresa
		// simplemente no aporta filas, en vez de exponer datos ajenos.
		$usuarios = $this->database->get_usuarios_export( $area_ids, $grupo_id );

		$headers = [
			__( 'Nombre', AP_TEXT_DOMAIN ),
			__( 'Correo', AP_TEXT_DOMAIN ),
			__( 'Área', AP_TEXT_DOMAIN ),
			__( 'Estado de perfil', AP_TEXT_DOMAIN ),
			__( 'Test', AP_TEXT_DOMAIN ),
			__( 'Cursos asignados', AP_TEXT_DOMAIN ),
			__( 'Avance general', AP_TEXT_DOMAIN ),
		];

		$filas = [];

		foreach ( $usuarios as $usuario ) {
			$filas[] = [
				$usuario['display_name'],
				$usuario['user_email'],
				$usuario['area_nombre'],
				$usuario['perfil_completo'] ? __( 'Completado', AP_TEXT_DOMAIN ) : __( 'Incompleto', AP_TEXT_DOMAIN ),
				$usuario['tiene_test'] ? __( 'Realizado', AP_TEXT_DOMAIN ) : __( 'Pendiente', AP_TEXT_DOMAIN ),
				(int) $usuario['total_cursos'],
				AP_Helpers::format_porcentaje_es( (float) $usuario['avance_pct'] ),
			];
		}

		// Alineación, ancho y color de cada columna en el .xlsx exportado
		// (ver AP_Xlsx_Writer::generate()); 'status' colorea en verde el
		// valor que coincide con 'good' ("Completado"/"Realizado") y en
		// gris cualquier otro, igual que los badges del panel en pantalla.
		$columnas = [
			[ 'align' => 'left', 'width' => 30 ],                                                  // Nombre
			[ 'align' => 'left', 'width' => 32 ],                                                  // Correo
			[ 'align' => 'left', 'width' => 24 ],                                                  // Área
			[ 'align' => 'status', 'good' => __( 'Completado', AP_TEXT_DOMAIN ), 'width' => 16 ],   // Estado de perfil
			[ 'align' => 'status', 'good' => __( 'Realizado', AP_TEXT_DOMAIN ), 'width' => 14 ],    // Test
			[ 'align' => 'right', 'type' => 'number', 'width' => 16 ],                              // Cursos asignados
			[ 'align' => 'right', 'width' => 16 ],                                                  // Avance general
		];

		$xlsx = AP_Xlsx_Writer::generate( $headers, $filas, $columnas );

		if ( null === $xlsx ) {
			wp_send_json_error( [ 'msg' => __( 'No se pudo generar el archivo Excel en este servidor.', AP_TEXT_DOMAIN ) ], 500 );
		}

		$nombre_archivo = 'usuarios-' . gmdate( 'Y-m-d' ) . '.xlsx';

		nocache_headers();
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
		header( 'Content-Disposition: attachment; filename="' . $nombre_archivo . '"' );
		header( 'Content-Length: ' . strlen( $xlsx ) );
		echo $xlsx; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binario del .xlsx, no HTML.
		exit;
	}

	/**
	 * Endpoint externo al que se notifica cada usuario creado, para que el
	 * ecosistema WMS lo replique en wmslatam.com. Definido como constante
	 * para que quede en un único lugar si el endpoint o el token cambian.
	 */
	const WMS_CREATE_USER_ENDPOINT = 'https://wmslatam.com/wp-json/wms/v1/create-user';
	const WMS_CREATE_USER_TOKEN    = '83cbe58392d6c44ff25ab8aa675808440ed4e9ad6f60f42c';
	const WMS_TIPO_PROGRAMA        = 'inspira';

	const WEBHOOK_CREACION_INSPIRA_WMS      = 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira-wms';
	const WEBHOOK_CREACION_INSPIRA_OCTAGONO = 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-inspira-octagono';

	const OCTAGONO_CREATE_USER_AREA_ENDPOINT = 'https://octagono.wmslatam.com/wp-json/octagono/v1/create-user-area';
	const OCTAGONO_CREATE_USER_AREA_TOKEN    = '779f441184653235126cbda0d78e8cf1b5531b556a77af0d61638760c8ffc56e';

	/**
	 * Crea un usuario nuevo dentro de un área del grupo del admin autenticado
	 * a partir únicamente de su correo. Genera contraseña, login y nicename,
	 * inscribe la membresía en `{prefix}user_members` y replica el alta en el
	 * webhook de WMS.
	 *
	 * El resto de campos (login, nicename, password) no los pide el admin:
	 * se derivan del correo o se generan al azar, tal como se especificó.
	 */
	public function crear_usuario(): void {
		AP_Security::verify_ajax_request();

		$area_id  = (int) ( $_POST['area_id'] ?? 0 );
		$grupo_id = get_current_user_id();

		if ( ! $area_id ) {
			wp_send_json_error( [ 'msg' => __( 'Área inválida', AP_TEXT_DOMAIN ) ], 400 );
		}

		$area = $this->database->get_area( $area_id );

		if ( ! $area || (int) $area['grupo_id'] !== $grupo_id ) {
			wp_send_json_error( [ 'msg' => __( 'Área no autorizada', AP_TEXT_DOMAIN ) ], 403 );
		}

		$cupo_usado = $this->database->total_usuarios_area( $area_id );

		// cupo = 0 se trata como "sin límite" (no debería ocurrir en la
		// práctica, pero evita bloquear áreas mal configuradas).
		if ( (int) $area['cupo'] > 0 && $cupo_usado >= (int) $area['cupo'] ) {
			wp_send_json_error( [ 'msg' => __( 'Esta área ya alcanzó su cupo máximo de usuarios.', AP_TEXT_DOMAIN ) ], 409 );
		}

		$correo = sanitize_email( wp_unslash( $_POST['correo'] ?? '' ) );

		if ( ! $correo || ! is_email( $correo ) ) {
			wp_send_json_error( [ 'msg' => __( 'Ingresa un correo electrónico válido.', AP_TEXT_DOMAIN ) ], 400 );
		}

		// Primera verificación exigida: si el correo ya existe en el sitio,
		// el proceso se detiene aquí sin crear nada.
		if ( email_exists( $correo ) ) {
			wp_send_json_error( [ 'msg' => __( 'Ya existe un usuario registrado con ese correo.', AP_TEXT_DOMAIN ) ], 409 );
		}

		$nombre_local  = strtok( $correo, '@' ); // Parte antes del @, usada como nombre y base del login.
		$password      = wp_generate_password( 14, true, false );
		$user_login    = $this->generar_login_unico( $nombre_local );
		$user_nicename = $this->generar_nicename_random( $user_login );

		// Este sitio tiene algo (probablemente el flujo de registro público
		// / auto-enrollment de otro plugin) enganchado al hook estándar
		// `user_register`, que wp_insert_user() dispara siempre justo
		// después de insertar la fila. Ese código fuerza el login del
		// usuario recién creado y, de paso, puede fallar (incluso con un
		// error fatal) porque asume un contexto de registro público que
		// aquí no aplica: el usuario lo crea un empresa_admin desde el
		// panel. Aquí solo debe crearse el usuario, así que se suspenden
		// TODOS los callbacks de ese hook durante la creación y se
		// restauran justo después, sin afectar el registro público normal
		// del sitio en ningún otro momento.
		global $wp_filter;
		$user_register_hooks_originales = isset( $wp_filter['user_register'] ) ? clone $wp_filter['user_register'] : null;
		remove_all_actions( 'user_register' );

		$user_id = null;

		try {
			// Buffer de salida como red de seguridad adicional: si a pesar
			// de suspender el hook algo más genera salida inesperada, no
			// debe romper el JSON de esta respuesta.
			ob_start();
			$user_id = wp_insert_user( [
				'user_login'    => $user_login,
				'user_email'    => $correo,
				'user_pass'     => $password,
				'user_nicename' => $user_nicename,
				'nickname'      => $nombre_local,
				'first_name'    => $nombre_local,
				'display_name'  => $nombre_local,
			] );
			ob_end_clean();
		} catch ( \Throwable $e ) {
			ob_end_clean();
			// La fila del usuario puede haber quedado creada en la base de
			// datos aunque algo posterior haya fallado: se recupera su ID
			// por correo antes de decidir si fue un error real.
			$user_id = email_exists( $correo );
		}

		if ( $user_register_hooks_originales ) {
			$wp_filter['user_register'] = $user_register_hooks_originales;
		}

		if ( ! $user_id || is_wp_error( $user_id ) ) {
			wp_send_json_error( [
				'msg' => is_wp_error( $user_id )
					? $user_id->get_error_message()
					: __( 'No se pudo crear el usuario.', AP_TEXT_DOMAIN ),
			], 500 );
		}

		// Salvaguarda adicional por si, a pesar de lo anterior, algo aparte
		// de `user_register` cambia la sesión actual: se restaura de todas
		// formas la del admin que hizo la petición.
		if ( get_current_user_id() !== $grupo_id ) {
			wp_clear_auth_cookie();
			wp_set_current_user( $grupo_id );
			wp_set_auth_cookie( $grupo_id );
		}

		$fecha_final = $area['fecha_expiracion'] ?: '0000-00-00';

		$this->database->crear_membresia_usuario( $area_id, (int) $user_id, (string) $fecha_final );

		$sync_externo = $this->notificar_creacion_wms( $correo, $password, $area_id );

		wp_send_json_success( [
			'user_id'      => (int) $user_id,
			'correo'       => $correo,
			'area'         => [
				'id'           => $area_id,
				'cupo'         => (int) $area['cupo'],
				'cupos_usados' => $this->database->total_usuarios_area( $area_id ),
			],
			'sync_externo' => $sync_externo,
		] );
	}

	/**
	 * Genera un user_login disponible a partir del nombre local del correo.
	 * Si ya está en uso, se le añaden dígitos aleatorios hasta encontrar uno
	 * libre (con un tope de intentos para no entrar en un bucle infinito).
	 */
	private function generar_login_unico( string $nombre_local ): string {
		$base     = sanitize_user( $nombre_local, true );
		$base     = $base ?: 'usuario';
		$login    = $base;
		$intentos = 0;

		while ( username_exists( $login ) && $intentos < 10 ) {
			$login = $base . wp_rand( 100, 999 );
			$intentos++;
		}

		return $login;
	}

	/**
	 * Reproduce el nicename que WordPress asignaría por defecto
	 * (sanitize_title del login) y le concatena caracteres aleatorios,
	 * tal como se pidió explícitamente.
	 */
	private function generar_nicename_random( string $user_login ): string {
		$default = sanitize_title( $user_login );
		$sufijo  = strtolower( wp_generate_password( 5, false, false ) );

		return $default . '-' . $sufijo;
	}

	/**
	 * Notifica el alta del usuario al endpoint de WMS para que quede
	 * replicado en wmslatam.com. Un fallo aquí no revierte la creación local
	 * (el usuario y su membresía ya quedaron guardados): solo se informa al
	 * frontend para que pueda avisar de una sincronización pendiente.
	 *
	 * Si esa respuesta es exitosa (`success: true`), se notifica siempre el
	 * webhook `creacion-inspira-wms` (correo + contraseña), tenga o no el
	 * usuario un área en el ecosistema Octágono. Solo si además trae un
	 * `area_octagono_id` con un valor real se encadena, adicionalmente: alta
	 * en Octágono → aviso final `creacion-inspira-octagono`. Un fallo en
	 * cualquier eslabón de esta cadena secundaria detiene los siguientes
	 * pasos, pero nunca afecta al usuario ya creado localmente.
	 */
	private function notificar_creacion_wms( string $correo, string $password, int $area_id ): bool {
		$response = wp_remote_post( self::WMS_CREATE_USER_ENDPOINT, [
			'method'  => 'POST',
			'timeout' => 20,
			'headers' => [
				'Authorization' => 'Bearer ' . self::WMS_CREATE_USER_TOKEN,
				'Content-Type'  => 'application/json',
			],
			'body'    => wp_json_encode( [
				'correo'        => $correo,
				'password'      => $password,
				'id_area'       => $area_id,
				'tipo_programa' => self::WMS_TIPO_PROGRAMA,
			] ),
		] );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$codigo = wp_remote_retrieve_response_code( $response );
		$exito  = $codigo >= 200 && $codigo < 300;

		if ( ! $exito ) {
			return false;
		}

		$cuerpo            = json_decode( (string) wp_remote_retrieve_body( $response ), true ) ?: [];
		$exito_wms         = ! empty( $cuerpo['success'] );

		if ( ! $exito_wms ) {
			return false;
		}

		// Este webhook se dispara siempre que WMS confirme el alta
		// (success: true), tenga o no `area_octagono_id`. Solo si ese campo
		// trae un valor real se continúa además con la cadena de Octágono.
		$this->notificar_webhook_simple( self::WEBHOOK_CREACION_INSPIRA_WMS, $correo, $password );

		$area_octagono_id = $cuerpo['data']['area_octagono_id'] ?? null;

		if ( $area_octagono_id ) {
			$octagono_ok = $this->crear_usuario_area_octagono( $correo, $password, (int) $area_octagono_id );

			if ( $octagono_ok ) {
				$this->notificar_webhook_simple( self::WEBHOOK_CREACION_INSPIRA_OCTAGONO, $correo, $password );
			}
		}

		return true;
	}

	/**
	 * Da de alta al usuario en el área correspondiente del ecosistema
	 * Octágono, a partir del `area_octagono_id` que devolvió la API de WMS.
	 */
	private function crear_usuario_area_octagono( string $correo, string $password, int $area_id ): bool {
		$response = wp_remote_post( self::OCTAGONO_CREATE_USER_AREA_ENDPOINT, [
			'method'  => 'POST',
			'timeout' => 20,
			'headers' => [
				'Authorization' => 'Bearer ' . self::OCTAGONO_CREATE_USER_AREA_TOKEN,
				'Content-Type'  => 'application/json',
			],
			'body'    => wp_json_encode( [
				'email'    => $correo,
				'password' => $password,
				'area_id'  => $area_id,
			] ),
		] );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$codigo = wp_remote_retrieve_response_code( $response );

		return $codigo >= 200 && $codigo < 300;
	}

	/**
	 * Los dos webhooks de notificación (`creacion-inspira-wms` y
	 * `creacion-inspira-octagono`) solo reciben correo y contraseña; se
	 * comparte una única implementación para ambos.
	 */
	private function notificar_webhook_simple( string $url, string $correo, string $password ): bool {
		$response = wp_remote_post( $url, [
			'method'  => 'POST',
			'timeout' => 20,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [
				'correo'   => $correo,
				'password' => $password,
			] ),
		] );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$codigo = wp_remote_retrieve_response_code( $response );

		return $codigo >= 200 && $codigo < 300;
	}
}
