/**
 * Áreas Asignadas — lógica de frontend: tabla de áreas, modal de usuarios
 * y descarga de informes en PDF.
 *
 * Depende del objeto `apAjax` (url, nonce, i18n) localizado por
 * AP_Frontend::maybe_enqueue_assets(). No se ejecuta en páginas donde el
 * shortcode no está presente, porque el script ni siquiera se encola ahí.
 */
( function () {
	'use strict';

	var i18n = ( window.apAjax && window.apAjax.i18n ) || {};
	var EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

	document.addEventListener( 'DOMContentLoaded', function () {
		initAreasTable();
		// Antes que initUsuariosModal: ese módulo necesita que
		// abrirRecordarRegistro ya esté asignado para su botón del menú.
		initRecordarRegistroModal();
		initUsuariosModal();
		initAccionesDropdown();
		initExportarExcelModal();
	} );

	/* ─────────────────────────────────────────────────────────────────────
	 * Tabla principal de áreas: búsqueda y paginación en cliente.
	 * El volumen de áreas por empresa es bajo, por lo que no se justifica
	 * un roundtrip al servidor para esta tabla (a diferencia de la de
	 * usuarios dentro del modal, que sí puede crecer mucho).
	 * ───────────────────────────────────────────────────────────────────── */
	function initAreasTable() {
		var search  = document.getElementById( 'ap-search' );
		var tbody   = document.getElementById( 'ap-tbody' );
		var noRes   = document.getElementById( 'ap-no-results' );
		var counter = document.getElementById( 'ap-count' );
		var pager   = document.getElementById( 'ap-pager' );

		if ( ! search || ! tbody ) {
			return;
		}

		var PER_PAGE = 5;
		var page = 1;
		var rows = [];

		function allRows() {
			return Array.prototype.slice.call( tbody.querySelectorAll( 'tr' ) );
		}

		function filter( query ) {
			rows = allRows().filter( function ( row ) {
				return ! query
					|| row.dataset.nombre.indexOf( query ) !== -1
					|| row.dataset.estado.indexOf( query ) !== -1;
			} );
			page = 1;
			render();
		}

		function render() {
			var totalPages = Math.max( 1, Math.ceil( rows.length / PER_PAGE ) );
			if ( page > totalPages ) {
				page = totalPages;
			}
			var start = ( page - 1 ) * PER_PAGE;

			allRows().forEach( function ( row ) { row.hidden = true; } );
			rows.forEach( function ( row, index ) {
				row.hidden = index < start || index >= start + PER_PAGE;
			} );

			if ( counter ) counter.textContent = rows.length;
			if ( noRes ) noRes.hidden = rows.length > 0;

			renderPager( pager, page, totalPages, function ( newPage ) {
				page = newPage;
				render();
			} );
		}

		rows = allRows();
		render();

		search.addEventListener( 'input', function ( event ) {
			filter( event.target.value.trim().toLowerCase() );
		} );
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Menú "Acciones" genérico: usado tanto por el toolbar principal
	 * (#ap-acciones-dropdown) como por el encabezado del modal "Ver
	 * usuarios" (#ap-modal-acciones-dropdown, ver initUsuariosModal). Cada
	 * caller registra sus propios listeners sobre los botones del menú
	 * (handleVerResultadosGrupo(), abrirCrearModal(), etc.); esta función
	 * solo abre/cierra el desplegable.
	 *
	 * @return {{cerrar: Function}|null} Handle con cerrar() para que el
	 *         caller pueda forzar el cierre (p. ej. al cerrar el modal que
	 *         lo contiene), o null si falta alguno de los tres elementos.
	 */
	function wireDropdown( dropdown, toggle, menu ) {
		if ( ! dropdown || ! toggle || ! menu ) {
			return null;
		}

		function abrir() {
			menu.hidden = false;
			toggle.setAttribute( 'aria-expanded', 'true' );
			dropdown.setAttribute( 'data-open', 'true' );
		}

		function cerrar() {
			menu.hidden = true;
			toggle.setAttribute( 'aria-expanded', 'false' );
			dropdown.removeAttribute( 'data-open' );
		}

		toggle.addEventListener( 'click', function () {
			if ( toggle.disabled ) return;
			if ( menu.hidden ) abrir(); else cerrar();
		} );

		// Cualquier opción del menú lo cierra al hacer clic, sin importar
		// qué maneje después el clic (cada botón registra su propio
		// listener por separado, sobre los mismos elementos).
		menu.addEventListener( 'click', function ( event ) {
			if ( event.target.closest( '.ap-dropdown-item' ) ) cerrar();
		} );

		document.addEventListener( 'click', function ( event ) {
			if ( ! menu.hidden && ! dropdown.contains( event.target ) ) cerrar();
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! menu.hidden ) cerrar();
		} );

		return { cerrar: cerrar };
	}

	/**
	 * Menú "Acciones" del toolbar: agrupa "Informe general" (comportamiento
	 * sin cambios, ver #ap-btn-informe-grupo dentro de initUsuariosModal) y
	 * "Descargar estado de usuario" (abre el modal de exportación a Excel,
	 * ver initExportarExcelModal) detrás de un único botón desplegable.
	 */
	function initAccionesDropdown() {
		wireDropdown(
			document.getElementById( 'ap-acciones-dropdown' ),
			document.getElementById( 'ap-btn-acciones' ),
			document.getElementById( 'ap-acciones-menu' )
		);
	}

	/**
	 * Descarga el .xlsx de las áreas indicadas vía ap_exportar_usuarios_excel.
	 * Compartida por el modal "Exportar usuarios a Excel" (varias áreas, a
	 * elección del admin) y por "Descargar estado de usuario" dentro del
	 * modal "Ver usuarios" (una sola área: la que está abierta), para no
	 * duplicar el fetch ni el criterio de éxito/error entre ambos.
	 *
	 * @return {Promise<void>} Se resuelve tras disparar la descarga; se
	 *         rechaza con un Error cuyo .message es el motivo (el mensaje
	 *         de wp_send_json_error si el servidor respondió JSON, o
	 *         'export_failed' en cualquier otro caso).
	 */
	function descargarExcelParaAreas( areaIds ) {
		var body = new URLSearchParams();
		body.append( 'action', 'ap_exportar_usuarios_excel' );
		body.append( 'nonce', window.apAjax.nonce );
		areaIds.forEach( function ( id ) { body.append( 'area_ids[]', id ); } );

		return fetch( window.apAjax.url, { method: 'POST', body: body } )
			.then( function ( response ) {
				var contentType = response.headers.get( 'Content-Type' ) || '';

				// Éxito: el servidor responde con el binario del .xlsx.
				// Error: responde JSON (wp_send_json_error), con el mensaje
				// concreto de qué falló (p. ej. "Selecciona al menos un área").
				if ( response.ok && contentType.indexOf( 'application/json' ) === -1 ) {
					return response.blob().then( function ( blob ) {
						var fecha = new Date().toISOString().slice( 0, 10 );
						triggerDownload( URL.createObjectURL( blob ), 'usuarios-' + fecha + '.xlsx', true );
					} );
				}

				return response.json().then( function ( data ) {
					throw new Error( ( data && data.data && data.data.msg ) || 'export_failed' );
				} );
			} );
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Modal "Exportar usuarios a Excel" (menú Acciones → "Descargar estado
	 * de usuario"): selección de áreas de la empresa actual y descarga del
	 * .xlsx generado por ap_exportar_usuarios_excel.
	 * ───────────────────────────────────────────────────────────────────── */
	function initExportarExcelModal() {
		var btnAbrir     = document.getElementById( 'ap-btn-descargar-estado' );
		var overlay      = document.getElementById( 'ap-modal-exportar' );
		var closeBtn     = document.getElementById( 'ap-modal-exportar-close' );
		var cancelBtn    = document.getElementById( 'ap-exportar-cancelar' );
		var aceptarBtn   = document.getElementById( 'ap-exportar-aceptar' );
		var aceptarTexto = document.getElementById( 'ap-exportar-aceptar-texto' );
		var selectAll    = document.getElementById( 'ap-exportar-select-all' );
		var lista        = document.getElementById( 'ap-exportar-list' );
		var errorEl      = document.getElementById( 'ap-exportar-error' );

		if ( ! btnAbrir || ! overlay || ! lista ) {
			return;
		}

		var textoDefecto = aceptarTexto.textContent;

		function checkboxesArea() {
			return Array.prototype.slice.call( lista.querySelectorAll( '.ap-exportar-area-checkbox' ) );
		}

		function ocultarError() {
			errorEl.hidden = true;
			errorEl.textContent = '';
		}

		function mostrarError( mensaje ) {
			errorEl.textContent = mensaje;
			errorEl.hidden = false;
		}

		function sincronizarSelectAll() {
			var checkboxes = checkboxesArea();
			selectAll.checked = checkboxes.length > 0 && checkboxes.every( function ( cb ) { return cb.checked; } );
		}

		function abrirModal() {
			ocultarError();
			overlay.hidden = false;
			document.body.style.overflow = 'hidden';
		}

		function cerrarModal() {
			overlay.hidden = true;
			document.body.style.overflow = '';
		}

		function setExportando( isLoading ) {
			aceptarBtn.disabled = isLoading;
			aceptarBtn.classList.toggle( 'ap-btn-primario-loading', isLoading );
			aceptarTexto.textContent = isLoading ? ( i18n.exportando_excel || 'Exportando…' ) : textoDefecto;
		}

		selectAll.addEventListener( 'change', function () {
			checkboxesArea().forEach( function ( cb ) { cb.checked = selectAll.checked; } );
		} );

		lista.addEventListener( 'change', function ( event ) {
			if ( event.target.classList.contains( 'ap-exportar-area-checkbox' ) ) {
				sincronizarSelectAll();
			}
		} );

		function descargarExcel() {
			var areaIds = checkboxesArea()
				.filter( function ( cb ) { return cb.checked; } )
				.map( function ( cb ) { return cb.value; } );

			if ( ! areaIds.length ) {
				mostrarError( i18n.exportar_selecciona_area || 'Selecciona al menos un área para exportar.' );
				return;
			}

			ocultarError();
			setExportando( true );

			descargarExcelParaAreas( areaIds )
				.then( function () {
					cerrarModal();
				} )
				.catch( function () {
					mostrarError( i18n.error_exportar_excel || 'No se pudo generar el archivo Excel. Inténtalo de nuevo.' );
				} )
				.finally( function () {
					setExportando( false );
				} );
		}

		btnAbrir.addEventListener( 'click', abrirModal );
		closeBtn.addEventListener( 'click', cerrarModal );
		cancelBtn.addEventListener( 'click', cerrarModal );
		overlay.addEventListener( 'click', function ( event ) {
			if ( event.target === overlay ) cerrarModal();
		} );
		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! overlay.hidden ) cerrarModal();
		} );
		aceptarBtn.addEventListener( 'click', descargarExcel );
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Modal "Ver usuarios": búsqueda, filtro por estado del test y
	 * paginación resueltos en el servidor vía ap_get_usuarios_area.
	 * ───────────────────────────────────────────────────────────────────── */
	function initUsuariosModal() {
		var overlay   = document.getElementById( 'ap-modal-overlay' );
		var closeBtn  = document.getElementById( 'ap-modal-close' );
		var modalBody = document.getElementById( 'ap-modal-body' );
		var elNombre  = document.getElementById( 'ap-modal-area-nombre' );
		var elDisp    = document.getElementById( 'ap-modal-disponibles' );

		if ( ! overlay || ! modalBody ) {
			return;
		}

		// Estado del área actualmente abierta en el modal. Lo necesita también
		// el submódulo de "Agregar usuario" (para saber en qué área crear) y
		// el refresco de cupos tras crear uno (para saber si el badge visible
		// corresponde a esa área).
		var estadoActual = null;

		function openModal( btn ) {
			elNombre.textContent = btn.dataset.areaNombre;
			elDisp.textContent   = 'Usuarios: ' + btn.dataset.areaUsados + ' / ' + btn.dataset.areaCupo;

			var state = {
				areaId:  btn.dataset.areaId,
				search:  '',
				estado:  'todos',
				perPage: 10,
				page:    1,
			};
			estadoActual = state;

			renderModalControls( modalBody, state, fetchUsuarios );

			overlay.hidden = false;
			document.body.style.overflow = 'hidden';

			fetchUsuarios( state );
			actualizarEstadoBotonAgregar();
		}

		function closeModal() {
			overlay.hidden = true;
			document.body.style.overflow = '';

			if ( accionesDropdown ) {
				accionesDropdown.cerrar();
			}
		}

		/**
		 * Verifica, a partir de los data-attributes ya presentes en el botón
		 * "Ver usuarios" del área abierta (actualizados en vivo por
		 * actualizarCuposArea()), si el área alcanzó su cupo máximo.
		 * cupo = 0 se trata como "sin límite".
		 */
		function estaAreaLlena() {
			if ( ! estadoActual ) {
				return false;
			}

			var btn = document.querySelector( '.ap-btn-usuarios[data-area-id="' + estadoActual.areaId + '"]' );
			if ( ! btn ) {
				return false;
			}

			var cupo   = parseInt( btn.dataset.areaCupo, 10 ) || 0;
			var usados = parseInt( btn.dataset.areaUsados, 10 ) || 0;

			return cupo > 0 && usados >= cupo;
		}

		/**
		 * Refleja en el botón "Agregar usuario" si el área abierta ya está
		 * llena (deshabilitado + tooltip). La validación real y definitiva
		 * ocurre siempre en el servidor (ver AP_Ajax::crear_usuario()); esto
		 * es solo para no invitar a un clic que el backend va a rechazar.
		 */
		function actualizarEstadoBotonAgregar() {
			var btnAgregar = document.getElementById( 'ap-btn-agregar-usuario' );
			if ( ! btnAgregar ) {
				return;
			}

			var lleno = estaAreaLlena();
			btnAgregar.disabled = lleno;
			btnAgregar.title    = lleno ? ( i18n.area_llena_text || 'Esta área ya alcanzó su cupo máximo de usuarios.' ) : '';
		}

		document.querySelectorAll( '.ap-btn-usuarios' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () { openModal( btn ); } );
		} );

		// Delegación única: los botones "Ver resultados" del modal se
		// regeneran en cada fetchUsuarios(), por lo que el listener vive en
		// modalBody y no se re-registra en cada apertura (evita disparos
		// duplicados de descarga si el modal se abre varias veces).
		modalBody.addEventListener( 'click', function ( event ) {
			var btnResultados = event.target.closest( '.ap-btn-resultados' );
			if ( btnResultados ) {
				handleVerResultadosUsuario( btnResultados.dataset.userId, btnResultados.dataset.userNombre );
				return;
			}

			// Mismo patrón de delegación para el botón de recordatorio: la
			// fila se regenera en cada fetchUsuarios(), así que el listener
			// vive en modalBody en vez de re-registrarse por fila.
			var btnRecordatorio = event.target.closest( '.ap-btn-recordatorio' );
			if ( btnRecordatorio && ! btnRecordatorio.disabled ) {
				handleEnviarRecordatorio( btnRecordatorio );
			}
		} );

		document.querySelectorAll( '.ap-btn-resultados-area' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				if ( '1' === btn.dataset.sinUsuarios ) {
					confirmarConSwal( i18n.sin_usuarios_title, i18n.sin_usuarios_text, 'warning' );
					return;
				}
				if ( '1' === btn.dataset.sinTest ) {
					confirmarConSwal( i18n.sin_test_title, i18n.sin_test_text, 'info' );
					return;
				}
				handleVerResultadosArea( btn.dataset.areaId, btn.dataset.areaNombre );
			} );
		} );

		var btnInformeGrupo = document.getElementById( 'ap-btn-informe-grupo' );
		if ( btnInformeGrupo ) {
			btnInformeGrupo.addEventListener( 'click', function () {
				if ( btnInformeGrupo.disabled ) return;
				handleVerResultadosGrupo();
			} );
		}

		// Menú "Acciones" del encabezado del modal: agrupa "Agregar usuario"
		// (comportamiento sin cambios, ver initCrearUsuarioModal más abajo,
		// que sigue enganchando su propio listener sobre este mismo botón)
		// y "Descargar estado de usuario", que exporta a Excel el área
		// actualmente abierta (estadoActual.areaId), sin necesidad de
		// elegir áreas: ya está implícita por el contexto del modal.
		var accionesDropdown = wireDropdown(
			document.getElementById( 'ap-modal-acciones-dropdown' ),
			document.getElementById( 'ap-modal-btn-acciones' ),
			document.getElementById( 'ap-modal-acciones-menu' )
		);

		var btnDescargarEstadoArea = document.getElementById( 'ap-btn-descargar-estado-area' );
		var textoDescargarEstadoArea = document.getElementById( 'ap-descargar-estado-area-texto' );
		var descargandoEstadoArea = false;

		if ( btnDescargarEstadoArea && textoDescargarEstadoArea ) {
			var textoDescargarDefecto = textoDescargarEstadoArea.textContent;

			btnDescargarEstadoArea.addEventListener( 'click', function () {
				if ( descargandoEstadoArea || ! estadoActual || ! estadoActual.areaId ) {
					return;
				}

				descargandoEstadoArea = true;
				btnDescargarEstadoArea.disabled = true;
				textoDescargarEstadoArea.textContent = i18n.exportando_excel || 'Exportando…';

				descargarExcelParaAreas( [ estadoActual.areaId ] )
					.catch( function () {
						mostrarNotificacion( i18n.error_exportar_excel || 'No se pudo generar el archivo Excel. Inténtalo de nuevo.', 'error' );
					} )
					.finally( function () {
						descargandoEstadoArea = false;
						btnDescargarEstadoArea.disabled = false;
						textoDescargarEstadoArea.textContent = textoDescargarDefecto;
					} );
			} );
		}

		// "Recordar registro" del menú del modal: mismo flujo que el del
		// listado, pero acotado al área que está abierta.
		var btnRecordarArea = document.getElementById( 'ap-btn-recordar-registro-area' );
		if ( btnRecordarArea ) {
			btnRecordarArea.addEventListener( 'click', function () {
				if ( ! estadoActual || ! estadoActual.areaId || ! abrirRecordarRegistro ) {
					return;
				}
				abrirRecordarRegistro( estadoActual.areaId );
			} );
		}

		closeBtn.addEventListener( 'click', closeModal );
		overlay.addEventListener( 'click', function ( event ) {
			if ( event.target === overlay ) closeModal();
		} );
		// Si el modal «Recordar registro» está abierto por encima de este, su
		// propio manejador corta la propagación y esta línea no llega a
		// ejecutarse (ver initRecordarRegistroModal).
		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' === event.key && ! overlay.hidden ) closeModal();
		} );

		/**
		 * Refleja en la UI (fila de la tabla principal, botón "Ver usuarios"
		 * y badge del modal) el cupo actualizado de un área tras crear un
		 * usuario, sin necesidad de recargar la página.
		 */
		function actualizarCuposArea( area ) {
			var row = document.querySelector( '#ap-tbody tr[data-area-id="' + area.id + '"]' );
			if ( row ) {
				var pct = area.cupo > 0 ? Math.min( 100, Math.round( ( area.cupos_usados / area.cupo ) * 100 ) ) : 0;
				var numEl  = row.querySelector( '.ap-cupos-num b' );
				var fillEl = row.querySelector( '.ap-fill' );
				var pctEl  = row.querySelector( '.ap-pct' );

				if ( numEl ) numEl.textContent = area.cupos_usados;
				if ( fillEl ) {
					fillEl.style.width = pct + '%';
					fillEl.classList.remove( 'ap-bar-ok', 'ap-bar-complete' );
					fillEl.classList.add( pct >= 100 ? 'ap-bar-complete' : 'ap-bar-ok' );
				}
				if ( pctEl ) pctEl.textContent = pct + '% ocupado';
			}

			var btnUsuarios = document.querySelector( '.ap-btn-usuarios[data-area-id="' + area.id + '"]' );
			if ( btnUsuarios ) {
				btnUsuarios.dataset.areaUsados = area.cupos_usados;
				btnUsuarios.dataset.areaCupo   = area.cupo;
			}

			if ( estadoActual && String( estadoActual.areaId ) === String( area.id ) ) {
				elDisp.textContent = 'Usuarios: ' + area.cupos_usados + ' / ' + area.cupo;
			}

			actualizarEstadoBotonAgregar();
		}

		/* ─────────────────────────────────────────────────────────────────
		 * Submódulo: modal "Agregar usuario". Solo pide el correo; el resto
		 * de datos se generan en el servidor (ver AP_Ajax::crear_usuario()).
		 * ───────────────────────────────────────────────────────────────── */
		( function initCrearUsuarioModal() {
			var btnAbrir  = document.getElementById( 'ap-btn-agregar-usuario' );
			var crearOverlay = document.getElementById( 'ap-modal-crear-overlay' );
			var crearClose   = document.getElementById( 'ap-modal-crear-close' );
			var crearCancelar = document.getElementById( 'ap-crear-cancelar' );
			var crearAceptar  = document.getElementById( 'ap-crear-aceptar' );
			var crearTexto    = document.getElementById( 'ap-crear-aceptar-texto' );
			var crearInput    = document.getElementById( 'ap-crear-correo' );
			var crearError    = document.getElementById( 'ap-crear-error' );

			if ( ! btnAbrir || ! crearOverlay ) {
				return;
			}

			var textoDefecto = crearTexto.textContent;

			function mostrarError( mensaje ) {
				crearError.textContent = mensaje;
				crearError.hidden = false;
			}

			function ocultarError() {
				crearError.hidden = true;
				crearError.textContent = '';
			}

			function abrirCrearModal() {
				if ( ! estadoActual || ! estadoActual.areaId ) {
					return;
				}

				if ( estaAreaLlena() ) {
					confirmarConSwal( i18n.area_llena_title || 'Cupo alcanzado', i18n.area_llena_text || 'Esta área ya alcanzó su cupo máximo de usuarios.', 'warning' );
					return;
				}

				crearInput.value = '';
				ocultarError();
				crearOverlay.hidden = false;
				setTimeout( function () { crearInput.focus(); }, 50 );
			}

			function cerrarCrearModal() {
				crearOverlay.hidden = true;
			}

			function setCreandoUsuario( isLoading ) {
				crearAceptar.disabled = isLoading;
				crearAceptar.classList.toggle( 'ap-btn-primario-loading', isLoading );
				crearTexto.textContent = isLoading ? ( i18n.creando_usuario || 'Creando…' ) : textoDefecto;
			}

			function aceptarCrearUsuario() {
				if ( ! estadoActual || ! estadoActual.areaId ) {
					return;
				}

				var correo = crearInput.value.trim();

				if ( ! EMAIL_REGEX.test( correo ) ) {
					mostrarError( i18n.correo_invalido || 'Ingresa un correo electrónico válido.' );
					return;
				}

				ocultarError();
				setCreandoUsuario( true );

				postAjax( 'ap_crear_usuario', { area_id: estadoActual.areaId, correo: correo } )
					.then( function ( response ) {
						if ( ! response.success ) {
							mostrarError( ( response.data && response.data.msg ) || i18n.error_crear_usuario || 'No se pudo crear el usuario.' );
							return;
						}

						cerrarCrearModal();
						actualizarCuposArea( response.data.area );
						fetchUsuarios( estadoActual );

						mostrarNotificacion(
							response.data.sync_externo
								? ( i18n.usuario_creado || 'Usuario creado correctamente.' )
								: ( i18n.usuario_creado_sync_pendiente || 'Usuario creado. La sincronización con WMS falló; puede requerir revisión manual.' ),
							response.data.sync_externo ? 'success' : 'warning'
						);
					} )
					.catch( function () {
						mostrarError( i18n.error_red || 'Error de red.' );
					} )
					.finally( function () {
						setCreandoUsuario( false );
					} );
			}

			btnAbrir.addEventListener( 'click', abrirCrearModal );
			crearClose.addEventListener( 'click', cerrarCrearModal );
			crearCancelar.addEventListener( 'click', cerrarCrearModal );
			crearOverlay.addEventListener( 'click', function ( event ) {
				if ( event.target === crearOverlay ) cerrarCrearModal();
			} );
			crearAceptar.addEventListener( 'click', aceptarCrearUsuario );
			crearInput.addEventListener( 'keydown', function ( event ) {
				if ( 'Enter' === event.key ) aceptarCrearUsuario();
			} );
			document.addEventListener( 'keydown', function ( event ) {
				if ( 'Escape' === event.key && ! crearOverlay.hidden ) cerrarCrearModal();
			} );
		} )();
	}

	/**
	 * Construye el shell de controles (buscador + filtros) del modal y
	 * conecta sus eventos. El buscador tiene debounce de 350ms para no
	 * disparar una petición por cada tecla.
	 */
	function renderModalControls( modalBody, state, onStateChange ) {
		// Estructura en 4 bloques apilados: toolbar y meta fijos arriba,
		// zona con scroll propio para la lista, y footer fijo con la
		// paginación. Solo `.ap-modal-scroll` se desplaza; el resto
		// permanece siempre visible mientras se navega la lista.
		modalBody.innerHTML =
			'<div class="ap-modal-toolbar">' +
				'<div class="ap-search-wrap ap-modal-search-grow">' +
					'<input type="text" id="ap-modal-search" class="ap-search ap-modal-search-full" placeholder="Buscar por nombre o correo…" autocomplete="off">' +
					'<span class="ap-search-icon" aria-hidden="true">' +
						'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
							'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>' +
						'</svg>' +
					'</span>' +
				'</div>' +
				'<div class="ap-modal-toolbar-filters">' +
					'<select id="ap-modal-filter-estado" class="ap-modal-select ap-modal-select-half">' +
						'<option value="todos">Todos los estados</option>' +
						'<option value="completado">Test completado</option>' +
						'<option value="pendiente">Test pendiente</option>' +
					'</select>' +
					'<select id="ap-modal-perpage" class="ap-modal-select ap-modal-select-half">' +
						'<option value="10">10 por página</option>' +
						'<option value="25">25 por página</option>' +
						'<option value="50">50 por página</option>' +
						'<option value="100">100 por página</option>' +
						'<option value="todos">Ver todos</option>' +
					'</select>' +
				'</div>' +
			'</div>' +
			'<div class="ap-modal-meta"><span id="ap-modal-count-info" class="ap-modal-count-info"></span></div>' +
			'<div class="ap-modal-scroll"><div id="ap-modal-table-wrap"></div></div>' +
			'<div class="ap-modal-footer"><div class="ap-pagination" id="ap-modal-pager"></div></div>';

		var searchTimeout = null;

		document.getElementById( 'ap-modal-search' ).addEventListener( 'input', function () {
			clearTimeout( searchTimeout );
			var value = this.value;
			searchTimeout = setTimeout( function () {
				state.search = value;
				state.page = 1;
				onStateChange( state );
			}, 350 );
		} );

		document.getElementById( 'ap-modal-filter-estado' ).addEventListener( 'change', function () {
			state.estado = this.value;
			state.page = 1;
			onStateChange( state );
		} );

		document.getElementById( 'ap-modal-perpage' ).addEventListener( 'change', function () {
			state.perPage = 'todos' === this.value ? 'todos' : parseInt( this.value, 10 );
			state.page = 1;
			onStateChange( state );
		} );
	}

	/**
	 * Consulta ap_get_usuarios_area y repinta la tabla + paginador del modal.
	 */
	function fetchUsuarios( state ) {
		var tableWrap = document.getElementById( 'ap-modal-table-wrap' );

		tableWrap.innerHTML =
			'<div class="ap-modal-loading"><span>' +
			( i18n.cargando_usuarios || 'Cargando usuarios…' ) +
			'</span></div>';

		postAjax( 'ap_get_usuarios_area', {
			area_id:  state.areaId,
			search:   state.search,
			estado:   state.estado,
			per_page: state.perPage,
			page:     state.page,
		} )
			.then( function ( response ) {
				if ( ! response.success ) {
					tableWrap.innerHTML = '<p class="ap-modal-err">' + ( ( response.data && response.data.msg ) || i18n.error_carga ) + '</p>';
					var pagerEl = document.getElementById( 'ap-modal-pager' );
					if ( pagerEl ) pagerEl.innerHTML = '';
					return;
				}

				var data = response.data;
				state.page = data.page;

				tableWrap.innerHTML = data.usuarios.length
					? buildUsuariosTable( data.usuarios )
					: '<p class="ap-modal-vacio">' + ( i18n.sin_criterio || 'No se encontraron usuarios con ese criterio.' ) + '</p>';

				updateCountInfo( data.total_filtrado, data.total_area );

				renderPager(
					document.getElementById( 'ap-modal-pager' ),
					state.page,
					data.pages,
					function ( newPage ) {
						state.page = newPage;
						fetchUsuarios( state );
					}
				);
			} )
			.catch( function () {
				tableWrap.innerHTML = '<p class="ap-modal-err">' + ( i18n.error_red || 'Error de red.' ) + '</p>';
			} );
	}

	function updateCountInfo( totalFiltrado, totalArea ) {
		var countEl = document.getElementById( 'ap-modal-count-info' );
		if ( ! countEl ) return;

		countEl.textContent = ( totalFiltrado === totalArea )
			? totalArea + ' ' + ( i18n.usuarios_en_total || 'usuario(s) en total' )
			: totalFiltrado + ' ' + ( i18n.de || 'de' ) + ' ' + totalArea + ' ' + ( i18n.usuarios_en_total || 'usuario(s) en total' ).replace( 'en total', '' ).trim();
	}

	function buildUsuariosTable( usuarios ) {
		return (
			'<div class="ap-mwrap"><table class="ap-mtable"><thead><tr>' +
				'<th>Usuario</th>' +
				'<th>' + escHtml( i18n.perfil || 'Perfil' ) + '</th>' +
				'<th>Estado del test</th><th>Progreso</th><th class="ap-hide-sm">Informe</th>' +
			'</tr></thead><tbody>' +
			usuarios.map( usuarioRowHtml ).join( '' ) +
			'</tbody></table></div>'
		);
	}

	function usuarioRowHtml( usuario ) {
		var pct    = parseInt( usuario.progreso_pct, 10 ) || 0;
		var barCls = pct >= 100 ? 'ap-bar-complete' : ( pct >= 70 ? 'ap-bar-ok' : 'ap-bar-danger' );
		var testOk = true === usuario.tiene_test || 1 === usuario.tiene_test || 'true' === usuario.tiene_test;
		// El valor llega como booleano de PHP, pero puede viajar como 1/0 o
		// "true" según cómo se serialice: se normaliza igual que tiene_test.
		var perfilOk = true === usuario.perfil_completo || 1 === usuario.perfil_completo || 'true' === usuario.perfil_completo;

		// Los atributos data-label alimentan las etiquetas ::before que
		// aparecen cuando la tabla se convierte en tarjetas apiladas en
		// pantallas angostas (ver media query max-width:640px del CSS).
		return (
			'<tr>' +
				'<td data-label="Usuario">' +
					'<span class="ap-name">' + escHtml( usuario.display_name ) + '</span>' +
					'<span class="ap-date">' + escHtml( usuario.user_email ) + '</span>' +
				'</td>' +
				'<td data-label="' + escHtml( i18n.perfil || 'Perfil' ) + '">' +
					'<span class="ap-badge ' + ( perfilOk ? 'ap-badge-activo' : 'ap-badge-pendiente' ) + '">' +
						( perfilOk
							? ( i18n.perfil_completo || 'Completo' )
							: ( i18n.perfil_incompleto || 'Incompleto' ) ) +
					'</span>' +
				'</td>' +
				'<td data-label="Estado del test">' +
					'<span class="ap-estado-test">' +
						'<span class="ap-badge ' + ( testOk ? 'ap-badge-activo' : 'ap-badge-pendiente' ) + '">' +
							( testOk ? ( i18n.completado || 'Completado' ) : ( i18n.incompleto || 'Incompleto' ) ) +
						'</span>' +
						( testOk ? '' : recordatorioButtonHtml( usuario ) ) +
					'</span>' +
				'</td>' +
				'<td data-label="Progreso">' +
					'<div class="ap-cupos">' +
						'<div class="ap-bar ap-bar-full"><div class="ap-fill ' + barCls + '" style="width:' + pct + '%"></div></div>' +
						'<span class="ap-pct">' + pct + '% completado</span>' +
					'</div>' +
				'</td>' +
				'<td class="ap-hide-sm" data-label="Informe">' +
					( testOk ? usuarioResultadosButtonHtml( usuario ) : '<span class="ap-dash">—</span>' ) +
				'</td>' +
			'</tr>'
		);
	}

	function usuarioResultadosButtonHtml( usuario ) {
		return (
			'<button class="ap-btn-resultados" data-user-id="' + escHtml( usuario.ID ) + '" data-user-nombre="' + escHtml( usuario.display_name ) + '">' +
				'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
					'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>' +
					'<polyline points="14 2 14 8 20 8"/>' +
					'<line x1="9" y1="13" x2="15" y2="13"/>' +
					'<line x1="9" y1="17" x2="15" y2="17"/>' +
				'</svg>' +
				( i18n.ver_resultados || 'Ver resultados' ) +
			'</button>'
		);
	}

	/**
	 * Botón discreto de "enviar recordatorio" que acompaña al badge cuando
	 * el test está incompleto. Solo lleva un ícono (sin texto) para no
	 * competir visualmente con el badge de estado; el título accesible
	 * describe la acción para lectores de pantalla y como tooltip nativo.
	 */
	function recordatorioButtonHtml( usuario ) {
		return (
			'<button type="button" class="ap-btn-recordatorio" ' +
				'data-user-id="' + escHtml( usuario.ID ) + '" ' +
				'data-user-nombre="' + escHtml( usuario.display_name ) + '" ' +
				'data-user-correo="' + escHtml( usuario.user_email ) + '" ' +
				'title="' + escHtml( i18n.enviar_recordatorio || 'Enviar recordatorio' ) + '" ' +
				'aria-label="' + escHtml( i18n.enviar_recordatorio || 'Enviar recordatorio' ) + '">' +
				'<svg class="ap-recordatorio-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
					'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>' +
					'<path d="M13.73 21a2 2 0 0 1-3.46 0"/>' +
				'</svg>' +
				'<svg class="ap-recordatorio-spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
					'<path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>' +
				'</svg>' +
			'</button>'
		);
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Envío de recordatorios a usuarios con el test incompleto.
	 * ───────────────────────────────────────────────────────────────────── */

	// Ids de usuario con un envío en curso. Además de deshabilitar el botón
	// (que ya evita el doble clic normal), esto cubre el caso en que la fila
	// se vuelva a pintar mientras la petición sigue en vuelo (cambio de
	// página/filtro) y aparezca un botón nuevo para el mismo usuario.
	var recordatorioEnCurso = {};

	/**
	 * Servicio de envío de recordatorio. La llamada al webhook la hace ahora
	 * el servidor (ap_enviar_recordatorio_test): desde aquí solo se manda el
	 * id del usuario, y es WordPress quien comprueba que pertenece a la
	 * empresa del admin y resuelve su correo. Antes este fetch iba directo al
	 * webhook, lo que dejaba su URL a la vista en el JS público y permitía
	 * invocarlo con cualquier nombre y correo.
	 *
	 * @return {Promise<void>} Se resuelve si el servidor confirma el envío;
	 *                         se rechaza con el motivo en cualquier otro caso.
	 */
	function enviarRecordatorioApi( userId ) {
		return postAjax( 'ap_enviar_recordatorio_test', { user_id: userId } )
			.then( function ( response ) {
				if ( ! response || ! response.success ) {
					throw new Error( ( response && response.data && response.data.msg ) || 'recordatorio_error' );
				}
			} );
	}

	/**
	 * Manejador de clic del botón de recordatorio: controla el estado visual
	 * (deshabilitado + spinner) y traduce el resultado del servicio en una
	 * notificación. El botón se reactiva tanto en éxito como en error para
	 * permitir reintentar sin tener que reabrir el modal.
	 */
	function handleEnviarRecordatorio( btn ) {
		var userId = btn.dataset.userId;

		if ( recordatorioEnCurso[ userId ] ) {
			return;
		}
		recordatorioEnCurso[ userId ] = true;
		setRecordatorioLoading( btn, true );

		enviarRecordatorioApi( userId )
			.then( function () {
				mostrarNotificacion( i18n.recordatorio_enviado || 'Recordatorio enviado correctamente.', 'success' );
			} )
			.catch( function () {
				mostrarNotificacion( i18n.recordatorio_error || 'No se pudo enviar el recordatorio. Inténtalo de nuevo.', 'error' );
			} )
			.finally( function () {
				delete recordatorioEnCurso[ userId ];
				setRecordatorioLoading( btn, false );
			} );
	}

	function setRecordatorioLoading( btn, isLoading ) {
		btn.disabled = isLoading;
		btn.classList.toggle( 'ap-btn-recordatorio-loading', isLoading );
	}

	/**
	 * Notificación breve de resultado. Usa el toast de SweetAlert2 si está
	 * disponible (misma dependencia opcional que confirmarConSwal); si no,
	 * recurre a alert() nativo como respaldo funcional.
	 */
	function mostrarNotificacion( message, icon ) {
		if ( 'undefined' === typeof window.Swal ) {
			alert( message );
			return;
		}

		window.Swal.fire( {
			icon:              icon,
			title:             message,
			toast:             true,
			position:          'top-end',
			showConfirmButton: false,
			timer:             3500,
			timerProgressBar:  true,
		} );
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Generación y descarga de informes en PDF.
	 * ───────────────────────────────────────────────────────────────────── */
	var pdfOverlay  = null;
	var pdfWaitText = null;

	function ensurePdfModalRefs() {
		if ( ! pdfOverlay ) pdfOverlay = document.getElementById( 'ap-modal-pdf' );
		if ( ! pdfWaitText ) pdfWaitText = document.getElementById( 'ap-pdf-waiting-text' );
	}

	function showPdfModal( message ) {
		ensurePdfModalRefs();
		if ( ! pdfOverlay || ! pdfWaitText ) return;
		pdfWaitText.textContent = message || i18n.descargando_informe || 'Estamos descargando tu informe.';
		pdfOverlay.hidden = false;
	}

	function hidePdfModal() {
		ensurePdfModalRefs();
		if ( pdfOverlay ) pdfOverlay.hidden = true;
	}

	function handleVerResultadosUsuario( userId, nombreUsuario ) {
		showPdfModal( i18n.obteniendo_usuario );

		postAjax( 'ap_get_resultados_pdf', { user_id: userId } )
			.then( function ( response ) {
				if ( ! response.success ) {
					hidePdfModal();
					alert( ( response.data && response.data.msg ) || i18n.error_carga );
					return;
				}
				enviarAlWebhookYDescargar( response.data, nombreUsuario, 'usuario' );
			} )
			.catch( function () {
				hidePdfModal();
				alert( i18n.error_red );
			} );
	}

	function handleVerResultadosArea( areaId, areaNombre ) {
		showPdfModal( i18n.obteniendo_area );

		postAjax( 'ap_get_resultados_area_pdf', { area_id: areaId } )
			.then( function ( response ) {
				if ( ! response.success ) {
					hidePdfModal();
					alert( ( response.data && response.data.msg ) || i18n.error_carga );
					return;
				}
				enviarAlWebhookYDescargar( response.data, areaNombre, 'area' );
			} )
			.catch( function () {
				hidePdfModal();
				alert( i18n.error_red );
			} );
	}

	/**
	 * Informe consolidado de todas las áreas del grupo. A diferencia de
	 * handleVerResultadosArea(), response.data trae un array `areas` (un
	 * resultado por área) en vez del resultado de una sola área.
	 */
	function handleVerResultadosGrupo() {
		showPdfModal( i18n.obteniendo_grupo || i18n.obteniendo_area );

		postAjax( 'ap_get_resultados_grupo_pdf', {} )
			.then( function ( response ) {
				if ( ! response.success ) {
					hidePdfModal();
					alert( ( response.data && response.data.msg ) || i18n.error_carga );
					return;
				}
				enviarAlWebhookYDescargar( response.data, 'general', 'area' );
			} )
			.catch( function () {
				hidePdfModal();
				alert( i18n.error_red );
			} );
	}

	/**
	 * URL del webhook que genera el PDF, por tipo de informe.
	 *
	 * Orden de preferencia:
	 *   1. window.ipwPdfWebhooks — lo publica el plugin «Webhooks de
	 *      generación de PDF (Inspira)», que es la pantalla desde la que
	 *      se cambian estas URLs sin tocar código.
	 *   2. apAjax.webhook_pdf — el ajuste propio de este plugin, para que
	 *      siga siendo configurable aunque ese plugin no esté activo.
	 *   3. El literal que estaba escrito aquí antes de existir ninguna de
	 *      las dos pantallas, como última red de seguridad.
	 *
	 * @param {string} tipo 'area' (informe de área y de empresa) o 'usuario'.
	 */
	function urlWebhookPdf( tipo ) {
		var central = window.ipwPdfWebhooks && window.ipwPdfWebhooks[ tipo ];

		return central ||
			( window.apAjax && window.apAjax.webhook_pdf ) ||
			'https://api.efrenmartinezortiz-ia.com/webhook/pdf_aprobandome';
	}

	/**
	 * Envía los resultados al webhook externo que genera el PDF y fuerza
	 * la descarga del archivo resultante.
	 *
	 * `tipo` decide a qué webhook configurado se manda: los informes de
	 * área y el consolidado de la empresa comparten uno ('area') porque
	 * producen el mismo tipo de documento, y el informe de un trabajador
	 * concreto usa el suyo ('usuario'), que por defecto apunta al mismo
	 * sitio pero puede separarse desde wp-admin.
	 */
	function enviarAlWebhookYDescargar( result, nombreArchivoBase, tipo ) {
		showPdfModal( i18n.descargando_informe );

		var nombreArchivo = 'informe-aprobandome-' + sanitizarNombreArchivo( nombreArchivoBase ) + '.pdf';

		fetch( urlWebhookPdf( tipo || 'area' ), {
			method:  'POST',
			headers: { 'Content-Type': 'application/json' },
			body:    JSON.stringify( result ),
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( data ) {
				forzarDescargaDesdeGCS( data.pdfUrl, nombreArchivo );
			} )
			.catch( function () {
				alert( i18n.error_pdf || 'Ocurrió un error al generar el PDF.' );
			} )
			.finally( hidePdfModal );
	}

	function forzarDescargaDesdeGCS( url, filename ) {
		fetch( url, { mode: 'cors' } )
			.then( function ( response ) {
				if ( ! response.ok ) throw new Error( 'fetch_failed' );
				return response.blob();
			} )
			.then( function ( blob ) {
				// Se fuerza el tipo genérico para que el navegador no intente
				// abrir el PDF inline en lugar de descargarlo.
				var pdfBlob = new Blob( [ blob ], { type: 'application/octet-stream' } );
				triggerDownload( URL.createObjectURL( pdfBlob ), filename, true );
			} )
			.catch( function () {
				// Respaldo si el fetch con CORS falla: enlace directo.
				triggerDownload( url, filename, false );
			} );
	}

	function triggerDownload( href, filename, isObjectUrl ) {
		var link = document.createElement( 'a' );
		link.href = href;
		link.download = filename;
		if ( ! isObjectUrl ) link.target = '_blank';
		link.style.display = 'none';
		document.body.appendChild( link );
		link.click();
		setTimeout( function () {
			link.remove();
			if ( isObjectUrl ) URL.revokeObjectURL( href );
		}, 200 );
	}

	function sanitizarNombreArchivo( nombre ) {
		return ( nombre || 'archivo' )
			.normalize( 'NFD' ).replace( /[\u0300-\u036f]/g, '' )
			.replace( /[^a-zA-Z0-9]/g, '-' )
			.replace( /-+/g, '-' )
			.replace( /^-|-$/g, '' )
			.toLowerCase();
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Modal «Recordar registro» (dos pasos: selección y confirmación).
	 *
	 * Un único modal sirve a los dos puntos de entrada: el menú "Acciones"
	 * del listado (todas las áreas de la empresa, con filtro por área) y el
	 * del modal de usuarios (una sola área, sin ese filtro). La diferencia
	 * se resuelve con `state.areaId`; la tabla, la selección y el envío son
	 * exactamente los mismos en ambos casos.
	 * ───────────────────────────────────────────────────────────────────── */

	// Lo asigna initRecordarRegistroModal() para que initUsuariosModal pueda
	// abrir el flujo acotado al área que tenga abierta.
	var abrirRecordarRegistro = null;

	function initRecordarRegistroModal() {
		var overlay      = document.getElementById( 'ap-modal-recordar' );
		var paso1        = document.getElementById( 'ap-recordar-paso-1' );
		var paso2        = document.getElementById( 'ap-recordar-paso-2' );
		var tabla        = document.getElementById( 'ap-recordar-tabla' );
		var confirmacion = document.getElementById( 'ap-recordar-confirmacion' );
		var resumen      = document.getElementById( 'ap-recordar-resumen' );
		var conteo       = document.getElementById( 'ap-recordar-conteo' );
		var badgeSel     = document.getElementById( 'ap-recordar-seleccionados' );
		var errorEl      = document.getElementById( 'ap-recordar-error' );

		var inputSearch  = document.getElementById( 'ap-recordar-search' );
		var selectArea   = document.getElementById( 'ap-recordar-filtro-area' );
		var selectRec    = document.getElementById( 'ap-recordar-filtro-recordatorio' );
		var rangoWrap    = document.getElementById( 'ap-recordar-rango' );
		var inputDesde   = document.getElementById( 'ap-recordar-desde' );
		var inputHasta   = document.getElementById( 'ap-recordar-hasta' );

		var btnCerrar    = document.getElementById( 'ap-recordar-close' );
		var btnCancelar  = document.getElementById( 'ap-recordar-cancelar' );
		var btnSiguiente = document.getElementById( 'ap-recordar-siguiente' );
		var btnVolver    = document.getElementById( 'ap-recordar-volver' );
		var btnEnviar    = document.getElementById( 'ap-recordar-enviar' );
		var textoEnviar  = document.getElementById( 'ap-recordar-enviar-texto' );

		if ( ! overlay || ! tabla ) {
			return;
		}

		var textoEnviarDefecto = textoEnviar.textContent;
		var searchTimeout      = null;
		var enviando           = false;
		var areasCargadas      = false;

		// `seleccion` guarda el objeto completo de cada usuario marcado, no
		// solo su id: así la selección sobrevive a un cambio de filtro que
		// saque esas filas de la vista, y el paso 2 puede mostrar su correo y
		// su último recordatorio sin volver a consultarlos.
		var state = {
			areaId:    0,
			lista:     [],
			total:     0,
			seleccion: {},
		};

		/* ── Apertura y cierre ───────────────────────────────────────────── */

		function abrir( areaId ) {
			state.areaId    = parseInt( areaId, 10 ) || 0;
			state.lista     = [];
			state.total     = 0;
			state.seleccion = {};

			inputSearch.value = '';
			selectRec.value   = 'todos';
			inputDesde.value  = '';
			inputHasta.value  = '';
			rangoWrap.hidden  = true;

			// El filtro por área no aplica cuando el flujo se abre desde el
			// modal de un área concreta: todos los resultados son de esa área.
			selectArea.hidden = state.areaId > 0;
			if ( state.areaId > 0 ) {
				selectArea.value = '0';
			}

			mostrarPaso( 1 );
			ocultarError();

			overlay.hidden = false;
			document.body.style.overflow = 'hidden';

			cargar();
		}

		function cerrar() {
			overlay.hidden = true;
			document.body.style.overflow = '';
		}

		function mostrarPaso( numero ) {
			paso1.hidden = 1 !== numero;
			paso2.hidden = 2 !== numero;
		}

		function ocultarError() {
			errorEl.hidden = true;
			errorEl.textContent = '';
		}

		function mostrarError( mensaje ) {
			errorEl.textContent = mensaje;
			errorEl.hidden = false;
		}

		/* ── Paso 1: carga y pintado ─────────────────────────────────────── */

		function cargar() {
			tabla.innerHTML = '<div class="ap-modal-loading"><span>' +
				escHtml( i18n.rec_cargando || 'Cargando usuarios…' ) + '</span></div>';

			var payload = {
				search:              inputSearch.value.trim(),
				filtro_recordatorio: selectRec.value,
				desde:               inputDesde.value,
				hasta:               inputHasta.value,
			};

			if ( state.areaId > 0 ) {
				payload.area_id = state.areaId;
			} else {
				payload.filtro_area = selectArea.value || 0;
				// Las opciones del filtro por área solo se piden una vez.
				payload.con_areas = areasCargadas ? 0 : 1;
			}

			postAjax( 'ap_get_usuarios_pendientes_registro', payload )
				.then( function ( response ) {
					if ( ! response || ! response.success ) {
						tabla.innerHTML = '<p class="ap-modal-err">' +
							escHtml( ( response && response.data && response.data.msg ) || i18n.error_carga || 'Error al cargar.' ) +
							'</p>';
						return;
					}

					state.lista = response.data.usuarios || [];
					state.total = parseInt( response.data.total, 10 ) || 0;

					if ( ! areasCargadas && response.data.areas && response.data.areas.length ) {
						pintarOpcionesArea( response.data.areas );
						areasCargadas = true;
					}

					pintarTabla();
					actualizarContadores();
				} )
				.catch( function () {
					tabla.innerHTML = '<p class="ap-modal-err">' + escHtml( i18n.error_red || 'Error de red.' ) + '</p>';
				} );
		}

		function pintarOpcionesArea( areas ) {
			selectArea.innerHTML = '<option value="0">' +
				escHtml( i18n.rec_todas_areas || 'Todas las áreas' ) + '</option>' +
				areas.map( function ( area ) {
					return '<option value="' + escHtml( area.id ) + '">' + escHtml( area.nombre ) + '</option>';
				} ).join( '' );
		}

		function pintarTabla() {
			// Dos estados vacíos distintos: no hay nadie pendiente en absoluto
			// (nada que hacer aquí) o los filtros no devolvieron nada (se puede
			// corregir cambiándolos).
			if ( 0 === state.total ) {
				tabla.innerHTML =
					'<div class="ap-recordar-vacio">' +
						'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
							'<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>' +
						'</svg>' +
						'<p class="ap-recordar-vacio-titulo">' + escHtml( i18n.rec_sin_pendientes || 'Todos los usuarios completaron su perfil.' ) + '</p>' +
						'<p class="ap-recordar-vacio-texto">' + escHtml( i18n.rec_sin_pendientes_sub || '' ) + '</p>' +
					'</div>';
				return;
			}

			if ( ! state.lista.length ) {
				tabla.innerHTML = '<p class="ap-modal-vacio">' +
					escHtml( i18n.rec_sin_criterio || 'Ningún usuario coincide con los filtros aplicados.' ) + '</p>';
				return;
			}

			tabla.innerHTML =
				'<div class="ap-mwrap"><table class="ap-mtable ap-recordar-tabla"><thead><tr>' +
					'<th class="ap-recordar-col-check">' +
						'<input type="checkbox" id="ap-recordar-check-todos" ' +
							'aria-label="' + escHtml( i18n.rec_seleccionar_todos || 'Seleccionar todos los resultados' ) + '">' +
					'</th>' +
					'<th>' + escHtml( i18n.rec_col_usuario || 'Usuario' ) + '</th>' +
					'<th>' + escHtml( i18n.rec_col_area || 'Área' ) + '</th>' +
					'<th>' + escHtml( i18n.rec_col_ultimo || 'Último recordatorio' ) + '</th>' +
				'</tr></thead><tbody>' +
				state.lista.map( filaUsuarioHtml ).join( '' ) +
				'</tbody></table></div>';

			sincronizarCheckTodos();
		}

		function filaUsuarioHtml( usuario ) {
			var marcado = !! state.seleccion[ usuario.ID ];

			return (
				'<tr class="' + ( marcado ? 'ap-recordar-fila-sel' : '' ) + '" data-user-id="' + escHtml( usuario.ID ) + '">' +
					'<td class="ap-recordar-col-check">' +
						'<input type="checkbox" class="ap-recordar-check" value="' + escHtml( usuario.ID ) + '"' +
							( marcado ? ' checked' : '' ) +
							' aria-label="' + escHtml( usuario.user_email ) + '">' +
					'</td>' +
					'<td data-label="' + escHtml( i18n.rec_col_usuario || 'Usuario' ) + '">' +
						'<span class="ap-name">' + escHtml( usuario.user_email ) + '</span>' +
					'</td>' +
					'<td data-label="' + escHtml( i18n.rec_col_area || 'Área' ) + '">' +
						escHtml( usuario.area_nombre ) +
					'</td>' +
					'<td data-label="' + escHtml( i18n.rec_col_ultimo || 'Último recordatorio' ) + '">' +
						ultimoHtml( usuario ) +
					'</td>' +
				'</tr>'
			);
		}

		function ultimoHtml( usuario ) {
			return usuario.ultimo_formateado
				? '<span class="ap-recordar-fecha">' + escHtml( usuario.ultimo_formateado ) + '</span>'
				: '<span class="ap-recordar-nunca">' + escHtml( i18n.rec_sin_recordatorios || 'Sin recordatorios' ) + '</span>';
		}

		function actualizarContadores() {
			var seleccionados = Object.keys( state.seleccion ).length;

			conteo.textContent = state.lista.length === state.total
				? state.total + ' ' + ( i18n.rec_pendientes || 'usuario(s) sin completar su perfil' )
				: state.lista.length + ' ' + ( i18n.de || 'de' ) + ' ' + state.total + ' ' +
				  ( i18n.rec_pendientes || 'usuario(s) sin completar su perfil' );

			badgeSel.textContent = seleccionados + ' ' + ( i18n.rec_seleccionados || 'seleccionado(s)' );
			badgeSel.hidden      = 0 === seleccionados;

			btnSiguiente.disabled = 0 === seleccionados;
		}

		/**
		 * El checkbox del encabezado refleja el estado de los resultados que
		 * están a la vista: marcado si todos lo están, indeterminado si solo
		 * algunos (la selección puede incluir usuarios fuera del filtro).
		 */
		function sincronizarCheckTodos() {
			var checkTodos = document.getElementById( 'ap-recordar-check-todos' );
			if ( ! checkTodos ) return;

			var marcados = state.lista.filter( function ( u ) { return !! state.seleccion[ u.ID ]; } ).length;

			checkTodos.checked       = state.lista.length > 0 && marcados === state.lista.length;
			checkTodos.indeterminate = marcados > 0 && marcados < state.lista.length;
		}

		/* ── Paso 2: confirmación ────────────────────────────────────────── */

		function pintarConfirmacion() {
			var seleccionados = Object.keys( state.seleccion ).map( function ( id ) { return state.seleccion[ id ]; } );

			resumen.textContent = ( i18n.rec_resumen || 'Se enviará un recordatorio a los siguientes usuarios:' ) +
				' (' + seleccionados.length + ')';

			confirmacion.innerHTML =
				'<div class="ap-mwrap"><table class="ap-mtable ap-recordar-tabla"><thead><tr>' +
					'<th>' + escHtml( i18n.rec_col_correo || 'Correo electrónico' ) + '</th>' +
					'<th>' + escHtml( i18n.rec_col_ultimo || 'Último recordatorio' ) + '</th>' +
				'</tr></thead><tbody>' +
				seleccionados.map( function ( usuario ) {
					return '<tr>' +
						'<td data-label="' + escHtml( i18n.rec_col_correo || 'Correo electrónico' ) + '">' +
							'<span class="ap-name">' + escHtml( usuario.user_email ) + '</span>' +
						'</td>' +
						'<td data-label="' + escHtml( i18n.rec_col_ultimo || 'Último recordatorio' ) + '">' +
							ultimoHtml( usuario ) +
						'</td>' +
					'</tr>';
				} ).join( '' ) +
				'</tbody></table></div>';
		}

		function setEnviando( activo ) {
			enviando = activo;
			btnEnviar.disabled = activo;
			btnVolver.disabled = activo;
			btnEnviar.classList.toggle( 'ap-btn-primario-loading', activo );
			textoEnviar.textContent = activo
				? ( i18n.rec_enviando || 'Enviando…' )
				: textoEnviarDefecto;
		}

		function enviar() {
			if ( enviando ) {
				return;
			}

			var ids = Object.keys( state.seleccion );

			if ( ! ids.length ) {
				return;
			}

			ocultarError();
			setEnviando( true );

			postAjax( 'ap_enviar_recordatorios_registro', { user_ids: ids } )
				.then( function ( response ) {
					if ( ! response || ! response.success ) {
						// La selección se conserva a propósito: el admin debe
						// poder reintentar sin volver a marcarlos uno a uno.
						mostrarError( ( response && response.data && response.data.msg ) ||
							i18n.rec_error || 'No se pudieron enviar los recordatorios.' );
						return;
					}

					mostrarNotificacion(
						i18n.rec_exito || 'La solicitud de envío de recordatorios se procesó correctamente.',
						'success'
					);
					cerrar();
				} )
				.catch( function () {
					mostrarError( i18n.error_red || 'Error de red.' );
				} )
				.finally( function () {
					setEnviando( false );
				} );
		}

		/* ── Eventos ─────────────────────────────────────────────────────── */

		// Delegación: las filas se repintan en cada carga, así que el listener
		// vive en el contenedor y no se vuelve a registrar por fila.
		tabla.addEventListener( 'change', function ( event ) {
			var checkTodos = event.target.closest( '#ap-recordar-check-todos' );

			if ( checkTodos ) {
				state.lista.forEach( function ( usuario ) {
					if ( checkTodos.checked ) {
						state.seleccion[ usuario.ID ] = usuario;
					} else {
						delete state.seleccion[ usuario.ID ];
					}
				} );
				pintarTabla();
				actualizarContadores();
				return;
			}

			var check = event.target.closest( '.ap-recordar-check' );

			if ( check ) {
				var usuario = state.lista.filter( function ( u ) {
					return String( u.ID ) === String( check.value );
				} )[ 0 ];

				if ( check.checked && usuario ) {
					state.seleccion[ usuario.ID ] = usuario;
				} else {
					delete state.seleccion[ check.value ];
				}

				var fila = check.closest( 'tr' );
				if ( fila ) fila.classList.toggle( 'ap-recordar-fila-sel', check.checked );

				sincronizarCheckTodos();
				actualizarContadores();
			}
		} );

		inputSearch.addEventListener( 'input', function () {
			clearTimeout( searchTimeout );
			searchTimeout = setTimeout( cargar, 350 );
		} );

		selectArea.addEventListener( 'change', cargar );

		selectRec.addEventListener( 'change', function () {
			rangoWrap.hidden = 'rango' !== selectRec.value;
			cargar();
		} );

		inputDesde.addEventListener( 'change', cargar );
		inputHasta.addEventListener( 'change', cargar );

		btnSiguiente.addEventListener( 'click', function () {
			if ( btnSiguiente.disabled ) return;
			pintarConfirmacion();
			ocultarError();
			mostrarPaso( 2 );
		} );

		// Volver no recarga ni limpia nada: los filtros y la selección siguen
		// exactamente como estaban.
		btnVolver.addEventListener( 'click', function () {
			if ( enviando ) return;
			mostrarPaso( 1 );
		} );

		btnEnviar.addEventListener( 'click', enviar );

		btnCerrar.addEventListener( 'click', function () { if ( ! enviando ) cerrar(); } );
		btnCancelar.addEventListener( 'click', function () { if ( ! enviando ) cerrar(); } );

		overlay.addEventListener( 'click', function ( event ) {
			if ( event.target === overlay && ! enviando ) cerrar();
		} );

		document.addEventListener( 'keydown', function ( event ) {
			if ( 'Escape' !== event.key || overlay.hidden ) {
				return;
			}

			// Este modal puede estar montado sobre el de usuarios, que también
			// cierra con Escape desde `document`. Sin cortar aquí la
			// propagación, una sola pulsación cerraría los dos de golpe: el
			// otro manejador no puede distinguir el caso, porque para cuando
			// se ejecuta este ya marcó su overlay como oculto.
			//
			// Depende de que este listener se registre antes que el del modal
			// de usuarios, que es justo lo que garantiza el orden de llamadas
			// en DOMContentLoaded.
			event.stopImmediatePropagation();

			if ( ! enviando ) cerrar();
		} );

		var btnAbrirGeneral = document.getElementById( 'ap-btn-recordar-registro' );
		if ( btnAbrirGeneral ) {
			btnAbrirGeneral.addEventListener( 'click', function () { abrir( 0 ); } );
		}

		abrirRecordarRegistro = abrir;
	}

	/* ─────────────────────────────────────────────────────────────────────
	 * Utilidades compartidas.
	 * ───────────────────────────────────────────────────────────────────── */

	/**
	 * POST estándar al admin-ajax.php del sitio, con nonce ya incluido.
	 *
	 * Un valor de array se envía como `clave[]` repetida, que es la forma en
	 * que PHP lo recibe como array en $_POST. Pasarlo tal cual a
	 * URLSearchParams lo convertiría en una única cadena separada por comas.
	 */
	function postAjax( action, payload ) {
		var body = new URLSearchParams();
		body.append( 'action', action );
		body.append( 'nonce', window.apAjax.nonce );

		Object.keys( payload || {} ).forEach( function ( key ) {
			var value = payload[ key ];

			if ( Array.isArray( value ) ) {
				value.forEach( function ( item ) { body.append( key + '[]', item ); } );
				return;
			}

			body.append( key, value );
		} );

		return fetch( window.apAjax.url, {
			method:  'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body:    body,
		} ).then( function ( response ) { return response.json(); } );
	}

	function renderPager( container, currentPage, totalPages, onPageChange ) {
		if ( ! container ) return;
		if ( totalPages <= 1 ) { container.innerHTML = ''; return; }

		container.innerHTML =
			pagerButtonHtml( arrowSvg( '15 18 9 12 15 6' ), currentPage - 1, currentPage === 1 ) +
			Array.from( { length: totalPages }, function ( _unused, index ) {
				return pagerButtonHtml( index + 1, index + 1, false, index + 1 === currentPage );
			} ).join( '' ) +
			pagerButtonHtml( arrowSvg( '9 18 15 12 9 6' ), currentPage + 1, currentPage === totalPages );

		container.querySelectorAll( '.ap-pbtn:not([disabled])' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				onPageChange( parseInt( btn.dataset.p, 10 ) );
			} );
		} );
	}

	function pagerButtonHtml( label, page, disabled, active ) {
		return (
			'<button class="ap-pbtn' + ( active ? ' ap-pactive' : '' ) + '" data-p="' + page + '" ' +
			( disabled ? 'disabled' : '' ) + '>' + label + '</button>'
		);
	}

	function arrowSvg( points ) {
		return (
			'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
				'<polyline points="' + points + '"/>' +
			'</svg>'
		);
	}

	function escHtml( value ) {
		return String( value )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' );
	}

	/**
	 * Diálogo de confirmación. Usa SweetAlert2 si está disponible en la
	 * página (dependencia externa documentada en readme.txt); si no,
	 * recurre a alert() nativo como respaldo funcional.
	 */
	function confirmarConSwal( title, text, icon ) {
		if ( 'undefined' === typeof window.Swal ) {
			alert( title + '\n' + text );
			return;
		}

		window.Swal.fire( {
			icon: icon,
			title: title,
			text: text,
			confirmButtonText: i18n.entendido || 'Entendido',
			confirmButtonColor: '#423373',
		} );
	}
} )();
